# Majesto

A focus, recall and attention-training app for iOS and Android.
React Native + Expo + TypeScript, Expo Router, offline-first with local persistence.

## Run it

```bash
npm install
npx expo install --fix     # aligns every Expo package to the exact version for your SDK
npx expo start             # press i (iOS simulator), a (Android emulator), or scan the QR in Expo Go
```

Scripts: `npm test` (logic tests), `npm run typecheck`.

## What's in it

| Tab | What it does |
| --- | --- |
| **Today** | Concentric goal rings (focus, recall, drills), streak, suggested next actions, daily intentions, week chart |
| **Focus** | Timer with presets and custom length, pause/resume, distraction counter, link a block to an intention, break flow, end-of-block notification. Survives backgrounding and app restarts because it stores timestamps, not a countdown |
| **Recall** | Decks and cards, spaced repetition (SM-2 style with learning steps and lapses), review sessions with interval previews on the buttons, optional typed recall, bulk import (`front :: back`) |
| **Drills** | Schulte table, number span (forward/backward), N-back, color clash (Stroop), number sequences. Each scores 0-1000, tracks personal bests, and adapts difficulty |
| **Profile** | Level and XP, streaks, lifetime stats, 16 achievements, goals and settings, JSON export, erase all |

XP comes from focus time, card reviews and drills. A day counts toward the streak with 10 minutes of focus, 10 cards, or one drill.

## Structure

```
app/                Expo Router screens (thin: read the store, call actions)
src/core/           Pure TypeScript. No React, no native modules. All the rules live here
  srs.ts            scheduler, queues, interval labels, bulk import parser
  focus.ts          timer math (pause-safe, restart-safe)
  xp.ts streak.ts   levels, XP, streaks
  achievements.ts   definitions and metrics
  stats.ts          derived numbers for screens
  drills/           generators and scoring for each drill
src/store/          observable store, actions, migrations, persistence
src/services/       haptics, notifications, sync seam
src/features/       drill screens
src/ui/             theme and components
tests/              node:test suites for core and store
```

Screens never contain business rules. Anything worth testing is in `src/core` or `src/store`, which have no React Native imports, so the tests run in plain Node.

## Android focus guard, floating timer and AI help

Android-only additions that sit on top of the existing Focus timer. Nothing else in the app changed.

| Piece | Where |
| --- | --- |
| Native Android module (foreground service, floating timer, app blocker, block screen, Do Not Disturb, one-shot screenshot) | `modules/majesto-focus/` (Kotlin, autolinked by Expo) |
| Timer/native sync logic (pure TS, tested) | `src/core/guard.ts`, `src/ui/GuardController.tsx`, `src/services/focusGuard.ts` |
| AI client (pure TS, tested) and screen | `src/core/ai.ts`, `src/services/ai.ts`, `app/assist.tsx` |
| Settings and app picker | `app/focus-guard.tsx`, `app/blocked-apps.tsx` (opened from Profile, Focus guard & AI help) |
| AI backend (holds the provider key) | `backend/` (see `backend/README.md`) |
| Share a picture into Majesto | `plugins/withShareImage.js` |

These need a **native Android build** (EAS or the GitHub workflow below). They do nothing in Expo Go or on iOS, where the controls are hidden and the timer works exactly as before.

### How it behaves

- Turn on Focus guard (Focus tab or Profile). Pick apps to block, floating timer, and optional Do Not Disturb.
- Start a focus block: a foreground service shows a notification, the floating pill shows `HH:MM:SS`, and blocked apps are covered by a full-screen reminder as soon as they come to the front.
- Tap the pill: Pause/Resume, AI Help, Stop (asks to confirm). AI Help can capture the screen (Android asks for consent every time) or open Majesto's AI screen. The timer and restrictions keep running while you ask, and "Back to studying" returns to your app.
- The timer in the app is the single source of truth. Presses on the floating timer are written back to it with their real timestamps, so XP and logs stay correct even if the app was closed.
- The service stops itself when the block ends, is stopped, or is discarded. Do Not Disturb is restored to what it was before.

### Permissions (all granted by you in Android Settings, never automatically)

| Permission | Why | Needed for |
| --- | --- | --- |
| Display over other apps | floating timer, block screen | timer pill, blocking |
| Usage access **or** Accessibility | notice which app is in front (app names only) | blocking |
| Do Not Disturb access | silence notifications and restore afterwards | optional |
| Notifications | the "session running" notification | optional |
| Screen capture consent | one screenshot for AI help | asked each time |

Profile, Focus guard & AI help has an "Open Android settings" button for each and shows whether it is granted.

### Limits (please read)

- Android does not allow an app to close or freeze other apps. Blocking is a cover screen shown when a blocked app is seen, so a blocked app can flash for a moment. Without a detection permission nothing can be blocked.
- Phone, Settings, launcher and Majesto are never blocked.
- On newer Android versions (15+) the cover screen opens most reliably while the floating timer is showing, so keep the floating timer on when blocking apps.
- Pausing the timer pauses blocking. After a phone restart, open Majesto and the running block resumes.
- The Accessibility option is optional and cannot read the screen. Apps distributed through Google Play need a policy declaration for the foreground-service type and for Accessibility use.
- Notification control uses Do Not Disturb only. Majesto never reads notification content.
- AI help needs your own backend and a provider key (`backend/README.md`). Without it the app says so and sends nothing.

### Build the APK

Option A, GitHub (no local Android setup): push the project to GitHub, open Actions, run **Build Android APK**. Optional repository secrets `AI_ENDPOINT` and `AI_TOKEN` bake the AI address into the build. Download `majesto-apk` from the run.

Option B, EAS (as before): `npm run build:android:apk`.

Option C, locally with Android SDK and JDK 17: `npm install && npx expo install --fix && npx expo prebuild --platform android && cd android && ./gradlew assembleRelease`. Output: `android/app/build/outputs/apk/release/app-release.apk`.

Tests: `npm test` (app logic, including the new guard and AI client tests) and `npm run test:backend`.

## Persistence

State is one JSON document in AsyncStorage (`majesto:state`), saved shortly after any change and again when the app leaves the foreground. `src/store/state.ts` holds the schema version and a `migrate` function that also repairs damaged or partial data. When you change the shape of saved data, bump `SCHEMA_VERSION` and add a step to `MIGRATIONS`.

## Cloud sync (Supabase-ready)

Nothing needs an account. `src/services/sync.ts` defines the `SyncAdapter` interface and documents the table, row-level-security policy and merge rules for a Supabase implementation. Env names are in `.env.example`.

## Fastest way to try it on your phone (no build, no Apple Developer account)

```bash
npm install && npx expo install --fix
npx expo login
npm run start:go        # same as: npx expo start --go
```

Install **Expo Go** on the phone (App Store / Google Play), sign in with the same Expo account, then scan the QR code. On Android the CLI can also install Expo Go for you. Because `expo-dev-client` is installed for the EAS development builds, plain `npx expo start` targets a development build instead, so use `start:go` (or press `s` in the terminal to switch). Phone and computer must be on the same Wi-Fi, or add `--tunnel`.

Expo Go is for quick checks. Use the builds below to test real notification timing and standalone behavior.

## No computer? Build from your phone

Use a free cloud terminal in your phone's browser. Expo's servers do the actual build.

1. Make free accounts at github.com and expo.dev.
2. On github.com (browser menu: "Request desktop site") create a private repository, tick "Add a README".
3. In the repository choose Add file, then Upload files, and upload `majesto.zip`. Commit.
4. Choose Code, then Codespaces, then Create codespace on main. A browser editor with a terminal opens.
5. In the terminal run: `unzip majesto.zip && cd majesto && bash scripts/build-android.sh`
6. Answer the prompts (Expo login, create project: yes, generate keystore: yes). The build link appears at the end.
7. Open that link on your Android phone, download the APK, install it.

For an iPhone without a paid Apple account, run `npx expo start --go --tunnel` in the Codespace, then open Expo Go on the phone (signed in to the same Expo account) and pick the project from the Home tab.

## Build installable apps (Expo SDK 57, EAS Build)

One-time setup:

```bash
npm install                      # creates package-lock.json
npx expo install --fix           # aligns every package to the exact SDK 57 versions
npx expo-doctor                  # must pass before you spend a build
npm install -g eas-cli
eas login
eas init                         # links the project, writes extra.eas.projectId into app.json
git add -A && git commit -m "Link EAS project"
```

| Goal | Command | Result |
| --- | --- | --- |
| Android APK to install and test | `eas build --platform android --profile preview` | `.apk`, no account beyond Expo needed |
| Android dev client (live reload) | `eas build --platform android --profile development` | `.apk` |
| Android Play Store bundle | `eas build --platform android --profile production` | `.aab` |
| Android production-settings APK | `eas build --platform android --profile production-apk` | `.apk` |
| iPhone dev client | `eas device:create` then `eas build --platform ios --profile development` | needs paid Apple Developer account |
| iPhone standalone test build | `eas device:create` then `eas build --platform ios --profile preview` | needs paid Apple Developer account |
| TestFlight | `eas build --platform ios --profile production` then `eas submit --platform ios` | needs paid Apple Developer account |
| iOS Simulator (Mac only) | `eas build --platform ios --profile development-simulator` | no Apple account |

`npm run verify` runs an offline check of the configuration (identifiers, icon rules, EAS profiles, dependencies, routes).

**Before your first iOS build**, change `ios.bundleIdentifier` and `android.package` in `app.json` (both `app.majesto.mobile`) to a reverse-domain name you control, for example `com.yourname.majesto`. Bundle identifiers are globally unique per Apple team, and changing one later means a new app.

## Before you ship

- The icon and splash in `assets/` are a generated placeholder (the three goal rings). Swap in final artwork of the same sizes.
- Headings use the platform serif (Georgia on iOS, Noto Serif on Android). To use a bundled typeface, load it with `expo-font` and change `fonts.serif` in `src/ui/theme.ts`.
- Timer alerts use standard (inexact) Android alarms, so the alert can arrive a little late when the phone is in deep sleep. The on-screen timer is always exact. If you want exact delivery, add `android.permission.USE_EXACT_ALARM` and test on the target Android version.
