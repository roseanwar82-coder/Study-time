import { useMemo, useState } from 'react';
import { Pressable, StyleSheet, View } from 'react-native';
import { router } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { DRILLS } from '@/core/drills';
import { recommendedDrill, todaySummary, todayTasks, weekSeries, countsForDeck } from '@/core/stats';
import { computeStreak } from '@/core/streak';
import { MINUTE, formatDayLong, formatMinutes, greeting } from '@/core/time';
import { levelFromXp } from '@/core/xp';
import { haptic } from '@/services/haptics';
import { actions, useApp } from '@/store';
import { Button, type IconName } from '@/ui/Button';
import { useNow } from '@/ui/hooks';
import { TextField } from '@/ui/Inputs';
import { Card, Chip, IconButton, Screen, SectionHeader } from '@/ui/Layout';
import { Rings, WeekBars } from '@/ui/Progress';
import { Txt } from '@/ui/Text';
import { areaColor, colors, radius, space } from '@/ui/theme';

export default function Today() {
  const state = useApp((s) => s);
  const now = useNow(true, 30_000);

  const summary = useMemo(() => todaySummary(state, now), [state, now]);
  const streak = useMemo(() => computeStreak(state.activity, summary.key), [state.activity, summary.key]);
  const tasks = useMemo(() => todayTasks(state, summary.key), [state, summary.key]);
  const week = useMemo(() => weekSeries(state, now), [state, now]);
  const due = useMemo(() => countsForDeck(state, null, now), [state, now]);
  const drill = DRILLS[recommendedDrill(state)];
  const goals = state.settings;
  const name = state.profile.name;

  return (
    <Screen>
      <View style={styles.header}>
        <View style={{ flex: 1, gap: 4 }}>
          <Txt variant="small" color="textDim">{formatDayLong(now)}</Txt>
          <Txt variant="display">{name ? `${greeting(now)}, ${name}` : greeting(now)}</Txt>
        </View>
        <Pressable onPress={() => router.push('/profile')} accessibilityRole="button" accessibilityLabel="Open profile" style={styles.level}>
          <Txt variant="caption" color="textDim">Level</Txt>
          <Txt variant="heading">{levelFromXp(state.xp)}</Txt>
        </Pressable>
      </View>

      <Card>
        <View style={styles.ringsRow}>
          <Rings
            size={136}
            stroke={11}
            rings={[
              { ratio: summary.focusRatio, color: areaColor.focus },
              { ratio: summary.reviewRatio, color: areaColor.recall },
              { ratio: summary.drillRatio, color: areaColor.drills },
            ]}
          >
            <Txt variant="title">{Math.round(summary.overall * 100)}%</Txt>
            <Txt variant="caption" color="textDim">of today</Txt>
          </Rings>
          <View style={{ flex: 1, gap: space.md }}>
            <GoalRow color={areaColor.focus} label="Focus" value={`${formatMinutes(summary.focusMs)} / ${formatMinutes(goals.dailyFocusGoalMin * MINUTE)}`} />
            <GoalRow color={areaColor.recall} label="Recall" value={`${summary.reviews} / ${goals.dailyReviewGoal} cards`} />
            <GoalRow color={areaColor.drills} label="Drills" value={`${summary.drills} / ${goals.dailyDrillGoal}`} />
          </View>
        </View>
        <View style={styles.streakRow}>
          <Ionicons name="flame" size={18} color={streak.current > 0 ? colors.gold : colors.textFaint} />
          <Txt variant="small" color={streak.current > 0 ? 'text' : 'textDim'} style={{ flex: 1 }}>
            {streak.current === 0
              ? 'Start a streak with any focus block, 10 cards or a drill.'
              : `${streak.current} day streak${streak.atRisk ? '. Do one thing today to keep it.' : ''}`}
          </Txt>
        </View>
      </Card>

      <View style={{ gap: space.md }}>
        <SectionHeader title="Next up" />
        {due.total > 0 ? (
          <NextCard
            icon="layers"
            tint={areaColor.recall}
            title={`${due.total} card${due.total === 1 ? '' : 's'} ready`}
            subtitle={[due.review && `${due.review} due`, due.learning && `${due.learning} learning`, due.new && `${due.new} new`].filter(Boolean).join(', ')}
            onPress={() => router.push('/review/all')}
          />
        ) : null}
        <NextCard
          icon="timer"
          tint={areaColor.focus}
          title={state.timer ? 'Timer running' : `Start a ${goals.focusMin} minute block`}
          subtitle={state.timer ? 'Jump back in' : 'One thing, no distractions'}
          onPress={() => router.push('/focus')}
        />
        <NextCard
          icon="flash"
          tint={areaColor.drills}
          title={drill.title}
          subtitle={`${drill.domain}. ${drill.blurb}`}
          onPress={() => router.push(`/drill/${drill.kind}`)}
        />
      </View>

      <Intentions tasks={tasks} />

      <Card>
        <SectionHeader title="This week" />
        <View style={{ height: space.lg }} />
        <WeekBars days={week} />
      </Card>
    </Screen>
  );
}

function GoalRow({ color, label, value }: { color: string; label: string; value: string }) {
  return (
    <View style={{ gap: 2 }}>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
        <View style={[styles.dot, { backgroundColor: color }]} />
        <Txt variant="small" color="textDim">{label}</Txt>
      </View>
      <Txt variant="body" style={{ fontWeight: '600', marginLeft: 16 }}>{value}</Txt>
    </View>
  );
}

function NextCard({ icon, tint, title, subtitle, onPress }: {
  icon: IconName; tint: string; title: string; subtitle: string; onPress: () => void;
}) {
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={title}
      onPress={() => {
        haptic.tap();
        onPress();
      }}
      style={({ pressed }) => [styles.next, pressed && { opacity: 0.85 }]}
    >
      <View style={[styles.nextIcon, { backgroundColor: tint + '22' }]}>
        <Ionicons name={icon} size={20} color={tint} />
      </View>
      <View style={{ flex: 1, gap: 2 }}>
        <Txt style={{ fontWeight: '700' }}>{title}</Txt>
        <Txt variant="small" color="textDim" numberOfLines={2}>{subtitle}</Txt>
      </View>
      <Ionicons name="chevron-forward" size={18} color={colors.textFaint} />
    </Pressable>
  );
}

function Intentions({ tasks }: { tasks: ReturnType<typeof todayTasks> }) {
  const [draft, setDraft] = useState('');
  const open = tasks.filter((t) => !t.doneAt).length;

  const add = () => {
    if (actions.addTask(draft)) {
      haptic.tap();
      setDraft('');
    }
  };

  return (
    <View style={{ gap: space.md }}>
      <SectionHeader title="Today's intentions" action={tasks.length ? <Txt variant="small" color="textDim">{open} open</Txt> : undefined} />
      {tasks.length === 0 ? (
        <Txt variant="small" color="textDim">Name the one thing that would make today a good day.</Txt>
      ) : (
        <View style={styles.list}>
          {tasks.map((t, i) => (
            <View key={t.id} style={[styles.taskRow, i > 0 && styles.taskDivider]}>
              <Pressable
                accessibilityRole="checkbox"
                accessibilityState={{ checked: !!t.doneAt }}
                accessibilityLabel={t.title}
                hitSlop={8}
                onPress={() => {
                  haptic.press();
                  actions.toggleTask(t.id);
                }}
                style={[styles.check, t.doneAt ? { backgroundColor: colors.success, borderColor: colors.success } : null]}
              >
                {t.doneAt ? <Ionicons name="checkmark" size={16} color={colors.onAccent} /> : null}
              </Pressable>
              <View style={{ flex: 1, gap: 2 }}>
                <Txt style={t.doneAt ? { color: colors.textFaint, textDecorationLine: 'line-through' } : undefined}>{t.title}</Txt>
                {t.focusMs >= MINUTE ? <Txt variant="caption" color="textDim">{formatMinutes(t.focusMs)} focused</Txt> : null}
              </View>
              <IconButton icon="close" label={`Delete ${t.title}`} color={colors.textFaint} size={18} onPress={() => actions.deleteTask(t.id)} />
            </View>
          ))}
        </View>
      )}
      <View style={{ flexDirection: 'row', gap: space.sm, alignItems: 'flex-end' }}>
        <View style={{ flex: 1 }}>
          <TextField
            placeholder="Add an intention"
            value={draft}
            onChangeText={setDraft}
            onSubmitEditing={add}
            returnKeyType="done"
            maxLength={120}
          />
        </View>
        <Button title="Add" variant="secondary" onPress={add} disabled={!draft.trim()} style={{ height: 48 }} />
      </View>
      {tasks.length > 0 && open > 0 ? <Chip label="Focus on one of these from the Focus tab" onPress={() => router.push('/focus')} /> : null}
    </View>
  );
}

const styles = StyleSheet.create({
  header: { flexDirection: 'row', alignItems: 'flex-start', gap: space.md },
  level: {
    alignItems: 'center',
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.border,
    backgroundColor: colors.surface,
  },
  ringsRow: { flexDirection: 'row', alignItems: 'center', gap: space.xl },
  streakRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: space.sm,
    marginTop: space.lg,
    paddingTop: space.md,
    borderTopWidth: 1,
    borderTopColor: colors.border,
  },
  dot: { width: 8, height: 8, borderRadius: 4 },
  next: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: space.md,
    backgroundColor: colors.surface,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.border,
    padding: space.md,
  },
  nextIcon: { width: 40, height: 40, borderRadius: radius.sm + 2, alignItems: 'center', justifyContent: 'center' },
  list: { backgroundColor: colors.surface, borderRadius: radius.md, borderWidth: 1, borderColor: colors.border, paddingHorizontal: space.md },
  taskRow: { flexDirection: 'row', alignItems: 'center', gap: space.md, paddingVertical: space.md },
  taskDivider: { borderTopWidth: 1, borderTopColor: colors.border },
  check: { width: 24, height: 24, borderRadius: 12, borderWidth: 2, borderColor: colors.textFaint, alignItems: 'center', justifyContent: 'center' },
});
