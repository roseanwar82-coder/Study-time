import { useEffect } from 'react';
import { AppState, View } from 'react-native';
import { Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import * as SplashScreen from 'expo-splash-screen';
import { initNotifications } from '@/services/notifications';
import { bootstrap, flushNow, useApp } from '@/store';
import { colors } from '@/ui/theme';
import { GuardController } from '@/ui/GuardController';
import { TimerWatcher } from '@/ui/TimerWatcher';
import { ToastHost } from '@/ui/Toasts';

SplashScreen.preventAutoHideAsync().catch(() => {});

export default function RootLayout() {
  const hydrated = useApp((s) => s.hydrated);

  useEffect(() => {
    bootstrap().catch(() => {});
    initNotifications().catch(() => {});
  }, []);

  useEffect(() => {
    if (hydrated) SplashScreen.hideAsync().catch(() => {});
  }, [hydrated]);

  // Make sure the latest changes are on disk whenever the app leaves the foreground.
  useEffect(() => {
    const sub = AppState.addEventListener('change', (state) => {
      if (state !== 'active') flushNow().catch(() => {});
    });
    return () => sub.remove();
  }, []);

  if (!hydrated) return <View style={{ flex: 1, backgroundColor: colors.bg }} />;

  return (
    <SafeAreaProvider>
      <StatusBar style="light" />
      <Stack screenOptions={{ headerShown: false, contentStyle: { backgroundColor: colors.bg } }}>
        <Stack.Screen name="(tabs)" />
        <Stack.Screen name="onboarding" options={{ gestureEnabled: false, animation: 'fade' }} />
        <Stack.Screen name="deck/[id]" />
        <Stack.Screen name="review/[deckId]" options={{ gestureEnabled: false, animation: 'slide_from_bottom' }} />
        <Stack.Screen name="drill/[kind]" options={{ gestureEnabled: false, animation: 'slide_from_bottom' }} />
        <Stack.Screen name="focus-guard" />
        <Stack.Screen name="blocked-apps" />
        <Stack.Screen name="assist" options={{ animation: 'slide_from_bottom' }} />
      </Stack>
      <TimerWatcher />
      <GuardController />
      <ToastHost />
    </SafeAreaProvider>
  );
}
