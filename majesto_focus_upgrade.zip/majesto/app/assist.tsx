import { useCallback, useEffect, useRef, useState } from 'react';
import { ActivityIndicator, AppState, Image, Pressable, StyleSheet, View } from 'react-native';
import { router } from 'expo-router';
import * as Clipboard from 'expo-clipboard';
import * as ImagePicker from 'expo-image-picker';
import { Ionicons } from '@expo/vector-icons';
import { describeError, type TutorImage, type TutorMessage } from '@/core/ai';
import { remainingMs } from '@/core/focus';
import { formatClock } from '@/core/time';
import { aiConfigured, askAi } from '@/services/ai';
import { focusGuard } from '@/services/focusGuard';
import { haptic } from '@/services/haptics';
import { useApp } from '@/store';
import { Button } from '@/ui/Button';
import { useNow } from '@/ui/hooks';
import { TextField } from '@/ui/Inputs';
import { Card, IconButton, Screen } from '@/ui/Layout';
import { Txt } from '@/ui/Text';
import { areaColor, colors, radius, space } from '@/ui/theme';

/** The conversation survives closing and reopening this screen while the app stays open. */
let saved: TutorMessage[] = [];

export default function Assist() {
  const timer = useApp((s) => s.timer);
  const now = useNow(!!timer && timer.pausedAt === null, 1000);

  const [messages, setMessages] = useState<TutorMessage[]>(saved);
  const [input, setInput] = useState('');
  const [image, setImage] = useState<TutorImage | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState<number | null>(null);
  const busy = useRef(false);

  useEffect(() => {
    saved = messages;
  }, [messages]);

  /** Picks up a screenshot or shared picture that was waiting for this screen. */
  const intakePicture = useCallback(async () => {
    const path = focusGuard.takePendingImage();
    if (!path) return;
    try {
      const base64 = await focusGuard.readImageBase64(path);
      setImage({ mediaType: 'image/jpeg', base64 });
      setError(null);
    } catch {
      setError('Could not open that picture. Try capturing it again.');
    } finally {
      focusGuard.deleteImage(path);
    }
  }, []);

  useEffect(() => {
    intakePicture();
    const sub = AppState.addEventListener('change', (s) => {
      if (s === 'active') intakePicture();
    });
    const offs = [
      focusGuard.on('onScreenshot', (e) => {
        if (e.error === 'denied') setError('Screen capture was cancelled. Nothing was captured.');
        else if (e.error) setError('Could not capture the screen. You can upload a screenshot instead.');
        else intakePicture();
      }),
      focusGuard.on('onSharedImage', (e) => (e.error ? setError('Could not read the shared picture.') : intakePicture())),
    ];
    return () => {
      sub.remove();
      offs.forEach((off) => off());
    };
  }, [intakePicture]);

  const send = async (text: string, detail: 'brief' | 'detailed') => {
    if (busy.current) return;
    const userMsg: TutorMessage = { role: 'user', text: text.trim(), ...(image ? { image } : {}) };
    busy.current = true;
    setLoading(true);
    setError(null);
    try {
      const res = await askAi({ detail, messages: [...messages, userMsg] });
      setMessages((m) => [...m, userMsg, { role: 'assistant', text: res.answer }]);
      setInput('');
      setImage(null);
      haptic.success();
    } catch (e) {
      setError(describeError(e));
    } finally {
      busy.current = false;
      setLoading(false);
    }
  };

  const pickImage = async () => {
    try {
      const res = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ['images'], base64: true, quality: 0.7 });
      const a = res.canceled ? null : res.assets[0];
      if (!a?.base64) return;
      const type = a.mimeType === 'image/png' || a.mimeType === 'image/webp' ? a.mimeType : 'image/jpeg';
      setImage({ mediaType: type, base64: a.base64 });
      setError(null);
    } catch {
      setError('Could not open your photos.');
    }
  };

  const paste = async () => {
    try {
      const text = await Clipboard.getStringAsync();
      if (text.trim()) setInput((v) => (v ? `${v}\n${text}` : text));
    } catch {
      setError('Could not read the clipboard.');
    }
  };

  const copy = async (text: string, index: number) => {
    await Clipboard.setStringAsync(text);
    setCopied(index);
    setTimeout(() => setCopied((c) => (c === index ? null : c)), 1500);
  };

  const newQuestion = () => {
    setMessages([]);
    setInput('');
    setImage(null);
    setError(null);
  };

  const backToStudying = () => {
    if (timer && focusGuard.isSupported) focusGuard.minimizeApp();
    else router.back();
  };

  const configured = aiConfigured();
  const asking = messages.length === 0;
  const canSend = !loading && configured && (input.trim().length > 0 || !!image);
  const lastIsAnswer = messages.length > 0 && messages[messages.length - 1].role === 'assistant';

  return (
    <Screen edges={['top', 'bottom']}>
      <View style={styles.top}>
        <IconButton icon="chevron-back" label="Back" color={colors.text} onPress={() => router.back()} />
        <View style={{ flex: 1 }} />
        {timer ? (
          <View style={styles.pill}>
            <Ionicons name={timer.pausedAt !== null ? 'pause' : 'timer-outline'} size={14} color={areaColor.focus} />
            <Txt variant="small" style={{ color: areaColor.focus, fontWeight: '700' }}>{formatClock(remainingMs(timer, now))}</Txt>
          </View>
        ) : null}
      </View>

      <Txt variant="display">AI help</Txt>
      {timer ? <Txt variant="small" color="textDim">Your timer keeps running while you ask.</Txt> : null}

      {!configured ? (
        <Card tint={colors.gold} style={{ gap: space.sm }}>
          <Txt style={{ fontWeight: '700' }}>AI help is not set up yet</Txt>
          <Txt variant="small" color="textDim">Add the address of your AI backend to turn it on. Nothing is sent anywhere until then.</Txt>
          <Button title="Set it up" variant="secondary" onPress={() => router.push('/focus-guard')} />
        </Card>
      ) : null}

      {messages.map((m, i) =>
        m.role === 'user' ? (
          <View key={i} style={styles.question}>
            {m.image ? <Txt variant="caption" color="textDim">Picture attached</Txt> : null}
            {m.text ? <Txt>{m.text}</Txt> : null}
          </View>
        ) : (
          <Card key={i} tint={areaColor.focus} style={{ gap: space.md }}>
            <Txt selectable>{m.text}</Txt>
            <View style={styles.row}>
              <Button title={copied === i ? 'Copied' : 'Copy answer'} icon="copy-outline" variant="secondary" onPress={() => copy(m.text, i)} />
              {i === messages.length - 1 ? (
                <Button title="More detail" variant="secondary" disabled={loading} onPress={() => send('Explain that in more detail, step by step.', 'detailed')} />
              ) : null}
            </View>
          </Card>
        ),
      )}

      {loading ? (
        <View style={styles.loading}>
          <ActivityIndicator color={colors.gold} />
          <Txt variant="small" color="textDim">Working on it...</Txt>
        </View>
      ) : null}

      {error ? (
        <Card style={{ borderColor: colors.danger + '88', gap: space.sm }}>
          <Txt variant="small" style={{ color: colors.danger }}>{error}</Txt>
        </Card>
      ) : null}

      <View style={{ gap: space.md }}>
        {image ? (
          <View style={styles.preview}>
            <Image source={{ uri: `data:${image.mediaType};base64,${image.base64}` }} style={styles.thumb} resizeMode="cover" />
            <Txt variant="small" color="textDim" style={{ flex: 1 }}>Picture ready. It is sent only when you press {asking ? 'Ask' : 'Send'}.</Txt>
            <IconButton icon="close-circle" label="Remove picture" onPress={() => setImage(null)} />
          </View>
        ) : null}
        <TextField
          placeholder={asking ? 'Type or paste your question' : 'Ask a follow-up'}
          value={input}
          onChangeText={setInput}
          multiline
          maxLength={6000}
        />
        <View style={styles.row}>
          <Button title="Paste" icon="clipboard-outline" variant="secondary" onPress={paste} />
          <Button title="Upload image" icon="image-outline" variant="secondary" onPress={pickImage} />
          {focusGuard.isSupported ? (
            <Button title="Capture screen" icon="scan-outline" variant="secondary" onPress={() => focusGuard.captureScreen(true)} />
          ) : null}
        </View>
        <Button title={asking ? 'Ask' : 'Send'} icon="sparkles-outline" size="lg" disabled={!canSend} loading={loading} onPress={() => send(input || 'Please solve the question in this picture.', 'brief')} />
        {!asking ? (
          <View style={styles.row}>
            {lastIsAnswer ? <Button title="New question" variant="ghost" onPress={newQuestion} /> : null}
          </View>
        ) : null}
        {timer ? <Button title="Back to studying" variant="ghost" onPress={backToStudying} /> : null}
      </View>
    </Screen>
  );
}

const styles = StyleSheet.create({
  top: { flexDirection: 'row', alignItems: 'center' },
  pill: { flexDirection: 'row', alignItems: 'center', gap: 6, paddingHorizontal: 12, paddingVertical: 6, borderRadius: radius.pill, borderWidth: 1, borderColor: areaColor.focus + '66' },
  row: { flexDirection: 'row', flexWrap: 'wrap', gap: space.sm },
  question: { alignSelf: 'flex-end', maxWidth: '88%', backgroundColor: colors.surfaceHi, borderRadius: radius.md, padding: space.md, gap: 4 },
  loading: { flexDirection: 'row', alignItems: 'center', gap: space.sm },
  preview: { flexDirection: 'row', alignItems: 'center', gap: space.md, backgroundColor: colors.surface, borderRadius: radius.md, borderWidth: 1, borderColor: colors.border, padding: space.sm },
  thumb: { width: 56, height: 56, borderRadius: radius.sm },
});
