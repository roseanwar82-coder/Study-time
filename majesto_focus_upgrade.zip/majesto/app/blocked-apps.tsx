import { useEffect, useMemo, useState } from 'react';
import { ActivityIndicator, FlatList, Image, Pressable, StyleSheet, View } from 'react-native';
import { router } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { focusGuard, type InstalledApp } from '@/services/focusGuard';
import { actions, useApp } from '@/store';
import { Button } from '@/ui/Button';
import { TextField } from '@/ui/Inputs';
import { EmptyState, IconButton, Screen } from '@/ui/Layout';
import { Txt } from '@/ui/Text';
import { colors, radius, space } from '@/ui/theme';

export default function BlockedApps() {
  const blocked = useApp((s) => s.settings.blockedApps);
  const [apps, setApps] = useState<InstalledApp[] | null>(null);
  const [failed, setFailed] = useState(false);
  const [query, setQuery] = useState('');

  useEffect(() => {
    let alive = true;
    focusGuard
      .listApps()
      .then((list) => alive && setApps(list))
      .catch(() => alive && setFailed(true));
    return () => {
      alive = false;
    };
  }, []);

  const selected = useMemo(() => new Set(blocked), [blocked]);

  const rows = useMemo(() => {
    if (!apps) return [];
    const q = query.trim().toLowerCase();
    const list = q ? apps.filter((a) => a.label.toLowerCase().includes(q) || a.packageName.toLowerCase().includes(q)) : apps;
    // Chosen apps first, then A to Z.
    return list.slice().sort((a, b) => Number(selected.has(b.packageName)) - Number(selected.has(a.packageName)) || a.label.localeCompare(b.label));
  }, [apps, query, selected]);

  const toggle = (pkg: string) => {
    actions.updateSettings({ blockedApps: selected.has(pkg) ? blocked.filter((p) => p !== pkg) : [...blocked, pkg] });
  };

  return (
    <Screen scroll={false} edges={['top', 'bottom']}>
      <View style={styles.top}>
        <IconButton icon="chevron-back" label="Back" color={colors.text} onPress={() => router.back()} />
        <View style={{ flex: 1 }} />
        {blocked.length > 0 ? <Button title="Clear all" variant="ghost" onPress={() => actions.updateSettings({ blockedApps: [] })} /> : null}
      </View>
      <View style={{ gap: 4 }}>
        <Txt variant="display">Block apps</Txt>
        <Txt color="textDim">
          {blocked.length === 0 ? 'Choose the apps that distract you.' : `${blocked.length} chosen.`} They are covered during focus blocks. Your phone, settings and Majesto are never blocked.
        </Txt>
      </View>
      <TextField placeholder="Search apps" value={query} onChangeText={setQuery} autoCorrect={false} autoCapitalize="none" />

      {failed ? (
        <EmptyState icon="alert-circle-outline" title="Could not load your apps" body="Android did not return the list of installed apps. Close this screen and try again." />
      ) : apps === null ? (
        <View style={{ paddingVertical: space.xxl }}><ActivityIndicator color={colors.gold} /></View>
      ) : rows.length === 0 ? (
        <EmptyState icon="search-outline" title="No apps found" body={query ? 'Try a different search.' : 'No launchable apps were returned.'} />
      ) : (
        <FlatList
          data={rows}
          keyExtractor={(a) => a.packageName}
          style={{ flex: 1 }}
          keyboardShouldPersistTaps="handled"
          initialNumToRender={14}
          renderItem={({ item }) => {
            const on = selected.has(item.packageName);
            return (
              <Pressable
                accessibilityRole="checkbox"
                accessibilityState={{ checked: on }}
                accessibilityLabel={item.label}
                onPress={() => toggle(item.packageName)}
                style={({ pressed }) => [styles.row, pressed && { opacity: 0.7 }]}
              >
                {item.icon ? (
                  <Image source={{ uri: `data:image/png;base64,${item.icon}` }} style={styles.icon} />
                ) : (
                  <View style={[styles.icon, { backgroundColor: colors.surfaceHi }]} />
                )}
                <View style={{ flex: 1 }}>
                  <Txt numberOfLines={1} style={{ fontWeight: on ? '700' : '500' }}>{item.label}</Txt>
                  <Txt variant="caption" color="textFaint" numberOfLines={1}>{item.packageName}</Txt>
                </View>
                <View style={[styles.check, on && { backgroundColor: colors.gold, borderColor: colors.gold }]}>
                  {on ? <Ionicons name="checkmark" size={16} color={colors.onAccent} /> : null}
                </View>
              </Pressable>
            );
          }}
        />
      )}
    </Screen>
  );
}

const styles = StyleSheet.create({
  top: { flexDirection: 'row', alignItems: 'center' },
  row: { flexDirection: 'row', alignItems: 'center', gap: space.md, paddingVertical: 10, borderBottomWidth: 1, borderBottomColor: colors.border },
  icon: { width: 40, height: 40, borderRadius: radius.sm },
  check: { width: 26, height: 26, borderRadius: 8, borderWidth: 1.5, borderColor: colors.border, alignItems: 'center', justifyContent: 'center' },
});
