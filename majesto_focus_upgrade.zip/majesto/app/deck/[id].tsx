import { useMemo, useState } from 'react';
import { Alert, Pressable, StyleSheet, View } from 'react-native';
import { router, useLocalSearchParams } from 'expo-router';
import { dueLabel, parseBulkCards } from '@/core/srs';
import { countsForDeck } from '@/core/stats';
import type { Card as CardModel } from '@/core/types';
import { actions, useApp } from '@/store';
import { Button } from '@/ui/Button';
import { useNow } from '@/ui/hooks';
import { TextField } from '@/ui/Inputs';
import { EmptyState, IconButton, Screen } from '@/ui/Layout';
import { Sheet } from '@/ui/Sheet';
import { Txt } from '@/ui/Text';
import { areaColor, colors, radius, space } from '@/ui/theme';

export default function DeckScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const state = useApp((s) => s);
  const now = useNow(true, 30_000);
  const deck = state.decks.find((d) => d.id === id);

  const [query, setQuery] = useState('');
  const [editing, setEditing] = useState<CardModel | 'new' | null>(null);
  const [importing, setImporting] = useState(false);

  const cards = useMemo(() => state.cards.filter((c) => c.deckId === id), [state.cards, id]);
  const counts = useMemo(() => countsForDeck(state, id ?? null, now), [state, id, now]);
  const shown = useMemo(() => {
    const q = query.trim().toLowerCase();
    const list = q ? cards.filter((c) => c.front.toLowerCase().includes(q) || c.back.toLowerCase().includes(q)) : cards;
    return list.slice().sort((a, b) => b.createdAt - a.createdAt);
  }, [cards, query]);

  if (!deck) {
    return (
      <Screen edges={['top', 'bottom']}>
        <EmptyState icon="alert-circle-outline" title="Deck not found" body="It may have been deleted." action={<Button title="Back" onPress={() => router.back()} />} />
      </Screen>
    );
  }

  const confirmDelete = () =>
    Alert.alert(`Delete "${deck.name}"?`, `This also deletes its ${cards.length} card${cards.length === 1 ? '' : 's'} and their review history.`, [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Delete deck',
        style: 'destructive',
        onPress: () => {
          actions.deleteDeck(deck.id);
          router.back();
        },
      },
    ]);

  return (
    <Screen edges={['top', 'bottom']}>
      <View style={styles.top}>
        <IconButton icon="chevron-back" label="Back" color={colors.text} onPress={() => router.back()} />
        <View style={{ flex: 1 }} />
        <IconButton icon="trash-outline" label="Delete deck" onPress={confirmDelete} />
      </View>

      <View style={{ gap: 6 }}>
        <View style={[styles.bar, { backgroundColor: deck.color }]} />
        <Txt variant="display">{deck.name}</Txt>
        <Txt variant="small" color="textDim">
          {cards.length} card{cards.length === 1 ? '' : 's'}. {counts.review} due, {counts.learning} learning, {counts.new} new today.
        </Txt>
      </View>

      <View style={styles.actions}>
        <Button title="Review" icon="play" tint={deck.color} disabled={counts.total === 0} onPress={() => router.push(`/review/${deck.id}`)} style={{ flex: 1 }} />
        <Button title="Add card" icon="add" variant="secondary" onPress={() => setEditing('new')} style={{ flex: 1 }} />
        <Button title="Import" variant="secondary" onPress={() => setImporting(true)} />
      </View>

      {cards.length > 6 ? <TextField placeholder="Search cards" value={query} onChangeText={setQuery} autoCorrect={false} /> : null}

      {cards.length === 0 ? (
        <EmptyState
          icon="albums-outline"
          title="No cards yet"
          body="Write a question on the front and the answer on the back. Short and specific works best."
          action={<Button title="Add the first card" tint={areaColor.recall} onPress={() => setEditing('new')} />}
        />
      ) : shown.length === 0 ? (
        <Txt color="textDim">No cards match "{query}".</Txt>
      ) : (
        <View style={{ gap: space.sm }}>
          {shown.map((c) => (
            <Pressable key={c.id} accessibilityRole="button" onPress={() => setEditing(c)} style={({ pressed }) => [styles.card, pressed && { opacity: 0.85 }]}>
              <View style={{ flex: 1, gap: 4 }}>
                <Txt style={{ fontWeight: '600' }} numberOfLines={2}>{c.front}</Txt>
                <Txt variant="small" color="textDim" numberOfLines={2}>{c.back}</Txt>
              </View>
              <Txt variant="caption" color={dueLabel(c.srs, now) === 'Due' ? 'sage' : 'textFaint'}>{dueLabel(c.srs, now)}</Txt>
            </Pressable>
          ))}
        </View>
      )}

      <CardSheet deckId={deck.id} target={editing} onClose={() => setEditing(null)} />
      <ImportSheet deckId={deck.id} visible={importing} onClose={() => setImporting(false)} />
    </Screen>
  );
}

function CardSheet({ deckId, target, onClose }: { deckId: string; target: CardModel | 'new' | null; onClose: () => void }) {
  const existing = target && target !== 'new' ? target : null;
  const [front, setFront] = useState('');
  const [back, setBack] = useState('');
  const [loadedId, setLoadedId] = useState<string | null>(null);

  // Load the card into the form each time the sheet opens on a different card.
  const key = target === null ? null : existing ? existing.id : 'new';
  if (key !== loadedId) {
    setLoadedId(key);
    setFront(existing?.front ?? '');
    setBack(existing?.back ?? '');
  }

  const valid = front.trim().length > 0 && back.trim().length > 0;

  const save = (another: boolean) => {
    if (!valid) return;
    if (existing) {
      actions.updateCard(existing.id, front, back);
      onClose();
      return;
    }
    actions.addCard(deckId, front, back);
    if (another) {
      setFront('');
      setBack('');
    } else {
      onClose();
    }
  };

  return (
    <Sheet visible={target !== null} onClose={onClose} title={existing ? 'Edit card' : 'New card'}>
      <TextField label="Front" placeholder="Question or prompt" value={front} onChangeText={setFront} multiline autoFocus={!existing} />
      <TextField label="Back" placeholder="Answer" value={back} onChangeText={setBack} multiline />
      <Button title={existing ? 'Save changes' : 'Add card'} tint={areaColor.recall} size="lg" disabled={!valid} onPress={() => save(false)} />
      {!existing ? <Button title="Add and write another" variant="secondary" disabled={!valid} onPress={() => save(true)} /> : null}
      {existing ? (
        <Button
          title="Delete card"
          variant="danger"
          onPress={() => {
            actions.deleteCard(existing.id);
            onClose();
          }}
        />
      ) : null}
    </Sheet>
  );
}

function ImportSheet({ deckId, visible, onClose }: { deckId: string; visible: boolean; onClose: () => void }) {
  const [text, setText] = useState('');
  const parsed = useMemo(() => parseBulkCards(text), [text]);

  const run = () => {
    actions.addCards(deckId, parsed.cards);
    setText('');
    onClose();
  };

  return (
    <Sheet visible={visible} onClose={onClose} title="Import cards">
      <Txt variant="small" color="textDim">One card per line: front :: back. Paste from a spreadsheet and tab-separated lines work too.</Txt>
      <TextField placeholder={'Capital of France :: Paris\nH2O :: Water'} value={text} onChangeText={setText} multiline autoCapitalize="none" autoCorrect={false} style={{ minHeight: 160 }} />
      {text.trim() ? (
        <Txt variant="small" color={parsed.cards.length ? 'sage' : 'danger'}>
          {parsed.cards.length} card{parsed.cards.length === 1 ? '' : 's'} ready{parsed.skipped ? `, ${parsed.skipped} line${parsed.skipped === 1 ? '' : 's'} skipped (need a separator)` : ''}
        </Txt>
      ) : null}
      <Button title={`Import ${parsed.cards.length || ''} cards`.replace('  ', ' ')} tint={areaColor.recall} size="lg" disabled={parsed.cards.length === 0} onPress={run} />
    </Sheet>
  );
}

const styles = StyleSheet.create({
  top: { flexDirection: 'row', alignItems: 'center', marginBottom: -space.sm },
  bar: { width: 44, height: 4, borderRadius: 2 },
  actions: { flexDirection: 'row', gap: space.sm },
  card: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: space.md,
    backgroundColor: colors.surface,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.border,
    padding: space.md,
  },
});
