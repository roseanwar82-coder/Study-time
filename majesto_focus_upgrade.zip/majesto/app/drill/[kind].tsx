import { useState, type JSX } from 'react';
import { StyleSheet, View } from 'react-native';
import { router, useLocalSearchParams } from 'expo-router';
import { DRILLS, isDrillKind } from '@/core/drills';
import type { DrillKind } from '@/core/types';
import { NBackDrill } from '@/features/drills/NBackDrill';
import { SchulteDrill } from '@/features/drills/SchulteDrill';
import { SequenceDrill } from '@/features/drills/SequenceDrill';
import { SpanDrill } from '@/features/drills/SpanDrill';
import { StroopDrill } from '@/features/drills/StroopDrill';
import type { DrillFinish, DrillProps } from '@/features/drills/types';
import { haptic } from '@/services/haptics';
import { actions, useApp } from '@/store';
import type { DrillRecord } from '@/store/actions';
import { Button } from '@/ui/Button';
import { Card, Chip, EmptyState, IconButton, Screen } from '@/ui/Layout';
import { Txt } from '@/ui/Text';
import { areaColor, colors, space } from '@/ui/theme';

const GAMES: Record<DrillKind, (props: DrillProps) => JSX.Element> = {
  schulte: SchulteDrill,
  span: SpanDrill,
  nback: NBackDrill,
  stroop: StroopDrill,
  sequence: SequenceDrill,
};

export default function DrillScreen() {
  const { kind } = useLocalSearchParams<{ kind: string }>();
  if (!isDrillKind(kind)) {
    return (
      <Screen edges={['top', 'bottom']}>
        <EmptyState icon="alert-circle-outline" title="Unknown drill" body="That drill doesn't exist." action={<Button title="Back" onPress={() => router.back()} />} />
      </Screen>
    );
  }
  return <DrillShell kind={kind} />;
}

type Phase = 'intro' | 'playing' | 'result';

function DrillShell({ kind }: { kind: DrillKind }) {
  const meta = DRILLS[kind];
  const saved = useApp((s) => s.drills.levels[kind]);
  const stats = useApp((s) => s.drills.stats[kind]);

  const [level, setLevel] = useState(() => (meta.levels.some((l) => l.value === saved) ? (saved as number) : meta.defaultLevel));
  const [phase, setPhase] = useState<Phase>('intro');
  const [run, setRun] = useState(0);
  const [outcome, setOutcome] = useState<{ record: DrillRecord; finish: DrillFinish } | null>(null);

  const Game = GAMES[kind];

  const handleFinish = (finish: DrillFinish) => {
    const record = actions.recordDrill({
      kind,
      points: finish.points,
      summary: finish.summary,
      accuracy: finish.accuracy,
      durationMs: finish.durationMs,
      level,
      nextLevel: finish.nextLevel ?? level,
    });
    if (!record) return;
    if (record.isPersonalBest) haptic.success();
    setOutcome({ record, finish });
    setPhase('result');
  };

  if (phase === 'playing') {
    return (
      <Screen edges={['top', 'bottom']} scroll={false} contentStyle={{ gap: space.lg }}>
        <View style={styles.top}>
          <IconButton icon="close" label="Quit drill" color={colors.text} onPress={() => router.back()} />
          <Txt variant="heading">{meta.title}</Txt>
          <View style={{ width: 30 }} />
        </View>
        <Game key={run} level={level} onFinish={handleFinish} />
      </Screen>
    );
  }

  if (phase === 'result' && outcome) {
    const { record, finish } = outcome;
    const next = finish.nextLevel ?? level;
    const changed = next !== level;
    const nextLabel = meta.levels.find((l) => l.value === next)?.label;
    return (
      <Screen edges={['top', 'bottom']}>
        <View style={{ gap: space.sm, paddingTop: space.xl }}>
          <Txt variant="small" color="textDim">{meta.title}</Txt>
          <Txt variant="numeral" style={{ color: areaColor.drills }}>{record.result.points}</Txt>
          <Txt color="textDim">{finish.summary}</Txt>
        </View>
        <Card tint={areaColor.drills} style={{ gap: space.sm }}>
          <Row label="XP earned" value={`+${record.result.xp}`} />
          <Row label="Personal best" value={record.isPersonalBest ? 'New best' : String(Math.max(record.previousBest, record.result.points))} highlight={record.isPersonalBest} />
          {changed && nextLabel ? <Row label={`Next ${meta.levelName.toLowerCase()}`} value={nextLabel} /> : null}
        </Card>
        <View style={{ gap: space.md }}>
          <Button
            title="Play again"
            tint={areaColor.drills}
            size="lg"
            onPress={() => {
              setLevel(next);
              setRun((r) => r + 1);
              setPhase('playing');
            }}
          />
          <Button title="Done" variant="secondary" onPress={() => router.back()} />
        </View>
      </Screen>
    );
  }

  return (
    <Screen edges={['top', 'bottom']}>
      <View style={styles.top}>
        <IconButton icon="close" label="Close" color={colors.text} onPress={() => router.back()} />
        <View style={{ flex: 1 }} />
      </View>
      <View style={{ gap: space.sm }}>
        <Txt variant="caption" style={{ color: areaColor.drills, fontWeight: '700', letterSpacing: 1 }}>{meta.domain.toUpperCase()}</Txt>
        <Txt variant="display">{meta.title}</Txt>
        <Txt color="textDim">{meta.blurb}</Txt>
      </View>
      <View style={{ gap: space.sm }}>
        <Txt variant="heading">How it works</Txt>
        {meta.howTo.map((line, i) => (
          <Txt key={i} variant="small" color="textDim">{i + 1}. {line}</Txt>
        ))}
      </View>
      {meta.levels.length > 1 ? (
        <View style={{ gap: space.sm }}>
          <Txt variant="heading">{meta.levelName}</Txt>
          <View style={styles.chips}>
            {meta.levels.map((l) => (
              <Chip key={l.value} label={l.label} selected={level === l.value} tint={areaColor.drills} onPress={() => setLevel(l.value)} />
            ))}
          </View>
        </View>
      ) : null}
      {stats ? <Txt variant="small" color="textDim">Your best: {stats.best}. Played {stats.plays} time{stats.plays === 1 ? '' : 's'}.</Txt> : null}
      <Button title="Start" icon="play" tint={areaColor.drills} size="lg" onPress={() => setPhase('playing')} />
    </Screen>
  );
}

function Row({ label, value, highlight }: { label: string; value: string; highlight?: boolean }) {
  return (
    <View style={styles.row}>
      <Txt color="textDim">{label}</Txt>
      <Txt style={{ fontWeight: '700', color: highlight ? colors.gold : colors.text }}>{value}</Txt>
    </View>
  );
}

const styles = StyleSheet.create({
  top: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  chips: { flexDirection: 'row', flexWrap: 'wrap', gap: space.sm },
  row: { flexDirection: 'row', justifyContent: 'space-between' },
});
