import { useMemo, useRef, useState } from 'react';
import { Pressable, ScrollView, StyleSheet, View } from 'react-native';
import { router, useLocalSearchParams } from 'expo-router';
import { GRADES, buildQueue, previewIntervals } from '@/core/srs';
import { newCardsRemaining } from '@/core/stats';
import type { Grade } from '@/core/types';
import { haptic } from '@/services/haptics';
import { actions, store, useApp } from '@/store';
import { Button } from '@/ui/Button';
import { TextField } from '@/ui/Inputs';
import { EmptyState, IconButton, Screen } from '@/ui/Layout';
import { ProgressBar } from '@/ui/Progress';
import { Txt } from '@/ui/Text';
import { areaColor, colors, radius, space } from '@/ui/theme';

const GRADE_META: Record<Grade, { label: string; color: string }> = {
  again: { label: 'Again', color: colors.danger },
  hard: { label: 'Hard', color: colors.gold },
  good: { label: 'Good', color: colors.sage },
  easy: { label: 'Easy', color: colors.amethyst },
};

interface Tally {
  again: number;
  hard: number;
  good: number;
  easy: number;
  xp: number;
}

export default function Review() {
  const { deckId } = useLocalSearchParams<{ deckId: string }>();
  const typedRecall = useApp((s) => s.settings.typedRecall);

  // The queue is fixed when the session starts. Cards you miss are appended so they come back.
  const [queue, setQueue] = useState<string[]>(() => {
    const s = store.get();
    const now = Date.now();
    const cards = deckId === 'all' ? s.cards : s.cards.filter((c) => c.deckId === deckId);
    return buildQueue(cards, now, { newLimit: newCardsRemaining(s, now) });
  });
  const startedWith = useRef(queue.length);
  const [pos, setPos] = useState(0);
  const [revealed, setRevealed] = useState(false);
  const [typed, setTyped] = useState('');
  const [tally, setTally] = useState<Tally>({ again: 0, hard: 0, good: 0, easy: 0, xp: 0 });

  const card = useApp((s) => s.cards.find((c) => c.id === queue[pos]));
  const previews = useMemo(() => (card ? previewIntervals(card.srs, Date.now()) : null), [card, revealed]); // eslint-disable-line react-hooks/exhaustive-deps

  const answered = tally.again + tally.hard + tally.good + tally.easy;
  const finished = pos >= queue.length;

  const grade = (g: Grade) => {
    if (!card) return;
    const res = actions.gradeCard(card.id, g);
    if (!res) return;
    if (g === 'again') haptic.warn();
    else haptic.tap();
    setTally((t) => ({ ...t, [g]: t[g] + 1, xp: t.xp + res.xp }));
    if (res.card.srs.phase === 'learning') setQueue((q) => [...q, card.id]);
    setPos((p) => p + 1);
    setRevealed(false);
    setTyped('');
  };

  if (startedWith.current === 0) {
    return (
      <Screen edges={['top', 'bottom']}>
        <EmptyState
          icon="checkmark-circle-outline"
          title="Nothing to review"
          body="You're all caught up. New cards appear each day, and reviews come back when they're due."
          action={<Button title="Done" tint={areaColor.recall} onPress={() => router.back()} />}
        />
      </Screen>
    );
  }

  if (finished || !card) {
    const good = tally.good + tally.easy;
    return (
      <Screen edges={['top', 'bottom']} contentStyle={{ gap: space.xl }}>
        <View style={{ gap: space.sm, paddingTop: space.xxl }}>
          <Txt variant="display">Session complete</Txt>
          <Txt color="textDim">
            {answered} answer{answered === 1 ? '' : 's'}, {answered ? Math.round((good / answered) * 100) : 0}% recalled well. +{tally.xp} XP
          </Txt>
        </View>
        <View style={styles.summaryGrid}>
          {GRADES.map((g) => (
            <View key={g} style={styles.summaryCell}>
              <Txt variant="title" style={{ color: GRADE_META[g].color }}>{tally[g]}</Txt>
              <Txt variant="caption" color="textDim">{GRADE_META[g].label}</Txt>
            </View>
          ))}
        </View>
        <Button title="Done" tint={areaColor.recall} size="lg" onPress={() => router.back()} />
      </Screen>
    );
  }

  return (
    <Screen edges={['top', 'bottom']} scroll={false} contentStyle={{ gap: space.lg }}>
      <View style={styles.top}>
        <IconButton icon="close" label="End session" color={colors.text} onPress={() => router.back()} />
        <View style={{ flex: 1 }}>
          <ProgressBar ratio={pos / queue.length} color={areaColor.recall} />
        </View>
        <Txt variant="small" color="textDim">{pos + 1} / {queue.length}</Txt>
      </View>

      <ScrollView style={{ flex: 1 }} contentContainerStyle={styles.face} keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false}>
        <Txt variant="caption" color="textFaint" style={{ textAlign: 'center', letterSpacing: 1 }}>
          {card.srs.phase === 'new' ? 'NEW' : card.srs.phase === 'learning' ? 'LEARNING' : 'REVIEW'}
        </Txt>
        <Txt variant="cardFace">{card.front}</Txt>
        {revealed ? (
          <>
            <View style={styles.rule} />
            {typed.trim() ? (
              <View style={{ gap: 4, alignItems: 'center' }}>
                <Txt variant="caption" color="textFaint">YOUR ANSWER</Txt>
                <Txt variant="small" color="textDim" style={{ textAlign: 'center' }}>{typed.trim()}</Txt>
              </View>
            ) : null}
            <Txt variant="cardFace" style={{ color: areaColor.recall }}>{card.back}</Txt>
          </>
        ) : null}
      </ScrollView>

      {revealed ? (
        <View style={styles.grades}>
          {GRADES.map((g) => (
            <Pressable
              key={g}
              accessibilityRole="button"
              accessibilityLabel={`${GRADE_META[g].label}, next review in ${previews?.[g]}`}
              onPress={() => grade(g)}
              style={({ pressed }) => [styles.grade, { borderColor: GRADE_META[g].color + '88' }, pressed && { opacity: 0.8 }]}
            >
              <Txt variant="small" style={{ color: GRADE_META[g].color, fontWeight: '700' }}>{GRADE_META[g].label}</Txt>
              <Txt variant="caption" color="textDim">{previews?.[g]}</Txt>
            </Pressable>
          ))}
        </View>
      ) : (
        <View style={{ gap: space.md }}>
          {typedRecall ? (
            <TextField placeholder="Type what you remember (optional)" value={typed} onChangeText={setTyped} multiline style={{ minHeight: 64 }} />
          ) : null}
          <Button
            title="Show answer"
            tint={areaColor.recall}
            size="lg"
            onPress={() => {
              haptic.press();
              setRevealed(true);
            }}
          />
        </View>
      )}
    </Screen>
  );
}

const styles = StyleSheet.create({
  top: { flexDirection: 'row', alignItems: 'center', gap: space.md },
  face: { flexGrow: 1, justifyContent: 'center', gap: space.xl, paddingVertical: space.lg },
  rule: { height: 1, backgroundColor: colors.border, alignSelf: 'stretch' },
  grades: { flexDirection: 'row', gap: space.sm },
  grade: {
    flex: 1,
    alignItems: 'center',
    gap: 2,
    paddingVertical: 12,
    borderRadius: radius.md,
    borderWidth: 1,
    backgroundColor: colors.surface,
  },
  summaryGrid: { flexDirection: 'row', backgroundColor: colors.surface, borderRadius: radius.lg, borderWidth: 1, borderColor: colors.border, paddingVertical: space.lg },
  summaryCell: { flex: 1, alignItems: 'center' },
});
