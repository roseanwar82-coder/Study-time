// Majesto AI tutor backend. Zero dependencies, Node 18+.
// Holds the Gemini API key so it never ships inside the app. See README.md.
import http from 'node:http';
import { pathToFileURL } from 'node:url';

const TUTOR_PROMPT = `You are a patient, efficient academic tutor helping a student who is in the middle of a study session.
- Give the direct answer first when there is one, then explain.
- Explain concepts in simple language. Break complex problems into short numbered steps.
- Explain every formula and symbol you use. Show calculations for numerical problems, with units.
- Say why the answer is correct. Add one simple example when it helps.
- Cover Mathematics, Physics, Chemistry, Biology and other subjects. If an image is attached, read it carefully and say if part of it is unreadable instead of guessing.
- Write plain text only: no markdown tables, no LaTeX. Use Unicode for math (x², √, ÷, ×, ≈, →). Short lines and blank lines between steps.
- Be honest about uncertainty. Do not invent facts or sources.`;

const BRIEF = 'Keep it concise: aim for under 180 words unless the problem truly needs more. The student can ask for more detail.';
const DETAILED = 'Give a fuller explanation with every step worked out, and a worked example if useful.';

const IMAGE_TYPES = new Set(['image/jpeg', 'image/png', 'image/webp']);
const MAX_TEXT = 6000;
const MAX_MESSAGES = 12;
const MAX_IMAGE_BYTES = 5 * 1024 * 1024;
const MAX_BODY_BYTES = 8 * 1024 * 1024;

export function loadConfig(env = process.env) {
  return {
    apiKey: env.GEMINI_API_KEY ?? '',
    baseUrl: (env.GEMINI_BASE_URL ?? 'https://generativelanguage.googleapis.com').replace(/\/+$/, ''),
    model: env.GEMINI_MODEL ?? 'gemini-2.5-flash',
    appToken: env.APP_TOKEN ?? '',
    rateLimit: Number(env.RATE_LIMIT ?? 30), // requests per window per client
    rateWindowMs: Number(env.RATE_WINDOW_SEC ?? 600) * 1000,
    upstreamTimeoutMs: Number(env.UPSTREAM_TIMEOUT_SEC ?? 50) * 1000,
    trustProxy: env.TRUST_PROXY === '1',
  };
}

const fail = (status, code, message, extra = {}) => ({ status, body: { error: { code, message } }, ...extra });

/** Checks and normalises the request body. Returns { messages, detail } or an error result. */
export function parseRequest(body) {
  if (!body || typeof body !== 'object') return fail(400, 'invalid_request', 'Send a JSON body.');
  const detail = body.detail === 'detailed' ? 'detailed' : 'brief';
  const raw = body.messages;
  if (!Array.isArray(raw) || raw.length === 0 || raw.length > MAX_MESSAGES) {
    return fail(400, 'invalid_request', `Send between 1 and ${MAX_MESSAGES} messages.`);
  }
  const messages = [];
  for (const m of raw) {
    if (!m || (m.role !== 'user' && m.role !== 'assistant') || typeof m.text !== 'string') {
      return fail(400, 'invalid_request', 'Each message needs a role and text.');
    }
    if (m.text.length > MAX_TEXT) return fail(413, 'too_large', `Messages are limited to ${MAX_TEXT} characters.`);
    let image = null;
    if (m.image != null) {
      if (m.role !== 'user') return fail(400, 'invalid_request', 'Only user messages can carry an image.');
      const { mediaType, base64 } = m.image;
      if (!IMAGE_TYPES.has(mediaType) || typeof base64 !== 'string' || !/^[A-Za-z0-9+/]+={0,2}$/.test(base64)) {
        return fail(400, 'bad_image', 'The picture must be a JPEG, PNG or WebP image.');
      }
      if (Math.floor((base64.length * 3) / 4) > MAX_IMAGE_BYTES) return fail(413, 'too_large', 'That picture is too large. Try a smaller one.');
      image = { mediaType, base64 };
    }
    messages.push({ role: m.role, text: m.text.trim(), image });
  }
  if (messages[0].role !== 'user' || messages[messages.length - 1].role !== 'user') {
    return fail(400, 'invalid_request', 'The conversation must start and end with a user message.');
  }
  for (let i = 1; i < messages.length; i++) {
    if (messages[i].role === messages[i - 1].role) return fail(400, 'invalid_request', 'Messages must alternate between user and assistant.');
  }
  const last = messages[messages.length - 1];
  if (!last.text && !messages.some((m) => m.image)) return fail(400, 'invalid_request', 'Write a question or add a picture.');
  return { messages, detail };
}

export function toProviderMessages(messages) {
  return messages.map((m) => {
    const parts = [];
    if (m.image) parts.push({ inlineData: { mimeType: m.image.mediaType, data: m.image.base64 } });
    parts.push({ text: m.text || (m.image ? 'Please solve the question in this picture.' : '...') });
    return { role: m.role === 'assistant' ? 'model' : 'user', parts };
  });
}

async function callProvider(cfg, parsed, fetchImpl) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), cfg.upstreamTimeoutMs);
  try {
    const res = await fetchImpl(`${cfg.baseUrl}/v1beta/models/${encodeURIComponent(cfg.model)}:generateContent`, {
      method: 'POST',
      headers: { 'content-type': 'application/json', 'x-goog-api-key': cfg.apiKey },
      body: JSON.stringify({
        systemInstruction: { parts: [{ text: `${TUTOR_PROMPT}\n\n${parsed.detail === 'detailed' ? DETAILED : BRIEF}` }] },
        contents: toProviderMessages(parsed.messages),
        // Gemini 2.5 models count their internal thinking against this limit, so leave generous room.
        generationConfig: { maxOutputTokens: parsed.detail === 'detailed' ? 4096 : 2048 },
      }),
      signal: controller.signal,
    });
    const data = await res.json().catch(() => null);
    if (!res.ok) {
      const msg = data?.error?.message ?? '';
      if (res.status === 429) return fail(429, 'rate_limited', 'The AI provider is busy or the free quota is used up. Try again in a moment.', { headers: { 'retry-after': res.headers.get('retry-after') ?? '20' } });
      if (res.status === 400 && /api key|api_key/i.test(msg)) return fail(502, 'upstream_auth', 'The backend API key is not valid. Check GEMINI_API_KEY.');
      if (res.status === 400 && /image|inline|mime/i.test(msg)) return fail(400, 'bad_image', 'The AI could not read that picture. Try another one.');
      if (res.status === 401 || res.status === 403) return fail(502, 'upstream_auth', 'The backend is not authorised with Gemini. Check GEMINI_API_KEY.');
      if (res.status === 404) return fail(502, 'upstream_model', 'Gemini does not know that model. Check GEMINI_MODEL.');
      return fail(502, 'upstream', 'The AI provider returned an error. Please try again.');
    }
    if (data?.promptFeedback?.blockReason) return fail(422, 'blocked', 'The AI would not answer that question. Try rephrasing it.');
    const parts = data?.candidates?.[0]?.content?.parts ?? [];
    const answer = parts.filter((p) => typeof p.text === 'string' && !p.thought).map((p) => p.text).join('').trim();
    if (!answer) return fail(502, 'empty', 'The AI returned an empty answer. Please try again.');
    return { status: 200, body: { answer, model: data.modelVersion ?? cfg.model } };
  } catch (e) {
    return e?.name === 'AbortError' ? fail(504, 'timeout', 'The AI took too long. Please try again.') : fail(502, 'upstream', 'Could not reach the AI provider.');
  } finally {
    clearTimeout(timer);
  }
}

/** Builds the request handler. Config and fetch are injected so tests can run without a network. */
export function createHandler(cfg, fetchImpl = fetch) {
  const hits = new Map();

  const limited = (key) => {
    const now = Date.now();
    const fresh = (hits.get(key) ?? []).filter((t) => now - t < cfg.rateWindowMs);
    fresh.push(now);
    hits.set(key, fresh);
    if (hits.size > 5000) for (const [k, v] of hits) if (!v.some((t) => now - t < cfg.rateWindowMs)) hits.delete(k);
    return fresh.length > cfg.rateLimit ? Math.ceil((fresh[0] + cfg.rateWindowMs - now) / 1000) : 0;
  };

  return async function handle(req, res) {
    const send = (r) => {
      res.writeHead(r.status, { 'content-type': 'application/json', 'cache-control': 'no-store', ...(r.headers ?? {}) });
      res.end(JSON.stringify(r.body));
    };
    const url = new URL(req.url ?? '/', 'http://x');

    if (req.method === 'GET' && url.pathname === '/health') {
      return send({ status: 200, body: { ok: true, configured: !!cfg.apiKey } });
    }
    if (req.method !== 'POST' || url.pathname !== '/solve') return send(fail(404, 'not_found', 'Not found.'));

    if (cfg.appToken) {
      const given = req.headers['x-majesto-token'] ?? '';
      if (given !== cfg.appToken) return send(fail(401, 'unauthorized', 'Missing or wrong access token.'));
    }
    if (!cfg.apiKey) return send(fail(503, 'not_configured', 'The backend has no GEMINI_API_KEY yet.'));

    const ip = (cfg.trustProxy && String(req.headers['x-forwarded-for'] ?? '').split(',')[0].trim()) || req.socket.remoteAddress || 'unknown';
    const wait = limited(ip);
    if (wait) return send(fail(429, 'rate_limited', 'Too many questions in a short time.', { headers: { 'retry-after': String(wait) } }));

    let size = 0;
    const chunks = [];
    for await (const chunk of req) {
      size += chunk.length;
      if (size > MAX_BODY_BYTES) return send(fail(413, 'too_large', 'That request is too large.'));
      chunks.push(chunk);
    }
    let body;
    try {
      body = JSON.parse(Buffer.concat(chunks).toString('utf8'));
    } catch {
      return send(fail(400, 'invalid_request', 'The body must be valid JSON.'));
    }
    const parsed = parseRequest(body);
    if (parsed.status) return send(parsed);
    return send(await callProvider(cfg, parsed, fetchImpl));
  };
}

if (import.meta.url === pathToFileURL(process.argv[1] ?? '').href) {
  const cfg = loadConfig();
  if (!cfg.apiKey) console.warn('GEMINI_API_KEY is not set. /health works, /solve will answer 503.');
  const port = Number(process.env.PORT ?? 8787);
  http.createServer(createHandler(cfg)).listen(port, () => console.log(`Majesto AI backend listening on :${port}`));
}
