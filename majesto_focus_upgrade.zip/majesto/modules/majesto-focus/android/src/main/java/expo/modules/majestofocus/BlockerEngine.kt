package expo.modules.majestofocus

import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.os.SystemClock

/**
 * Decides when a blocked app has come to the front and puts the block screen in its place.
 *
 * Two ways of noticing, both permission-gated and both optional:
 *  - Accessibility service: instant, pushed to [FocusService.onForegroundPackage].
 *  - Usage access: polled twice a second while the screen is on.
 *
 * What this can and cannot do: Android does not let an ordinary app close or suspend another app.
 * We cover the blocked app with a full-screen block screen as soon as it is seen. A very fast app may flash
 * on screen for a moment first, and if no detection permission is granted nothing can be blocked.
 */
class BlockerEngine(private val ctx: Context) {
  private val usage = ctx.getSystemService(Context.USAGE_STATS_SERVICE) as? UsageStatsManager
  private var protectedSet: Set<String> = emptySet()
  private var blocked: Set<String> = emptySet()
  private var enabled = false

  private var lastQueryAt = 0L
  private var lastForeground: String? = null
  private var lastBlockAt = 0L

  fun configure(blockedPackages: Set<String>) {
    protectedSet = Protected.packages(ctx)
    blocked = blockedPackages.filter { it !in protectedSet }.toSet()
    enabled = blocked.isNotEmpty()
    if (!enabled) lastForeground = null
  }

  /** True when there is something to block and a way to notice it. */
  fun canWork(): Boolean = enabled && Perms.overlay(ctx) && (Perms.usageAccess(ctx) || FocusAccessibilityService.connected)

  /** Polling path. Skipped when the accessibility service is already pushing events. */
  fun poll(nowWall: Long, sessionRunning: Boolean) {
    if (!enabled || !sessionRunning || FocusAccessibilityService.connected) return
    if (usage == null || !Perms.usageAccess(ctx)) return
    val pkg = foregroundFromUsage(nowWall) ?: return
    onForeground(pkg, sessionRunning)
  }

  private fun foregroundFromUsage(now: Long): String? {
    return try {
      val from = if (lastQueryAt == 0L) now - 60_000L else maxOf(lastQueryAt - 1_500L, now - 60_000L)
      val events = usage?.queryEvents(from, now) ?: return lastForeground
      val e = UsageEvents.Event()
      while (events.hasNextEvent()) {
        events.getNextEvent(e)
        @Suppress("DEPRECATION")
        if (e.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND) lastForeground = e.packageName
      }
      lastQueryAt = now
      lastForeground
    } catch (ignored: Throwable) {
      lastForeground
    }
  }

  fun onForeground(pkg: String, sessionRunning: Boolean) {
    if (!enabled || !sessionRunning) return
    if (pkg !in blocked || pkg in protectedSet) return
    val t = SystemClock.elapsedRealtime()
    if (t - lastBlockAt < 1_500L) return
    lastBlockAt = t
    block(pkg)
  }

  private fun block(pkg: String) {
    val attempts = SessionStore(ctx).addAttempt()
    val label = try {
      val pm = ctx.packageManager
      pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
    } catch (ignored: Throwable) {
      pkg
    }
    FocusEvents.emit("onBlocked", mapOf("packageName" to pkg, "label" to label, "attempts" to attempts))
    var shown = false
    if (Perms.overlay(ctx)) {
      try {
        val i = Intent(ctx, BlockActivity::class.java)
          .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NO_ANIMATION)
          .putExtra(BlockActivity.EXTRA_LABEL, label)
        ctx.startActivity(i)
        shown = true
      } catch (ignored: Throwable) {
      }
    }
    // Last resort: at least take the person off the blocked app when the accessibility service is on.
    if (!shown) FocusAccessibilityService.goHome()
  }

  /** Forget what we saw, for example after the screen was off, so a stale app is not blocked on wake. */
  fun reset() {
    lastQueryAt = 0L
    lastForeground = null
  }
}
