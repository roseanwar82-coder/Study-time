package expo.modules.majestofocus

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager

/**
 * The one foreground service behind a focus session. It owns the floating timer, the app blocker and the
 * Do Not Disturb setting, so there is exactly one place that starts them and one place that stops them.
 * A second start while it is running only refreshes it: there is never a duplicate service.
 */
class FocusService : Service(), OverlayController.Actions {

  companion object {
    const val ACTION_START = "expo.modules.majestofocus.START"
    const val ACTION_TOGGLE_PAUSE = "expo.modules.majestofocus.TOGGLE_PAUSE"
    private const val CHANNEL_ID = "majesto_focus_session"
    private const val NOTIFICATION_ID = 7101
    private const val TICK_MS = 500L

    @Volatile var instance: FocusService? = null
      private set

    /** Starts (or refreshes) the service. Returns false if Android refused, e.g. the app is not allowed to start it now. */
    fun start(ctx: Context): Boolean {
      return try {
        val i = Intent(ctx, FocusService::class.java).setAction(ACTION_START)
        if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i) else ctx.startService(i)
        true
      } catch (ignored: Throwable) {
        false
      }
    }
  }

  private val handler = Handler(Looper.getMainLooper())
  private lateinit var store: SessionStore
  private lateinit var blocker: BlockerEngine
  private var overlayController: OverlayController? = null
  private var foregroundStarted = false
  private var lastNotifiedPaused: Boolean? = null
  private var screenWasOff = false

  val overlay: OverlayController? get() = overlayController

  private val loop = object : Runnable {
    override fun run() {
      tick()
      if (instance === this@FocusService) handler.postDelayed(this, TICK_MS)
    }
  }

  override fun onCreate() {
    super.onCreate()
    store = SessionStore(this)
    blocker = BlockerEngine(this)
    ensureChannel()
  }

  override fun onBind(intent: Intent?): IBinder? = null

  override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
    instance = this
    val s = store.read()

    // Android requires startForeground soon after startForegroundService, even when we are about to stop.
    startForegroundCompat(buildNotification(s))

    if (!s.active) {
      shutdown()
      return START_NOT_STICKY
    }

    if (intent?.action == ACTION_TOGGLE_PAUSE) {
      if (s.paused) resume() else pause()
    }

    applyFeatures()
    handler.removeCallbacks(loop)
    handler.post(loop)
    return START_STICKY // if Android kills us, it restarts us and the saved session carries on
  }

  override fun onDestroy() {
    handler.removeCallbacksAndMessages(null)
    overlayController?.remove()
    overlayController = null
    if (instance === this) instance = null
    super.onDestroy()
  }

  /* ----- features ----- */

  /** Brings the floating timer, blocker and Do Not Disturb in line with the saved session. Safe to repeat. */
  private fun applyFeatures() {
    val s = store.read()
    blocker.configure(s.blocked)
    if (s.floating && Perms.overlay(this)) {
      if (overlayController == null) overlayController = OverlayController(this, this)
      overlayController?.show()
    } else {
      overlayController?.remove()
    }
    if (s.dnd == "off") DndController.restore(this) else DndController.apply(this, s.dnd)
  }

  fun onForegroundPackage(pkg: String) {
    val s = store.read()
    blocker.onForeground(pkg, s.active && !s.paused && s.remaining(System.currentTimeMillis()) > 0)
  }

  private fun tick() {
    val s = store.read()
    if (!s.active) {
      shutdown()
      return
    }
    val now = System.currentTimeMillis()
    if (!s.paused && s.remaining(now) <= 0L) {
      finishByExpiry(now)
      return
    }

    val pm = getSystemService(Context.POWER_SERVICE) as? PowerManager
    val interactive = pm?.isInteractive ?: true
    if (!interactive) {
      screenWasOff = true // nothing to draw or block while the screen is off
      return
    }
    if (screenWasOff) {
      screenWasOff = false
      blocker.reset()
    }
    overlayController?.render(s, now)
    blocker.poll(now, !s.paused)
    if (lastNotifiedPaused != s.paused) updateNotification(s)
  }

  private fun finishByExpiry(now: Long) {
    store.markEnded("expired", now)
    FocusEvents.emit("onSessionEnded", mapOf("reason" to "expired", "at" to now.toDouble()))
    shutdown()
  }

  /** Stops the overlay, blocker and Do Not Disturb, then the service itself. The saved session is kept for the app to read. */
  fun shutdown() {
    handler.removeCallbacksAndMessages(null)
    overlayController?.remove()
    overlayController = null
    DndController.restore(this)
    try {
      stopForeground(true)
    } catch (ignored: Throwable) {
    }
    foregroundStarted = false
    if (instance === this) instance = null
    stopSelf()
  }

  /* ----- controls, used by the floating timer and the notification ----- */

  override fun pause() {
    val s = store.read()
    if (!s.active || s.paused) return
    val at = System.currentTimeMillis()
    store.markPaused(at)
    store.setPending("pause", at)
    FocusEvents.emit("onCommand", mapOf("command" to "pause", "at" to at.toDouble()))
    updateNotification(store.read())
  }

  override fun resume() {
    val s = store.read()
    if (!s.active || !s.paused) return
    val at = System.currentTimeMillis()
    store.markResumed(at)
    store.setPending("resume", at)
    FocusEvents.emit("onCommand", mapOf("command" to "resume", "at" to at.toDouble()))
    updateNotification(store.read())
  }

  /** The person confirmed "Stop" on the floating timer. */
  override fun stop() {
    val s = store.read()
    if (!s.active) return
    val at = System.currentTimeMillis()
    store.markEnded("stopped", at)
    store.setPending("stop", at)
    FocusEvents.emit("onCommand", mapOf("command" to "stop", "at" to at.toDouble()))
    shutdown()
  }

  override fun openAssist() {
    Launch.openAssist(this)
  }

  override fun captureScreen() {
    ScreenCapture.begin(this, minimize = false)
  }

  /** The app changed the timer or options. Safe to call from any thread: the work happens on the main thread. */
  fun postRefresh() {
    handler.post {
      if (instance !== this) return@post
      val s = store.read()
      if (!s.active) return@post
      updateNotification(s)
      applyFeatures()
    }
  }

  /** Stops everything. Safe to call from any thread. */
  fun postShutdown() {
    handler.post { shutdown() }
  }

  /* ----- notification ----- */

  private fun ensureChannel() {
    if (Build.VERSION.SDK_INT < 26) return
    val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    if (nm.getNotificationChannel(CHANNEL_ID) != null) return
    val ch = NotificationChannel(CHANNEL_ID, getString(R.string.majesto_focus_channel_name), NotificationManager.IMPORTANCE_LOW)
    ch.description = getString(R.string.majesto_focus_channel_description)
    ch.setShowBadge(false)
    nm.createNotificationChannel(ch)
  }

  private fun startForegroundCompat(n: Notification) {
    try {
      if (Build.VERSION.SDK_INT >= 34) {
        startForeground(NOTIFICATION_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
      } else {
        startForeground(NOTIFICATION_ID, n)
      }
      foregroundStarted = true
    } catch (ignored: Throwable) {
      // Android may refuse to let a background app start a foreground service. The app retries when it is opened.
    }
  }

  private fun updateNotification(s: SessionStore.Snapshot) {
    lastNotifiedPaused = s.paused
    try {
      (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(NOTIFICATION_ID, buildNotification(s))
    } catch (ignored: Throwable) {
    }
  }

  private fun smallIcon(): Int {
    val id = resources.getIdentifier("notification_icon", "drawable", packageName)
    return if (id != 0) id else android.R.drawable.ic_lock_idle_alarm
  }

  private fun buildNotification(s: SessionStore.Snapshot): Notification {
    val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL_ID) else Notification.Builder(this)
    b.setSmallIcon(smallIcon())
      .setContentTitle("Majesto focus session")
      .setOngoing(true)
      .setOnlyAlertOnce(true)
      .setCategory(Notification.CATEGORY_PROGRESS)
      .setContentIntent(openAppIntent())

    if (s.paused) {
      b.setContentText("Paused")
    } else {
      b.setContentText("Time left")
      b.setShowWhen(true)
      b.setWhen(System.currentTimeMillis() + s.remaining(System.currentTimeMillis()))
      b.setUsesChronometer(true)
      if (Build.VERSION.SDK_INT >= 24) b.setChronometerCountDown(true)
    }

    val toggle = Intent(this, FocusService::class.java).setAction(ACTION_TOGGLE_PAUSE)
    val flags = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    val pi = if (Build.VERSION.SDK_INT >= 26) PendingIntent.getForegroundService(this, 1, toggle, flags) else PendingIntent.getService(this, 1, toggle, flags)
    @Suppress("DEPRECATION")
    b.addAction(0, if (s.paused) "Resume" else "Pause", pi)
    if (Build.VERSION.SDK_INT >= 31) b.setForegroundServiceBehavior(Notification.FOREGROUND_SERVICE_IMMEDIATE)
    return b.build()
  }

  private fun openAppIntent(): PendingIntent {
    val launch = packageManager.getLaunchIntentForPackage(packageName) ?: Intent()
    launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
    return PendingIntent.getActivity(this, 0, launch, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
  }
}
