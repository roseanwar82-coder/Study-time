package expo.modules.majestofocus

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.view.WindowManager

/**
 * One-frame screenshot for the AI helper, always started by the person.
 *
 *  1. [begin] hides the floating timer and opens [CaptureConsentActivity], which shows Android's own
 *     "Start recording or casting?" dialog. Nothing is captured without that consent, every single time.
 *  2. [ScreenCaptureService] takes ONE frame, saves it to the cache folder, stops the projection and exits.
 *  3. The picture is handed to Majesto's AI screen. Nothing is uploaded until the person presses Ask there.
 */
object ScreenCapture {
  fun begin(ctx: Context, minimize: Boolean) {
    try {
      val i = Intent(ctx, CaptureConsentActivity::class.java)
        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION)
        .putExtra(CaptureConsentActivity.EXTRA_MINIMIZE, minimize)
      // Start first, hide second: the visible overlay is what lets the service start an activity.
      ctx.startActivity(i)
      FocusService.instance?.overlay?.setHidden(true)
    } catch (ignored: Throwable) {
      FocusService.instance?.overlay?.setHidden(false)
      FocusEvents.emit("onScreenshot", mapOf("error" to "unavailable"))
    }
  }

  fun finished(ctx: Context, path: String?, error: String?) {
    FocusService.instance?.overlay?.setHidden(false)
    if (path != null) {
      SessionStore(ctx).setPendingImage(path)
      FocusEvents.emit("onScreenshot", mapOf("path" to path))
      Launch.openAssist(ctx)
    } else {
      FocusEvents.emit("onScreenshot", mapOf("error" to (error ?: "failed")))
    }
  }
}

class CaptureConsentActivity : Activity() {
  companion object {
    const val EXTRA_MINIMIZE = "minimize"
    private const val REQUEST = 4101
  }

  private var minimize = false

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    minimize = intent?.getBooleanExtra(EXTRA_MINIMIZE, false) ?: false
    if (savedInstanceState != null) return // the system dialog is already up after a rotation
    try {
      val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
      @Suppress("DEPRECATION")
      startActivityForResult(mpm.createScreenCaptureIntent(), REQUEST)
    } catch (ignored: Throwable) {
      ScreenCapture.finished(this, null, "unavailable")
      finish()
    }
  }

  @Deprecated("Result of the system consent dialog")
  override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
    @Suppress("DEPRECATION")
    super.onActivityResult(requestCode, resultCode, data)
    if (requestCode != REQUEST) return
    if (resultCode != RESULT_OK || data == null) {
      ScreenCapture.finished(this, null, "denied")
      finish()
      return
    }
    if (minimize) FocusEvents.minimizeApp?.invoke()
    val i = Intent(this, ScreenCaptureService::class.java)
      .putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, resultCode)
      .putExtra(ScreenCaptureService.EXTRA_DATA, data)
    try {
      if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
    } catch (ignored: Throwable) {
      ScreenCapture.finished(this, null, "unavailable")
    }
    finish()
  }
}

class ScreenCaptureService : Service() {
  companion object {
    const val EXTRA_RESULT_CODE = "resultCode"
    const val EXTRA_DATA = "data"
    private const val CHANNEL_ID = "majesto_focus_capture"
    private const val NOTIFICATION_ID = 7102
    /** Gives the previous app time to come back to the front after Majesto steps aside. */
    private const val SETTLE_MS = 800L
    private const val TIMEOUT_MS = 6000L
  }

  private val handler = Handler(Looper.getMainLooper())
  private var projection: MediaProjection? = null
  private var display: VirtualDisplay? = null
  private var reader: ImageReader? = null
  private var done = false

  override fun onBind(intent: Intent?): IBinder? = null

  override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
    startForegroundCompat()
    val code = intent?.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED) ?: Activity.RESULT_CANCELED
    val data: Intent? = if (Build.VERSION.SDK_INT >= 33) {
      intent?.getParcelableExtra(EXTRA_DATA, Intent::class.java)
    } else {
      @Suppress("DEPRECATION")
      intent?.getParcelableExtra(EXTRA_DATA)
    }
    if (code != Activity.RESULT_OK || data == null) {
      finish(null, "denied")
      return START_NOT_STICKY
    }
    handler.postDelayed({ capture(code, data) }, SETTLE_MS)
    handler.postDelayed({ if (!done) finish(null, "timeout") }, SETTLE_MS + TIMEOUT_MS)
    return START_NOT_STICKY
  }

  private fun capture(resultCode: Int, data: Intent) {
    if (done) return
    try {
      val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
      val mp = mpm.getMediaProjection(resultCode, data)
      projection = mp
      // Android 14+ requires a callback to be registered before the display is created.
      mp.registerCallback(object : MediaProjection.Callback() {
        override fun onStop() {
          release()
        }
      }, handler)

      val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
      val width: Int
      val height: Int
      if (Build.VERSION.SDK_INT >= 30) {
        val b = wm.maximumWindowMetrics.bounds
        width = b.width()
        height = b.height()
      } else {
        val m = DisplayMetrics()
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(m)
        width = m.widthPixels
        height = m.heightPixels
      }
      val dpi = resources.displayMetrics.densityDpi

      val r = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
      reader = r
      r.setOnImageAvailableListener({ ir ->
        if (done) return@setOnImageAvailableListener
        val image: Image? = try { ir.acquireLatestImage() } catch (ignored: Throwable) { null }
        if (image == null) return@setOnImageAvailableListener
        var path: String? = null
        try {
          path = save(image, width, height)
        } catch (ignored: Throwable) {
        } finally {
          try { image.close() } catch (ignored: Throwable) {}
        }
        finish(path, if (path == null) "failed" else null)
      }, handler)
      display = mp.createVirtualDisplay(
        "majesto-capture", width, height, dpi,
        DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, handler,
      )
    } catch (ignored: Throwable) {
      finish(null, "failed")
    }
  }

  private fun save(image: Image, width: Int, height: Int): String {
    val plane = image.planes[0]
    val pixelStride = plane.pixelStride
    val rowPadding = plane.rowStride - pixelStride * width
    val padded = Bitmap.createBitmap(width + rowPadding / pixelStride, height, Bitmap.Config.ARGB_8888)
    padded.copyPixelsFromBuffer(plane.buffer)
    val cropped = Bitmap.createBitmap(padded, 0, 0, width, height)
    if (cropped !== padded) padded.recycle()
    val file = ImageFiles.saveScaledJpeg(this, cropped, "capture")
    cropped.recycle()
    return file.absolutePath
  }

  private fun finish(path: String?, error: String?) {
    if (done) return
    done = true
    release()
    ScreenCapture.finished(this, path, error)
    try {
      stopForeground(true)
    } catch (ignored: Throwable) {
    }
    stopSelf()
  }

  /** Stops the projection straight away, so nothing keeps recording after the one frame. */
  private fun release() {
    try { display?.release() } catch (ignored: Throwable) {}
    try { reader?.close() } catch (ignored: Throwable) {}
    try { projection?.stop() } catch (ignored: Throwable) {}
    display = null
    reader = null
    projection = null
  }

  override fun onDestroy() {
    handler.removeCallbacksAndMessages(null)
    release()
    super.onDestroy()
  }

  private fun startForegroundCompat() {
    val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    if (Build.VERSION.SDK_INT >= 26 && nm.getNotificationChannel(CHANNEL_ID) == null) {
      nm.createNotificationChannel(NotificationChannel(CHANNEL_ID, "Screenshot for AI help", NotificationManager.IMPORTANCE_LOW))
    }
    val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL_ID) else Notification.Builder(this)
    val iconId = resources.getIdentifier("notification_icon", "drawable", packageName)
    b.setSmallIcon(if (iconId != 0) iconId else android.R.drawable.ic_menu_camera)
      .setContentTitle("Majesto is taking one screenshot")
      .setContentText("It stops by itself as soon as the picture is taken.")
      .setOngoing(true)
    val n = b.build()
    try {
      if (Build.VERSION.SDK_INT >= 29) {
        startForeground(NOTIFICATION_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
      } else {
        startForeground(NOTIFICATION_ID, n)
      }
    } catch (ignored: Throwable) {
    }
  }
}
