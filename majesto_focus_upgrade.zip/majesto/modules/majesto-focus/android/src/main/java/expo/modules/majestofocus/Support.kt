package expo.modules.majestofocus

import android.app.AppOpsManager
import android.app.NotificationManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Process
import android.provider.Settings
import android.telecom.TelecomManager
import java.io.File
import java.io.FileOutputStream

/** Bridge from the native service to the JS module. Null while the JS runtime is not running. */
object FocusEvents {
  @Volatile var emitter: ((String, Map<String, Any?>) -> Unit)? = null
  @Volatile var minimizeApp: (() -> Unit)? = null

  fun emit(name: String, body: Map<String, Any?> = emptyMap()) {
    try {
      emitter?.invoke(name, body)
    } catch (ignored: Throwable) {
      // JS may be reloading. State is persisted, the app reconciles when it comes back.
    }
  }
}

/** Apps we never block, so that a focus session can never lock the phone or hide the way out. */
object Protected {
  private val FIXED = setOf(
    "android",
    "com.android.systemui",
    "com.android.settings",
    "com.android.emergency",
    "com.android.phone",
    "com.android.server.telecom",
    "com.android.dialer",
    "com.google.android.dialer",
    "com.android.permissioncontroller",
    "com.google.android.permissioncontroller",
    "com.android.packageinstaller",
    "com.google.android.packageinstaller",
  )

  fun packages(ctx: Context): Set<String> {
    val out = HashSet<String>(FIXED)
    out.add(ctx.packageName)
    try {
      val pm = ctx.packageManager
      val home = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
      val list = if (Build.VERSION.SDK_INT >= 33) {
        pm.queryIntentActivities(home, PackageManager.ResolveInfoFlags.of(0L))
      } else {
        @Suppress("DEPRECATION")
        pm.queryIntentActivities(home, 0)
      }
      for (ri in list) ri.activityInfo?.packageName?.let { out.add(it) }
    } catch (ignored: Throwable) {
    }
    try {
      val tm = ctx.getSystemService(Context.TELECOM_SERVICE) as? TelecomManager
      tm?.defaultDialerPackage?.let { out.add(it) }
    } catch (ignored: Throwable) {
    }
    return out
  }
}

object Perms {
  fun overlay(ctx: Context): Boolean =
    try { Settings.canDrawOverlays(ctx) } catch (ignored: Throwable) { false }

  fun usageAccess(ctx: Context): Boolean {
    return try {
      val ops = ctx.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
      val mode = if (Build.VERSION.SDK_INT >= 29) {
        ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName)
      } else {
        @Suppress("DEPRECATION")
        ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName)
      }
      mode == AppOpsManager.MODE_ALLOWED
    } catch (ignored: Throwable) {
      false
    }
  }

  /** True when the person has switched the accessibility service on in Android Settings. */
  fun accessibility(ctx: Context): Boolean {
    return try {
      val enabled = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
      val mine = ComponentName(ctx, FocusAccessibilityService::class.java)
      enabled.split(':').any { part ->
        val c = ComponentName.unflattenFromString(part)
        c != null && c == mine
      }
    } catch (ignored: Throwable) {
      false
    }
  }

  fun notificationPolicy(ctx: Context): Boolean {
    return try {
      (ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).isNotificationPolicyAccessGranted
    } catch (ignored: Throwable) {
      false
    }
  }

  fun notifications(ctx: Context): Boolean {
    return try {
      (ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).areNotificationsEnabled()
    } catch (ignored: Throwable) {
      true
    }
  }

  /** The Settings screen for one permission, or null for an unknown name. */
  fun settingsIntent(ctx: Context, kind: String): Intent? {
    val pkg = Uri.parse("package:" + ctx.packageName)
    val intent = when (kind) {
      "overlay" -> Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, pkg)
      "usageAccess" -> Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)
      "accessibility" -> Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
      "notificationPolicy" -> Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)
      "notifications" -> Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, ctx.packageName)
      else -> return null
    }
    return intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
  }
}

object Launch {
  /** Brings Majesto's AI help screen to the front. Safe to call from the service: it has the overlay exemption. */
  fun openAssist(ctx: Context) {
    try {
      val i = Intent(Intent.ACTION_VIEW, Uri.parse("majesto://assist"))
        .setPackage(ctx.packageName)
        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
      ctx.startActivity(i)
    } catch (ignored: Throwable) {
    }
  }

  fun openApp(ctx: Context) {
    try {
      val i = ctx.packageManager.getLaunchIntentForPackage(ctx.packageName) ?: return
      i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
      ctx.startActivity(i)
    } catch (ignored: Throwable) {
    }
  }

  fun goHome(ctx: Context) {
    try {
      val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
      ctx.startActivity(i)
    } catch (ignored: Throwable) {
    }
  }
}

object ImageFiles {
  private const val MAX_EDGE = 1600
  private const val KEEP_MS = 60L * 60L * 1000L

  /** Scales to at most 1600px on the long side and writes a JPEG into the cache folder. */
  fun saveScaledJpeg(ctx: Context, source: Bitmap, prefix: String): File {
    val longest = maxOf(source.width, source.height)
    val scaled = if (longest > MAX_EDGE) {
      val f = MAX_EDGE.toFloat() / longest
      Bitmap.createScaledBitmap(source, maxOf(1, (source.width * f).toInt()), maxOf(1, (source.height * f).toInt()), true)
    } else {
      source
    }
    pruneOld(ctx)
    val file = File(ctx.cacheDir, prefix + "_" + System.currentTimeMillis() + ".jpg")
    FileOutputStream(file).use { scaled.compress(Bitmap.CompressFormat.JPEG, 85, it) }
    if (scaled !== source) scaled.recycle()
    return file
  }

  private fun pruneOld(ctx: Context) {
    try {
      val cutoff = System.currentTimeMillis() - KEEP_MS
      ctx.cacheDir.listFiles()?.forEach { f ->
        val n = f.name
        if ((n.startsWith("capture_") || n.startsWith("shared_")) && f.lastModified() < cutoff) f.delete()
      }
    } catch (ignored: Throwable) {
    }
  }

  /** Only files this module wrote, so JS can never ask us to read or delete anything else. */
  fun isOurs(ctx: Context, path: String): Boolean {
    return try {
      val f = File(path).canonicalFile
      f.parentFile == ctx.cacheDir.canonicalFile && (f.name.startsWith("capture_") || f.name.startsWith("shared_"))
    } catch (ignored: Throwable) {
      false
    }
  }
}
