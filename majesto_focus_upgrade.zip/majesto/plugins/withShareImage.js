// Lets other apps share a picture straight into Majesto (for example "Share" on a screenshot or video frame).
// Adds one intent filter to the main activity. Nothing else changes.
const { withAndroidManifest } = require('expo/config-plugins');

module.exports = function withShareImage(config) {
  return withAndroidManifest(config, (cfg) => {
    const app = cfg.modResults.manifest.application?.[0];
    const main = app?.activity?.find((a) => a.$['android:name'] === '.MainActivity');
    if (!main) return cfg;
    main['intent-filter'] = main['intent-filter'] ?? [];
    const exists = main['intent-filter'].some((f) =>
      (f.action ?? []).some((a) => a.$['android:name'] === 'android.intent.action.SEND') &&
      (f.data ?? []).some((d) => (d.$['android:mimeType'] ?? '').startsWith('image/')),
    );
    if (!exists) {
      main['intent-filter'].push({
        action: [{ $: { 'android:name': 'android.intent.action.SEND' } }],
        category: [{ $: { 'android:name': 'android.intent.category.DEFAULT' } }],
        data: [{ $: { 'android:mimeType': 'image/*' } }],
      });
    }
    return cfg;
  });
};
