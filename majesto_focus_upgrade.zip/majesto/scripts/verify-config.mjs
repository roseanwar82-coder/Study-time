// Offline sanity checks for build configuration. Run: npm run verify
// This does not replace `npx expo-doctor` (which needs the network); it catches the mistakes that
// most often break EAS builds before you spend a build on them.
import { readFileSync, existsSync, readdirSync, statSync } from 'node:fs';
import { join, relative, sep } from 'node:path';

const root = process.cwd();
const read = (f) => JSON.parse(readFileSync(join(root, f), 'utf8'));
const results = [];
const check = (name, ok, detail = '') => results.push({ name, ok: !!ok, detail });

const app = read('app.json').expo;
const eas = read('eas.json');
const pkg = read('package.json');
const deps = { ...pkg.dependencies, ...pkg.devDependencies };

/* ---------- app.json ---------- */
check('app name', app.name === 'Majesto', app.name);
check('slug', /^[a-z0-9-]+$/.test(app.slug), app.slug);
check('version is semver', /^\d+\.\d+\.\d+$/.test(app.version), app.version);
check('iOS bundle identifier is reverse-DNS', /^[A-Za-z0-9-]+(\.[A-Za-z0-9-]+){2,}$/.test(app.ios?.bundleIdentifier ?? ''), app.ios?.bundleIdentifier);
check('Android package is a valid Java package', /^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*){2,}$/.test(app.android?.package ?? ''), app.android?.package);
check('iOS and Android identifiers match', app.ios?.bundleIdentifier === app.android?.package);
check('no versionCode/buildNumber (EAS manages them remotely)', app.android?.versionCode === undefined && app.ios?.buildNumber === undefined && eas.cli?.appVersionSource === 'remote');
check('export compliance flag set (avoids TestFlight prompt)', app.ios?.infoPlist?.ITSAppUsesNonExemptEncryption === false);
check('Android notification permission declared', (app.android?.permissions ?? []).includes('android.permission.POST_NOTIFICATIONS'));
check('deprecated keys absent (newArchEnabled, edgeToEdgeEnabled)', app.newArchEnabled === undefined && app.android?.edgeToEdgeEnabled === undefined);
check('dark UI style set and expo-system-ui installed (needed on Android)', app.userInterfaceStyle === 'dark' && !!deps['expo-system-ui']);
check('overlay permission is not blocked (floating timer needs it)', !(app.android?.blockedPermissions ?? []).includes('android.permission.SYSTEM_ALERT_WINDOW'));
check('native focus module present', existsSync(join(root, 'modules/majesto-focus/expo-module.config.json')) && existsSync(join(root, 'modules/majesto-focus/android/build.gradle')));
check('.gitignore does not hide the module android folder from EAS', !/^android\/$/m.test(readFileSync(join(root, '.gitignore'), 'utf8')));
check('URL scheme set (Expo Router deep links)', app.scheme === 'majesto');

/* ---------- assets ---------- */
function png(file) {
  const b = readFileSync(join(root, file));
  if (b.subarray(1, 4).toString() !== 'PNG') return null;
  const colorType = b[25]; // 2 = RGB, 6 = RGBA, 3 = palette, 0/4 = gray(+alpha)
  return { w: b.readUInt32BE(16), h: b.readUInt32BE(20), alpha: colorType === 6 || colorType === 4 };
}
const asset = (label, path, w, h, alpha) => {
  const ok = path && existsSync(join(root, path));
  const info = ok ? png(path) : null;
  const good = info && info.w === w && info.h === h && (alpha === undefined || info.alpha === alpha);
  check(label, good, ok ? info && `${info.w}x${info.h}, alpha ${info.alpha}` : `missing: ${path}`);
};
asset('app icon: 1024x1024 with NO alpha (App Store rejects transparency)', app.icon, 1024, 1024, false);
asset('adaptive icon foreground: 1024x1024 with alpha', app.android?.adaptiveIcon?.foregroundImage, 1024, 1024, true);
const splash = app.plugins.find((p) => Array.isArray(p) && p[0] === 'expo-splash-screen')?.[1];
asset('splash image exists (square)', splash?.image, 1024, 1024);
const notif = app.plugins.find((p) => Array.isArray(p) && p[0] === 'expo-notifications')?.[1];
asset('notification icon: 96x96 with alpha', notif?.icon, 96, 96, true);
check('splash and adaptive backgrounds match the app background', splash?.backgroundColor === app.backgroundColor && app.android?.adaptiveIcon?.backgroundColor === app.backgroundColor);

/* ---------- eas.json ---------- */
const profiles = eas.build ?? {};
const resolve = (name, seen = new Set()) => {
  if (seen.has(name)) return null;
  seen.add(name);
  const p = profiles[name];
  if (!p) return null;
  if (!p.extends) return p;
  const base = resolve(p.extends, seen);
  return base ? { ...base, ...p, android: { ...base.android, ...p.android }, ios: { ...base.ios, ...p.ios } } : null;
};
for (const name of Object.keys(profiles)) check(`eas profile "${name}" resolves`, resolve(name));
const dev = resolve('development');
const preview = resolve('preview');
const prod = resolve('production');
const prodApk = resolve('production-apk');
check('development: dev client, internal, Android APK, iOS device build', dev?.developmentClient && dev.distribution === 'internal' && dev.android?.buildType === 'apk' && dev.ios?.simulator === false);
check('development-simulator: iOS simulator build', resolve('development-simulator')?.ios?.simulator === true);
check('preview: internal (ad hoc on iOS), Android APK, NOT a dev client', preview?.distribution === 'internal' && preview.android?.buildType === 'apk' && !preview.developmentClient);
check('production: store distribution, Android AAB, auto-increment', prod?.distribution === undefined && prod?.android?.buildType === 'app-bundle' && prod?.autoIncrement === true);
check('production-apk: installable APK from production settings', prodApk?.android?.buildType === 'apk' && prodApk?.distribution === 'internal');
check('no iOS "image" override (SDK 57 default is Xcode 26, which Apple requires)', Object.values(profiles).every((p) => !p.ios?.image));
check('expo-dev-client installed (required for the development profile)', !!deps['expo-dev-client']);

/* ---------- package.json ---------- */
const expoMajor = /(\d+)\./.exec(pkg.dependencies.expo.replace(/^[~^]/, ''))?.[1];
check('Expo SDK 57', expoMajor === '57', pkg.dependencies.expo);
const mismatched = Object.entries(pkg.dependencies).filter(([n, v]) => n.startsWith('expo-') && !new RegExp(`^~${expoMajor}\\.`).test(v));
check('every expo-* package is ~57.x', mismatched.length === 0, mismatched.map(([n, v]) => `${n}@${v}`).join(', '));
check('React Native 0.86 with React 19.2', pkg.dependencies['react-native'].startsWith('0.86') && pkg.dependencies.react.startsWith('19.2'));
check('entry point is expo-router', pkg.main === 'expo-router/entry');

/* ---------- imports vs dependencies, routes vs files ---------- */
const walk = (dir) => readdirSync(dir).flatMap((f) => {
  const p = join(dir, f);
  return statSync(p).isDirectory() ? walk(p) : [p];
});
const srcFiles = ['app', 'src'].flatMap((d) => walk(join(root, d))).filter((f) => /\.(ts|tsx)$/.test(f));
const used = new Map();
const missingLocal = [];
for (const f of srcFiles) {
  const text = readFileSync(f, 'utf8');
  for (const m of text.matchAll(/(?:import|export)[^'"`]*?from\s+['"]([^'"]+)['"]|import\s+['"]([^'"]+)['"]/g)) {
    const spec = m[1] ?? m[2];
    if (spec.startsWith('@/')) {
      const base = join(root, 'src', spec.slice(2));
      if (!['.ts', '.tsx', '/index.ts', '/index.tsx'].some((ext) => existsSync(base + ext))) missingLocal.push(`${relative(root, f)} -> ${spec}`);
    } else if (!spec.startsWith('.')) {
      const name = spec.startsWith('@') ? spec.split('/').slice(0, 2).join('/') : spec.split('/')[0];
      used.set(name, relative(root, f));
    }
  }
}
const undeclared = [...used].filter(([n]) => !deps[n]);
check('every third-party import is a declared dependency', undeclared.length === 0, undeclared.map(([n, f]) => `${n} (${f})`).join(', '));
check('every "@/" import resolves to a file', missingLocal.length === 0, missingLocal.join('; '));

const routes = walk(join(root, 'app')).map((f) => relative(join(root, 'app'), f).split(sep).join('/')).filter((f) => f.endsWith('.tsx'));
const noDefault = routes.filter((r) => !/export\s+default/.test(readFileSync(join(root, 'app', r), 'utf8')));
check('every route file has a default export', noDefault.length === 0, noDefault.join(', '));
const layout = readFileSync(join(root, 'app/_layout.tsx'), 'utf8');
const declared = [...layout.matchAll(/<Stack\.Screen name="([^"]+)"/g)].map((m) => m[1]);
const missingRoutes = declared.filter((n) => !routes.some((r) => r === `${n}.tsx` || r.startsWith(`${n}/`)));
check('every <Stack.Screen name> matches a route', missingRoutes.length === 0, missingRoutes.join(', '));
const tabs = [...readFileSync(join(root, 'app/(tabs)/_layout.tsx'), 'utf8').matchAll(/<Tabs\.Screen name="([^"]+)"/g)].map((m) => m[1]);
check('every tab matches a file in app/(tabs)', tabs.every((t) => routes.includes(`(tabs)/${t}.tsx`)), tabs.join(', '));

/* ---------- removed / renamed APIs ---------- */
const allText = srcFiles.map((f) => readFileSync(f, 'utf8')).join('\n');
check('no removed notification option shouldShowAlert', !/shouldShowAlert/.test(allText));
check('no StyleSheet.absoluteFillObject', !/absoluteFillObject/.test(allText));

/* ---------- report ---------- */
let failed = 0;
for (const r of results) {
  if (!r.ok) failed++;
  console.log(`${r.ok ? 'PASS' : 'FAIL'}  ${r.name}${!r.ok && r.detail ? `  [${r.detail}]` : ''}`);
}
console.log(`\n${results.length - failed}/${results.length} checks passed`);
process.exit(failed ? 1 : 0);
