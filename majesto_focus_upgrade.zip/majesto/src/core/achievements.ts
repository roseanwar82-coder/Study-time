import type { PersistedState } from './types';
import { MINUTE, dayKey } from './time';
import { computeStreak } from './streak';
import { levelFromXp } from './xp';

export interface Metrics {
  totalFocusMs: number;
  sessions: number;
  longestSessionMs: number;
  reviews: number;
  drills: number;
  bestPoints: number;
  longestStreak: number;
  cards: number;
  tasksDone: number;
  level: number;
}

export interface AchievementDef {
  id: string;
  title: string;
  description: string;
  target: number;
  progress: (m: Metrics) => number;
}

export function computeMetrics(s: PersistedState, now: number): Metrics {
  let totalFocusMs = 0, sessions = 0, reviews = 0, drills = 0, tasksDone = 0;
  for (const a of Object.values(s.activity)) {
    totalFocusMs += a.focusMs;
    sessions += a.sessions;
    reviews += a.reviews;
    drills += a.drills;
    tasksDone += a.tasksDone;
  }
  const longestSessionMs = s.sessions.reduce((max, x) => (x.completed ? Math.max(max, x.actualMs) : max), 0);
  const bestPoints = Object.values(s.drills.stats).reduce((max, st) => Math.max(max, st?.best ?? 0), 0);
  return {
    totalFocusMs,
    sessions,
    longestSessionMs,
    reviews,
    drills,
    bestPoints,
    longestStreak: computeStreak(s.activity, dayKey(now)).longest,
    cards: s.cards.length,
    tasksDone,
    level: levelFromXp(s.xp),
  };
}

export const ACHIEVEMENTS: AchievementDef[] = [
  { id: 'first_focus', title: 'First block', description: 'Finish a focus session.', target: 1, progress: (m) => m.sessions },
  { id: 'focus_10h', title: 'Ten hours in', description: 'Focus for 10 hours in total.', target: 600, progress: (m) => Math.floor(m.totalFocusMs / MINUTE) },
  { id: 'deep_90', title: 'Deep dive', description: 'Complete a single 90 minute session.', target: 90, progress: (m) => Math.floor(m.longestSessionMs / MINUTE) },
  { id: 'first_review', title: 'First recall', description: 'Review your first card.', target: 1, progress: (m) => m.reviews },
  { id: 'reviews_100', title: 'Hundred recalls', description: 'Answer 100 cards.', target: 100, progress: (m) => m.reviews },
  { id: 'reviews_1000', title: 'Thousand recalls', description: 'Answer 1,000 cards.', target: 1000, progress: (m) => m.reviews },
  { id: 'deck_builder', title: 'Deck builder', description: 'Create 25 cards.', target: 25, progress: (m) => m.cards },
  { id: 'first_drill', title: 'Warm-up', description: 'Finish a drill.', target: 1, progress: (m) => m.drills },
  { id: 'drills_25', title: 'Regular', description: 'Finish 25 drills.', target: 25, progress: (m) => m.drills },
  { id: 'sharp', title: 'Sharp', description: 'Score 900 or more in any drill.', target: 900, progress: (m) => m.bestPoints },
  { id: 'streak_3', title: 'Three days running', description: 'Reach a 3 day streak.', target: 3, progress: (m) => m.longestStreak },
  { id: 'streak_7', title: 'A full week', description: 'Reach a 7 day streak.', target: 7, progress: (m) => m.longestStreak },
  { id: 'streak_30', title: 'A full month', description: 'Reach a 30 day streak.', target: 30, progress: (m) => m.longestStreak },
  { id: 'tasks_25', title: 'Closer', description: 'Complete 25 intentions.', target: 25, progress: (m) => m.tasksDone },
  { id: 'level_5', title: 'Level 5', description: 'Reach level 5.', target: 5, progress: (m) => m.level },
  { id: 'level_10', title: 'Level 10', description: 'Reach level 10.', target: 10, progress: (m) => m.level },
];
