/**
 * Client side of the AI tutor. Pure TypeScript: the network call is injected, so it runs the same in the
 * app and in tests. The API key never lives here. It lives on the backend in /backend.
 */

export type ImageType = 'image/jpeg' | 'image/png' | 'image/webp';

export interface TutorImage {
  mediaType: ImageType;
  /** Base64 without the "data:" prefix. */
  base64: string;
}

export interface TutorMessage {
  role: 'user' | 'assistant';
  text: string;
  /** Only user messages can carry an image. */
  image?: TutorImage | null;
}

export type Detail = 'brief' | 'detailed';

export interface TutorRequest {
  /** The whole conversation so far. The last message must be from the user. */
  messages: TutorMessage[];
  detail: Detail;
}

export type TutorErrorCode =
  | 'not-configured'
  | 'invalid-request'
  | 'offline'
  | 'timeout'
  | 'unauthorized'
  | 'rate-limited'
  | 'bad-image'
  | 'too-large'
  | 'server'
  | 'bad-response';

export class TutorError extends Error {
  readonly code: TutorErrorCode;
  readonly retryAfterSec?: number;
  constructor(code: TutorErrorCode, message: string, retryAfterSec?: number) {
    super(message);
    this.name = 'TutorError';
    this.code = code;
    this.retryAfterSec = retryAfterSec;
  }
}

export const MAX_QUESTION_CHARS = 6000;
export const MAX_HISTORY = 12;
export const DEFAULT_TIMEOUT_MS = 60_000;

const IMAGE_TYPES: readonly string[] = ['image/jpeg', 'image/png', 'image/webp'];

/** Accepts https URLs, and plain http only for local development servers. Returns null when unusable. */
export function normalizeEndpoint(raw: string | null | undefined): string | null {
  const value = (raw ?? '').trim().replace(/\/+$/, '');
  const m = /^(https?):\/\/([^/\s:]+)(:\d+)?(\/[^\s?#]*)?$/i.exec(value);
  if (!m) return null;
  const scheme = m[1].toLowerCase();
  const host = m[2].toLowerCase();
  if (scheme === 'http') {
    const local = host === 'localhost' || host === '10.0.2.2' || /^127\./.test(host) || /^192\.168\./.test(host) || /^10\./.test(host);
    if (!local) return null;
  }
  return value;
}

/** Everything the UI needs to know before it lets someone press "Ask". */
export function validateRequest(req: TutorRequest): TutorError | null {
  const msgs = req.messages;
  if (msgs.length === 0 || msgs[msgs.length - 1].role !== 'user') {
    return new TutorError('invalid-request', 'Write a question first.');
  }
  const last = msgs[msgs.length - 1];
  if (!last.text.trim() && !msgs.some((m) => m.image)) {
    return new TutorError('invalid-request', 'Write a question or add an image.');
  }
  if (msgs.some((m) => m.text.length > MAX_QUESTION_CHARS)) {
    return new TutorError('too-large', `Keep each message under ${MAX_QUESTION_CHARS} characters.`);
  }
  for (const m of msgs) {
    if (m.image && (m.role !== 'user' || !IMAGE_TYPES.includes(m.image.mediaType) || !m.image.base64)) {
      return new TutorError('bad-image', 'That image type is not supported. Use a JPEG, PNG or WebP picture.');
    }
  }
  return null;
}

/** Keeps the most recent turns, always starting with a user message so roles alternate correctly. */
export function trimHistory(messages: TutorMessage[], max = MAX_HISTORY): TutorMessage[] {
  if (messages.length <= max) return messages;
  let tail = messages.slice(messages.length - max);
  // The image usually sits on the first message. Keep it by carrying it onto the first kept user turn.
  const dropped = messages.slice(0, messages.length - max);
  const image = [...dropped].reverse().find((m) => m.image)?.image ?? null;
  while (tail.length > 0 && tail[0].role !== 'user') tail = tail.slice(1);
  if (image && tail.length > 0 && !tail.some((m) => m.image)) tail = [{ ...tail[0], image }, ...tail.slice(1)];
  return tail;
}

export function buildBody(req: TutorRequest): unknown {
  return {
    detail: req.detail,
    messages: trimHistory(req.messages).map((m) => ({
      role: m.role,
      text: m.text,
      ...(m.image ? { image: { mediaType: m.image.mediaType, base64: m.image.base64 } } : {}),
    })),
  };
}

export interface TutorConfig {
  endpoint: string | null | undefined;
  token?: string | null;
  fetchImpl?: typeof fetch;
  timeoutMs?: number;
}

export interface TutorAnswer {
  answer: string;
}

function messageFromBody(body: unknown, fallback: string): { code?: string; message: string } {
  if (body && typeof body === 'object') {
    const err = (body as { error?: unknown }).error;
    if (err && typeof err === 'object') {
      const e = err as { code?: unknown; message?: unknown };
      return {
        code: typeof e.code === 'string' ? e.code : undefined,
        message: typeof e.message === 'string' && e.message ? e.message : fallback,
      };
    }
  }
  return { message: fallback };
}

export async function askTutor(req: TutorRequest, cfg: TutorConfig): Promise<TutorAnswer> {
  const endpoint = normalizeEndpoint(cfg.endpoint);
  if (!endpoint) {
    throw new TutorError(
      'not-configured',
      cfg.endpoint ? 'The AI address is not valid. It must start with https://.' : 'AI help is not set up yet. Add your backend address in Focus guard settings.',
    );
  }
  const invalid = validateRequest(req);
  if (invalid) throw invalid;

  const doFetch = cfg.fetchImpl ?? fetch;
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), cfg.timeoutMs ?? DEFAULT_TIMEOUT_MS);

  let res: Response;
  try {
    res = await doFetch(`${endpoint}/solve`, {
      method: 'POST',
      headers: {
        'content-type': 'application/json',
        ...(cfg.token ? { 'x-majesto-token': cfg.token } : {}),
      },
      body: JSON.stringify(buildBody(req)),
      signal: controller.signal,
    });
  } catch (e) {
    const aborted = (e as { name?: string } | null)?.name === 'AbortError';
    throw aborted
      ? new TutorError('timeout', 'The answer took too long. Check your connection and try again.')
      : new TutorError('offline', 'Could not reach the AI service. Check your internet connection.');
  } finally {
    clearTimeout(timeout);
  }

  let body: unknown = null;
  try {
    body = await res.json();
  } catch {
    body = null;
  }

  if (!res.ok) {
    const { code, message } = messageFromBody(body, `The AI service returned an error (${res.status}).`);
    if (res.status === 401 || res.status === 403) throw new TutorError('unauthorized', 'The AI service rejected this app. Check the access token.');
    if (res.status === 429) {
      const retry = Number(res.headers?.get?.('retry-after'));
      throw new TutorError('rate-limited', 'Too many questions in a short time. Wait a moment and try again.', Number.isFinite(retry) && retry > 0 ? retry : undefined);
    }
    if (res.status === 413) throw new TutorError('too-large', 'That image or question is too large. Try a smaller image.');
    if (res.status === 400 && code === 'bad_image') throw new TutorError('bad-image', message);
    if (res.status === 400) throw new TutorError('invalid-request', message);
    throw new TutorError('server', message);
  }

  const answer = body && typeof body === 'object' ? (body as { answer?: unknown }).answer : undefined;
  if (typeof answer !== 'string' || !answer.trim()) {
    throw new TutorError('bad-response', 'The AI service sent an empty answer. Please try again.');
  }
  return { answer: answer.trim() };
}

/** A short, kind sentence for each failure, for the answer panel. */
export function describeError(e: unknown): string {
  if (e instanceof TutorError) {
    if (e.code === 'rate-limited' && e.retryAfterSec) return `${e.message} (about ${e.retryAfterSec}s)`;
    return e.message;
  }
  return 'Something went wrong. Please try again.';
}
