import type { DrillKind } from '../types';

export type Domain = 'Attention' | 'Memory' | 'Reasoning';

export interface DrillMeta {
  kind: DrillKind;
  title: string;
  domain: Domain;
  blurb: string;
  howTo: string[];
  levelName: string;
  levels: { value: number; label: string }[];
  defaultLevel: number;
}

export const DRILL_ORDER: DrillKind[] = ['schulte', 'span', 'nback', 'stroop', 'sequence'];

export const DRILLS: Record<DrillKind, DrillMeta> = {
  schulte: {
    kind: 'schulte',
    title: 'Schulte table',
    domain: 'Attention',
    blurb: 'Find every number in order, as fast as you can.',
    howTo: [
      'Tap the numbers from 1 upward in order.',
      'Keep your eyes on the center and use your peripheral vision.',
      'A wrong tap adds one second.',
    ],
    levelName: 'Grid',
    levels: [
      { value: 3, label: '3x3' },
      { value: 4, label: '4x4' },
      { value: 5, label: '5x5' },
    ],
    defaultLevel: 4,
  },
  span: {
    kind: 'span',
    title: 'Number span',
    domain: 'Memory',
    blurb: 'Hold a growing string of digits in mind and repeat it back.',
    howTo: [
      'Watch the digits appear one at a time.',
      'Type them back when the keypad shows.',
      'Two mistakes end the round. Every correct answer adds a digit.',
    ],
    levelName: 'Order',
    levels: [
      { value: 1, label: 'Forward' },
      { value: 2, label: 'Backward' },
    ],
    defaultLevel: 1,
  },
  nback: {
    kind: 'nback',
    title: 'N-back',
    domain: 'Memory',
    blurb: 'Spot when a letter matches the one from N steps ago.',
    howTo: [
      'Letters appear one at a time.',
      'Tap Match when the letter is the same as the one N steps back.',
      'Do nothing when it is different.',
    ],
    levelName: 'N',
    levels: [
      { value: 1, label: '1-back' },
      { value: 2, label: '2-back' },
      { value: 3, label: '3-back' },
      { value: 4, label: '4-back' },
    ],
    defaultLevel: 2,
  },
  stroop: {
    kind: 'stroop',
    title: 'Color clash',
    domain: 'Attention',
    blurb: 'Name the ink color, not the word. Your reading habit will fight you.',
    howTo: [
      'A color word appears, printed in some ink color.',
      'Tap the button for the ink color, ignoring what the word says.',
      'Speed and accuracy both count.',
    ],
    levelName: 'Mode',
    levels: [{ value: 1, label: 'Standard' }],
    defaultLevel: 1,
  },
  sequence: {
    kind: 'sequence',
    title: 'Sequences',
    domain: 'Reasoning',
    blurb: 'Work out the rule behind a number pattern and pick what comes next.',
    howTo: [
      'Each puzzle shows five numbers that follow a hidden rule.',
      'Choose the sixth number from four options.',
      'Higher levels use trickier rules.',
    ],
    levelName: 'Level',
    levels: [
      { value: 1, label: '1' },
      { value: 2, label: '2' },
      { value: 3, label: '3' },
      { value: 4, label: '4' },
      { value: 5, label: '5' },
    ],
    defaultLevel: 2,
  },
};

export function isDrillKind(v: string | undefined): v is DrillKind {
  return v !== undefined && v in DRILLS;
}
