import type { Rng } from '../rng';
import { clamp01 } from '../time';

export const SCHULTE_SIZES = [3, 4, 5];
const TARGET_SEC_PER_CELL = 1.0;
const BASELINE_SEC_PER_CELL = 2.6;
const MISS_PENALTY_MS = 1000;

export function generateGrid(rng: Rng, size: number): number[] {
  const nums = Array.from({ length: size * size }, (_, i) => i + 1);
  return rng.shuffle(nums);
}

export interface SchulteScore {
  points: number;
  effectiveSeconds: number;
  summary: string;
  nextSize: number;
}

export function scoreSchulte(size: number, timeMs: number, errors: number): SchulteScore {
  const cells = size * size;
  const effectiveMs = timeMs + errors * MISS_PENALTY_MS;
  const targetMs = TARGET_SEC_PER_CELL * cells * 1000;
  const baselineMs = BASELINE_SEC_PER_CELL * cells * 1000;
  const norm = clamp01((baselineMs - effectiveMs) / (baselineMs - targetMs));
  const seconds = timeMs / 1000;
  const missText = errors === 0 ? 'no misses' : errors === 1 ? '1 miss' : `${errors} misses`;
  const nextSize = norm > 0.8 && size < 5 ? size + 1 : norm < 0.2 && size > 3 ? size - 1 : size;
  return {
    points: Math.round(1000 * norm),
    effectiveSeconds: effectiveMs / 1000,
    summary: `${seconds.toFixed(1)}s on ${size}x${size}, ${missText}`,
    nextSize,
  };
}
