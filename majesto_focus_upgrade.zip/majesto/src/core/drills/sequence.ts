import type { Rng } from '../rng';
import { clamp01 } from '../time';

export const SEQUENCE_ROUND = 10;
export const SEQUENCE_MAX_LEVEL = 5;

export interface Puzzle {
  family: string;
  terms: number[]; // shown
  answer: number;
  options: number[];
  rule: string;
}

interface Built {
  terms: number[]; // 6 terms; the last is the answer
  rule: string;
}

type Family = (rng: Rng, hard: boolean) => Built;

const arithmetic: Family = (rng, hard) => {
  const down = rng.chance(0.3);
  const d = rng.int(2, hard ? 15 : 9) * (down ? -1 : 1);
  const start = down ? rng.int(80, 140) : rng.int(1, 30);
  return {
    terms: Array.from({ length: 6 }, (_, i) => start + d * i),
    rule: d > 0 ? `Add ${d} each time` : `Subtract ${-d} each time`,
  };
};

const geometric: Family = (rng, hard) => {
  const r = rng.int(2, hard ? 4 : 3);
  const start = rng.int(1, 4);
  return { terms: Array.from({ length: 6 }, (_, i) => start * r ** i), rule: `Multiply by ${r} each time` };
};

const growing: Family = (rng, hard) => {
  const d0 = rng.int(1, hard ? 5 : 3);
  const start = rng.int(1, 12);
  const terms = [start];
  for (let i = 0; i < 5; i++) terms.push(terms[i] + d0 + i);
  return { terms, rule: `The gap grows by 1 each step (+${d0}, +${d0 + 1}, +${d0 + 2}...)` };
};

const alternating: Family = (rng, hard) => {
  const a = rng.int(3, hard ? 12 : 9);
  const b = rng.int(1, a - 1);
  const terms = [rng.int(8, 30)];
  for (let i = 0; i < 5; i++) terms.push(terms[i] + (i % 2 === 0 ? a : -b));
  return { terms, rule: `Alternately add ${a} and subtract ${b}` };
};

const squares: Family = (rng, hard) => {
  const k = rng.int(1, hard ? 6 : 4);
  const c = rng.int(-3, hard ? 8 : 4);
  const terms = Array.from({ length: 6 }, (_, i) => (k + i) ** 2 + c);
  return { terms, rule: `Perfect squares ${c === 0 ? '' : c > 0 ? `plus ${c}` : `minus ${-c}`}`.trim() };
};

const doubleAdd: Family = (rng, hard) => {
  const k = rng.chance(0.5) ? rng.int(1, hard ? 5 : 3) : -rng.int(1, 3);
  const terms = [rng.int(hard ? 3 : 2, 8)];
  for (let i = 0; i < 5; i++) terms.push(terms[i] * 2 + k);
  return { terms, rule: `Double, then ${k >= 0 ? 'add' : 'subtract'} ${Math.abs(k)}` };
};

const fibonacci: Family = (rng, hard) => {
  const terms = [rng.int(1, hard ? 7 : 4), rng.int(1, hard ? 7 : 4)];
  for (let i = 2; i < 6; i++) terms.push(terms[i - 1] + terms[i - 2]);
  return { terms, rule: 'Each term is the sum of the two before it' };
};

export function familiesForLevel(level: number): { name: string; build: Family }[] {
  const all = [
    { name: 'arithmetic', build: arithmetic },
    { name: 'geometric', build: geometric },
  ];
  if (level >= 2) all.push({ name: 'growing', build: growing }, { name: 'alternating', build: alternating });
  if (level >= 3) all.push({ name: 'squares', build: squares }, { name: 'doubleAdd', build: doubleAdd });
  if (level >= 4) all.push({ name: 'fibonacci', build: fibonacci });
  return all;
}

export function generatePuzzle(rng: Rng, level: number): Puzzle {
  const fam = rng.pick(familiesForLevel(level));
  const built = fam.build(rng, level >= 4);
  const terms = built.terms.slice(0, 5);
  const answer = built.terms[5];
  const last = terms[4];
  const prev = terms[3];

  const candidates = [answer + 1, answer - 1, answer + 2, answer - 2, answer + (answer - last), last + (last - prev), answer * 2, last];
  const pool = Array.from(new Set(candidates.filter((c) => c !== answer)));
  const options = rng.shuffle(pool).slice(0, 3);
  while (options.length < 3) {
    const extra = answer + rng.int(3, 12) * (rng.chance(0.5) ? 1 : -1);
    if (extra !== answer && !options.includes(extra)) options.push(extra);
  }
  return {
    family: fam.name,
    terms,
    answer,
    options: rng.shuffle([answer, ...options]),
    rule: built.rule,
  };
}

export interface SequenceScore {
  points: number;
  accuracy: number;
  nextLevel: number;
  summary: string;
}

const FAST_MS = 4000;
const SLOW_MS = 20000;

export function scoreSequence(level: number, correct: number, total: number, meanRtMs: number): SequenceScore {
  const accuracy = total === 0 ? 0 : correct / total;
  const speed = clamp01((SLOW_MS - meanRtMs) / (SLOW_MS - FAST_MS));
  const norm = clamp01(accuracy * (0.7 + 0.3 * speed));
  const nextLevel = accuracy >= 0.8 ? Math.min(SEQUENCE_MAX_LEVEL, level + 1) : accuracy < 0.4 ? Math.max(1, level - 1) : level;
  return {
    points: Math.round(1000 * norm),
    accuracy,
    nextLevel,
    summary: `${correct}/${total} solved, ${(meanRtMs / 1000).toFixed(1)}s per puzzle`,
  };
}
