import type { Rng } from '../rng';
import { clamp01 } from '../time';

export type SpanMode = 'forward' | 'backward';

export const SPAN_START = 3;
export const SPAN_LIVES = 2;
export const SPAN_MAX = 12;

export interface SpanState {
  length: number;
  lives: number;
  best: number;
  trials: number;
  correct: number;
}

export const initialSpan = (): SpanState => ({ length: SPAN_START, lives: SPAN_LIVES, best: 0, trials: 0, correct: 0 });

/** Digits 0-9 with no digit repeated back to back. */
export function generateDigits(rng: Rng, length: number): number[] {
  const out: number[] = [];
  while (out.length < length) {
    const d = rng.int(0, 9);
    if (out[out.length - 1] !== d) out.push(d);
  }
  return out;
}

export function expectedAnswer(seq: number[], mode: SpanMode): number[] {
  return mode === 'backward' ? seq.slice().reverse() : seq.slice();
}

export function checkSpan(seq: number[], answer: number[], mode: SpanMode): boolean {
  const expected = expectedAnswer(seq, mode);
  return expected.length === answer.length && expected.every((d, i) => d === answer[i]);
}

export function advanceSpan(s: SpanState, correct: boolean): SpanState {
  if (correct) {
    return {
      ...s,
      best: Math.max(s.best, s.length),
      length: Math.min(SPAN_MAX, s.length + 1),
      trials: s.trials + 1,
      correct: s.correct + 1,
    };
  }
  return { ...s, lives: s.lives - 1, trials: s.trials + 1 };
}

export const isSpanOver = (s: SpanState) => s.lives <= 0 || s.best >= SPAN_MAX;

export function spanPoints(best: number): number {
  return Math.round(1000 * clamp01((best - 2) / 8));
}
