export type DayKey = string; // local calendar day, "YYYY-MM-DD"

export interface DayActivity {
  focusMs: number;
  sessions: number;
  reviews: number;
  newCards: number;
  drills: number;
  tasksDone: number;
  xp: number;
}

export interface Task {
  id: string;
  title: string;
  day: DayKey;
  createdAt: number;
  doneAt: number | null;
  focusMs: number;
}

export type TimerKind = 'focus' | 'break';

/** How the native companion silences notifications during a guarded session. */
export type DndMode = 'off' | 'priority' | 'alarms';

/** What the Android focus guard does for one session. Captured when the session starts. */
export interface GuardConfig {
  blockedApps: string[];
  floatingTimer: boolean;
  dndMode: DndMode;
}

export interface ActiveTimer {
  id: string;
  kind: TimerKind;
  startedAt: number;
  plannedMs: number;
  pausedAt: number | null;
  pausedTotalMs: number;
  taskId: string | null;
  label: string;
  distractions: number;
  /** Present only when the session runs with the Android focus guard. */
  guard?: GuardConfig | null;
}

export interface FocusSession {
  id: string;
  startedAt: number;
  endedAt: number;
  plannedMs: number;
  actualMs: number;
  completed: boolean;
  taskId: string | null;
  label: string;
  distractions: number;
  dayKey: DayKey;
  xp: number;
}

export type Grade = 'again' | 'hard' | 'good' | 'easy';
export type Phase = 'new' | 'learning' | 'review';

export interface SrsState {
  phase: Phase;
  step: number;
  ease: number;
  intervalDays: number;
  reps: number;
  lapses: number;
  due: number;
  lastReviewedAt: number | null;
}

export interface Deck {
  id: string;
  name: string;
  color: string;
  createdAt: number;
}

export interface Card {
  id: string;
  deckId: string;
  front: string;
  back: string;
  createdAt: number;
  srs: SrsState;
}

export type DrillKind = 'span' | 'schulte' | 'stroop' | 'nback' | 'sequence';

export interface DrillResult {
  id: string;
  kind: DrillKind;
  at: number;
  dayKey: DayKey;
  points: number;
  summary: string;
  accuracy: number | null;
  durationMs: number;
  level: number;
  xp: number;
}

export interface DrillStats {
  best: number;
  bestAt: number;
  plays: number;
  lastPlayedAt: number;
}

export interface Settings {
  dailyFocusGoalMin: number;
  dailyReviewGoal: number;
  dailyDrillGoal: number;
  focusMin: number;
  breakMin: number;
  newCardsPerDay: number;
  haptics: boolean;
  notifications: boolean;
  typedRecall: boolean;
  /** Android focus guard: run focus blocks with app blocking, floating timer and notification control. */
  guardEnabled: boolean;
  /** Package names of the apps to block during a guarded session. */
  blockedApps: string[];
  floatingTimer: boolean;
  dndMode: DndMode;
  /** Base URL of the AI tutor backend. Empty means "use the build-time default, if any". */
  aiEndpoint: string;
}

export interface Profile {
  name: string;
  createdAt: number;
  onboarded: boolean;
}

export interface PersistedState {
  version: number;
  profile: Profile;
  settings: Settings;
  xp: number;
  activity: Record<DayKey, DayActivity>;
  tasks: Task[];
  sessions: FocusSession[];
  timer: ActiveTimer | null;
  decks: Deck[];
  cards: Card[];
  drills: {
    results: DrillResult[];
    stats: Partial<Record<DrillKind, DrillStats>>;
    levels: Partial<Record<DrillKind, number>>;
  };
  achievements: Record<string, number>;
}

export interface Toast {
  id: string;
  kind: 'level' | 'achievement' | 'info';
  title: string;
  body: string;
}

export interface AppState extends PersistedState {
  hydrated: boolean;
  toasts: Toast[];
}
