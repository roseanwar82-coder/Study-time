import type { Grade } from './types';
import { MINUTE } from './time';

export const ACHIEVEMENT_XP = 25;

/** Total XP required to reach a level. Level 1 = 0, 2 = 100, 3 = 300, 4 = 600... */
export function xpForLevel(level: number): number {
  return 50 * level * (level - 1);
}

export function levelFromXp(xp: number): number {
  const safe = Math.max(0, xp);
  let level = Math.max(1, Math.floor((1 + Math.sqrt(1 + safe / 12.5)) / 2));
  while (xpForLevel(level + 1) <= safe) level++;
  while (level > 1 && xpForLevel(level) > safe) level--;
  return level;
}

export interface LevelProgress {
  level: number;
  current: number;
  needed: number;
  ratio: number;
}

export function levelProgress(xp: number): LevelProgress {
  const level = levelFromXp(xp);
  const floor = xpForLevel(level);
  const needed = xpForLevel(level + 1) - floor;
  const current = Math.max(0, xp) - floor;
  return { level, current, needed, ratio: needed === 0 ? 0 : current / needed };
}

const TITLES = ['Novice', 'Apprentice', 'Adept', 'Scholar', 'Strategist', 'Sage', 'Luminary', 'Grandmaster'];

export function levelTitle(level: number): string {
  return TITLES[Math.min(TITLES.length - 1, Math.floor((level - 1) / 3))];
}

export function xpForFocus(actualMs: number, completed: boolean, distractions: number): number {
  const minutes = Math.floor(actualMs / MINUTE);
  if (minutes < 1) return 0;
  const base = Math.min(minutes, 180) * 2;
  const bonus = completed ? 10 : 0;
  const penalty = Math.min(Math.max(0, distractions) * 2, Math.floor(base * 0.3));
  return Math.max(0, base + bonus - penalty);
}

export function xpForReview(grade: Grade): number {
  return grade === 'again' ? 1 : grade === 'easy' ? 3 : 2;
}

/** points is the 0-1000 drill score. A personal best adds a flat bonus. */
export function xpForDrill(points: number, personalBest: boolean): number {
  const clamped = Math.min(1000, Math.max(0, points));
  return 10 + Math.round((clamped / 1000) * 30) + (personalBest ? 10 : 0);
}
