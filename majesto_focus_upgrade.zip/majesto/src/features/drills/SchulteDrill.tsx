import { useMemo, useRef, useState } from 'react';
import { Pressable, StyleSheet, View, useWindowDimensions } from 'react-native';
import { createRng } from '@/core/rng';
import { generateGrid, scoreSchulte } from '@/core/drills/schulte';
import { formatClock } from '@/core/time';
import { haptic } from '@/services/haptics';
import { useNow } from '@/ui/hooks';
import { Txt } from '@/ui/Text';
import { areaColor, colors, radius, space } from '@/ui/theme';
import type { DrillProps } from './types';

const GAP = 8;

export function SchulteDrill({ level: size, onFinish }: DrillProps) {
  const grid = useMemo(() => generateGrid(createRng(), size), [size]);
  const startedAt = useRef(Date.now());
  const [next, setNext] = useState(1);
  const [errors, setErrors] = useState(0);
  const [wrong, setWrong] = useState<number | null>(null);
  const now = useNow(true, 200);
  const { width } = useWindowDimensions();

  const boardWidth = Math.min(width, 480) - space.xl * 2;
  const cell = Math.floor((boardWidth - GAP * (size - 1)) / size);
  const total = size * size;

  const press = (n: number) => {
    if (n === next) {
      haptic.tap();
      if (n === total) {
        const s = scoreSchulte(size, Date.now() - startedAt.current, errors);
        onFinish({
          points: s.points,
          summary: s.summary,
          accuracy: total / (total + errors),
          durationMs: Date.now() - startedAt.current,
          nextLevel: s.nextSize,
        });
      } else {
        setNext(n + 1);
      }
    } else {
      haptic.error();
      setErrors((e) => e + 1);
      setWrong(n);
      setTimeout(() => setWrong((w) => (w === n ? null : w)), 250);
    }
  };

  return (
    <View style={styles.wrap}>
      <View style={styles.header}>
        <View>
          <Txt variant="caption" color="textDim">Find</Txt>
          <Txt variant="title" style={{ color: areaColor.drills }}>{next}</Txt>
        </View>
        <View style={{ alignItems: 'flex-end' }}>
          <Txt variant="caption" color="textDim">Time</Txt>
          <Txt variant="title" style={{ fontVariant: ['tabular-nums'] }}>{formatClock(now - startedAt.current).replace(/^0/, '')}</Txt>
        </View>
        <View style={{ alignItems: 'flex-end' }}>
          <Txt variant="caption" color="textDim">Misses</Txt>
          <Txt variant="title" style={{ color: errors ? colors.danger : colors.text }}>{errors}</Txt>
        </View>
      </View>
      <View style={{ width: boardWidth, flexDirection: 'row', flexWrap: 'wrap', gap: GAP }}>
        {grid.map((n) => {
          const done = n < next;
          return (
            <Pressable
              key={n}
              accessibilityRole="button"
              accessibilityLabel={`${n}`}
              onPress={() => press(n)}
              style={[
                styles.cell,
                { width: cell, height: cell },
                done && { opacity: 0.25 },
                wrong === n && { backgroundColor: colors.danger + '55', borderColor: colors.danger },
              ]}
            >
              <Txt variant="title" style={{ fontSize: size === 5 ? 22 : 26 }}>{n}</Txt>
            </Pressable>
          );
        })}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { flex: 1, alignItems: 'center', gap: space.xl },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignSelf: 'stretch' },
  cell: {
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: colors.surface,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.border,
  },
});
