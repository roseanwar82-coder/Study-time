import { useEffect, useMemo, useRef, useState } from 'react';
import { Pressable, StyleSheet, View } from 'react-native';
import { createRng } from '@/core/rng';
import { SEQUENCE_ROUND, generatePuzzle, scoreSequence } from '@/core/drills/sequence';
import { haptic } from '@/services/haptics';
import { ProgressBar } from '@/ui/Progress';
import { Txt } from '@/ui/Text';
import { areaColor, colors, fonts, radius, space } from '@/ui/theme';
import type { DrillProps } from './types';

const REVEAL_MS = 1300;

export function SequenceDrill({ level, onFinish }: DrillProps) {
  const puzzles = useMemo(() => {
    const rng = createRng();
    return Array.from({ length: SEQUENCE_ROUND }, () => generatePuzzle(rng, level));
  }, [level]);
  const startedAt = useRef(Date.now());
  const puzzleStart = useRef(Date.now());
  const rts = useRef<number[]>([]);
  const [index, setIndex] = useState(0);
  const [picked, setPicked] = useState<number | null>(null);
  const [correctCount, setCorrectCount] = useState(0);
  const alive = useRef(true);
  useEffect(() => () => {
    alive.current = false;
  }, []);

  const puzzle = puzzles[index];
  const locked = picked !== null;

  const choose = (value: number) => {
    if (locked) return;
    const ok = value === puzzle.answer;
    rts.current.push(Date.now() - puzzleStart.current);
    ok ? haptic.success() : haptic.error();
    setPicked(value);
    const total = ok ? correctCount + 1 : correctCount;
    if (ok) setCorrectCount(total);

    setTimeout(() => {
      if (!alive.current) return;
      if (index + 1 >= SEQUENCE_ROUND) {
        const mean = rts.current.reduce((a, b) => a + b, 0) / rts.current.length;
        const s = scoreSequence(level, total, SEQUENCE_ROUND, mean);
        onFinish({ points: s.points, summary: s.summary, accuracy: s.accuracy, durationMs: Date.now() - startedAt.current, nextLevel: s.nextLevel });
        return;
      }
      puzzleStart.current = Date.now();
      setPicked(null);
      setIndex(index + 1);
    }, REVEAL_MS);
  };

  return (
    <View style={styles.wrap}>
      <View style={{ gap: space.sm }}>
        <Txt variant="small" color="textDim">Puzzle {index + 1} of {SEQUENCE_ROUND}</Txt>
        <ProgressBar ratio={index / SEQUENCE_ROUND} color={areaColor.drills} />
      </View>

      <View style={styles.stage}>
        <View style={styles.terms}>
          {puzzle.terms.map((t, i) => (
            <Txt key={i} style={styles.term}>{t}</Txt>
          ))}
          <Txt style={[styles.term, { color: areaColor.drills }]}>?</Txt>
        </View>
        <Txt variant="small" color={locked ? (picked === puzzle.answer ? 'success' : 'danger') : 'textDim'} style={{ textAlign: 'center', minHeight: 40 }}>
          {locked ? `${picked === puzzle.answer ? 'Correct' : `The answer was ${puzzle.answer}`}. ${puzzle.rule}.` : 'What comes next?'}
        </Txt>
      </View>

      <View style={styles.options}>
        {puzzle.options.map((o) => {
          const isAnswer = locked && o === puzzle.answer;
          const isWrongPick = locked && o === picked && o !== puzzle.answer;
          return (
            <Pressable
              key={o}
              accessibilityRole="button"
              accessibilityLabel={String(o)}
              onPress={() => choose(o)}
              style={[styles.option, isAnswer && { borderColor: colors.success }, isWrongPick && { borderColor: colors.danger }]}
            >
              <Txt variant="title">{o}</Txt>
            </Pressable>
          );
        })}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { flex: 1, gap: space.xl },
  stage: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    gap: space.xl,
    borderRadius: radius.lg,
    borderWidth: 1,
    borderColor: colors.border,
    backgroundColor: colors.surface,
    padding: space.lg,
  },
  terms: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'center', gap: 14 },
  term: { fontFamily: fonts.serif, fontSize: 34, lineHeight: 42, color: colors.text, fontVariant: ['tabular-nums'] },
  options: { flexDirection: 'row', flexWrap: 'wrap', gap: space.md },
  option: {
    width: '47.5%',
    height: 64,
    borderRadius: radius.md,
    borderWidth: 2,
    borderColor: colors.border,
    backgroundColor: colors.surface,
    alignItems: 'center',
    justifyContent: 'center',
  },
});
