import { useEffect, useRef, useState } from 'react';
import { Pressable, StyleSheet, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { createRng } from '@/core/rng';
import {
  SPAN_LIVES, SPAN_START, advanceSpan, checkSpan, expectedAnswer, generateDigits, initialSpan, isSpanOver, spanPoints,
  type SpanMode,
} from '@/core/drills/span';
import { haptic } from '@/services/haptics';
import { Txt } from '@/ui/Text';
import { areaColor, colors, fonts, radius, space } from '@/ui/theme';
import type { DrillProps } from './types';

type Phase = 'show' | 'input' | 'feedback';

const SHOW_MS = 800;
const STEP_MS = 1000;
const LEAD_MS = 600;
const FEEDBACK_MS = 1100;

export function SpanDrill({ level, onFinish }: DrillProps) {
  const mode: SpanMode = level === 2 ? 'backward' : 'forward';
  const rng = useRef(createRng()).current;
  const startedAt = useRef(Date.now());

  const [game, setGame] = useState(initialSpan);
  const [seq, setSeq] = useState(() => generateDigits(rng, SPAN_START));
  const [phase, setPhase] = useState<Phase>('show');
  const [shown, setShown] = useState(-1);
  const [answer, setAnswer] = useState<number[]>([]);
  const [ok, setOk] = useState<boolean | null>(null);

  // Show the digits one at a time.
  useEffect(() => {
    if (phase !== 'show') return;
    const timers: ReturnType<typeof setTimeout>[] = [];
    seq.forEach((_, i) => {
      timers.push(setTimeout(() => setShown(i), LEAD_MS + i * STEP_MS));
      timers.push(setTimeout(() => setShown(-1), LEAD_MS + i * STEP_MS + SHOW_MS));
    });
    timers.push(setTimeout(() => setPhase('input'), LEAD_MS + seq.length * STEP_MS));
    return () => timers.forEach(clearTimeout);
  }, [phase, seq]);

  // After feedback, move on or finish.
  useEffect(() => {
    if (phase !== 'feedback') return;
    const t = setTimeout(() => {
      if (isSpanOver(game)) {
        onFinish({
          points: spanPoints(game.best),
          summary: game.best > 0 ? `Longest span ${game.best}, ${game.correct}/${game.trials} correct` : 'No span completed',
          accuracy: game.trials ? game.correct / game.trials : 0,
          durationMs: Date.now() - startedAt.current,
          nextLevel: level,
        });
        return;
      }
      setSeq(generateDigits(rng, game.length));
      setAnswer([]);
      setOk(null);
      setShown(-1);
      setPhase('show');
    }, FEEDBACK_MS);
    return () => clearTimeout(t);
  }, [phase]); // eslint-disable-line react-hooks/exhaustive-deps

  const submit = (final: number[]) => {
    const correct = checkSpan(seq, final, mode);
    correct ? haptic.success() : haptic.error();
    setOk(correct);
    setGame((g) => advanceSpan(g, correct));
    setPhase('feedback');
  };

  const press = (d: number) => {
    if (phase !== 'input' || answer.length >= seq.length) return;
    haptic.tap();
    const next = [...answer, d];
    setAnswer(next);
    if (next.length === seq.length) submit(next);
  };

  // `game` inside the feedback effect is read after the state update from submit().
  const livesLeft = game.lives;

  return (
    <View style={styles.wrap}>
      <View style={styles.header}>
        <Txt variant="small" color="textDim">{mode === 'backward' ? 'Backward' : 'Forward'} span</Txt>
        <View style={{ flexDirection: 'row', gap: 6 }}>
          {Array.from({ length: SPAN_LIVES }, (_, i) => (
            <Ionicons key={i} name={i < livesLeft ? 'heart' : 'heart-outline'} size={18} color={i < livesLeft ? areaColor.drills : colors.textFaint} />
          ))}
        </View>
      </View>

      <View style={styles.stage}>
        {phase === 'show' ? (
          <>
            <Txt style={styles.digit}>{shown >= 0 ? seq[shown] : ''}</Txt>
            <Txt variant="small" color="textDim">Remember {seq.length} digits{mode === 'backward' ? ', then repeat them in reverse' : ''}</Txt>
          </>
        ) : (
          <>
            <View style={styles.slots}>
              {seq.map((_, i) => {
                const filled = i < answer.length;
                return (
                  <View key={i} style={[styles.slot, filled && { borderColor: areaColor.drills }]}>
                    <Txt variant="title">{filled ? answer[i] : ''}</Txt>
                  </View>
                );
              })}
            </View>
            {phase === 'feedback' ? (
              <View style={{ alignItems: 'center', gap: 4 }}>
                <Txt variant="heading" style={{ color: ok ? colors.success : colors.danger }}>{ok ? 'Correct' : 'Not quite'}</Txt>
                {!ok ? <Txt variant="small" color="textDim">It was {expectedAnswer(seq, mode).join(' ')}</Txt> : null}
              </View>
            ) : (
              <Txt variant="small" color="textDim">{mode === 'backward' ? 'Type them in reverse' : 'Type them in order'}</Txt>
            )}
          </>
        )}
      </View>

      <View style={[styles.pad, phase !== 'input' && { opacity: 0.3 }]} pointerEvents={phase === 'input' ? 'auto' : 'none'}>
        {[1, 2, 3, 4, 5, 6, 7, 8, 9].map((d) => (
          <Key key={d} label={String(d)} onPress={() => press(d)} />
        ))}
        <View style={styles.keySpacer} />
        <Key label="0" onPress={() => press(0)} />
        <Key icon="backspace-outline" label="Delete" onPress={() => setAnswer((a) => a.slice(0, -1))} />
      </View>
    </View>
  );
}

function Key({ label, icon, onPress }: { label: string; icon?: 'backspace-outline'; onPress: () => void }) {
  return (
    <Pressable accessibilityRole="button" accessibilityLabel={label} onPress={onPress} style={({ pressed }) => [styles.key, pressed && { backgroundColor: colors.surfaceHi }]}>
      {icon ? <Ionicons name={icon} size={24} color={colors.text} /> : <Txt variant="title">{label}</Txt>}
    </Pressable>
  );
}

const styles = StyleSheet.create({
  wrap: { flex: 1, gap: space.xl },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  stage: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: space.xl },
  digit: { fontFamily: fonts.serif, fontSize: 120, lineHeight: 130, color: colors.text, fontVariant: ['tabular-nums'] },
  slots: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, justifyContent: 'center' },
  slot: {
    width: 36,
    height: 48,
    borderRadius: radius.sm,
    borderWidth: 1,
    borderColor: colors.border,
    backgroundColor: colors.surface,
    alignItems: 'center',
    justifyContent: 'center',
  },
  pad: { flexDirection: 'row', flexWrap: 'wrap', gap: 10, justifyContent: 'center' },
  key: {
    width: '31%',
    height: 56,
    borderRadius: radius.md,
    backgroundColor: colors.surface,
    borderWidth: 1,
    borderColor: colors.border,
    alignItems: 'center',
    justifyContent: 'center',
  },
  keySpacer: { width: '31%', height: 56 },
});
