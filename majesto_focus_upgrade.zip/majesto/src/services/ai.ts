import { askTutor, normalizeEndpoint, type TutorAnswer, type TutorRequest } from '@/core/ai';
import { store } from '@/store';

/**
 * Where the AI tutor lives. The address can be set in Focus guard settings, or at build time with
 * EXPO_PUBLIC_AI_ENDPOINT. The optional access token is build-time only (EXPO_PUBLIC_AI_TOKEN).
 * Neither is a secret that unlocks the AI provider: the provider key stays on the backend.
 */
export function aiEndpoint(): string | null {
  return normalizeEndpoint(store.get().settings.aiEndpoint) ?? normalizeEndpoint(process.env.EXPO_PUBLIC_AI_ENDPOINT);
}

export function aiConfigured(): boolean {
  return aiEndpoint() !== null;
}

export function askAi(req: TutorRequest): Promise<TutorAnswer> {
  return askTutor(req, { endpoint: aiEndpoint(), token: process.env.EXPO_PUBLIC_AI_TOKEN });
}

export interface BackendCheck {
  ok: boolean;
  message: string;
}

/** Asks the backend's /health route, so the person can tell whether the address and server are right. */
export async function checkBackend(endpoint: string | null = aiEndpoint()): Promise<BackendCheck> {
  const base = normalizeEndpoint(endpoint);
  if (!base) return { ok: false, message: 'Enter an address that starts with https://.' };
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 8000);
  try {
    const res = await fetch(`${base}/health`, { signal: controller.signal });
    const body = (await res.json().catch(() => null)) as { ok?: boolean; configured?: boolean } | null;
    if (!res.ok || !body?.ok) return { ok: false, message: `The server answered, but not like a Majesto AI backend (${res.status}).` };
    if (body.configured === false) return { ok: false, message: 'The backend is running, but its AI provider key is not set yet.' };
    return { ok: true, message: 'Connected. AI help is ready.' };
  } catch {
    return { ok: false, message: 'Could not reach that address. Check it and your internet connection.' };
  } finally {
    clearTimeout(timer);
  }
}
