import { Platform } from 'react-native';
import { requireOptionalNativeModule } from 'expo';
import {
  EMPTY_NATIVE_SESSION, type GuardOptions, type GuardPermissions, type NativeCommand, type NativeSession, type NativeTimer,
} from '@/core/guard';

/**
 * Thin, crash-proof wrapper around the Android module in modules/majesto-focus.
 * On iOS, in Expo Go, or in any build without the module, every call quietly does nothing and
 * `isSupported` is false, so screens can hide the Android-only controls instead of failing.
 */

export interface InstalledApp {
  packageName: string;
  label: string;
  /** Base64 PNG, 96px. */
  icon: string | null;
}

export interface StartStatus {
  serviceStarted: boolean;
  floatingTimer: boolean;
  blocking: boolean;
  dnd: boolean;
}

export type PermissionKind = 'overlay' | 'usageAccess' | 'accessibility' | 'notificationPolicy' | 'notifications';

export interface GuardEvents {
  onCommand: { command: NativeCommand; at: number };
  onBlocked: { packageName: string; label: string; attempts: number };
  onSessionEnded: { reason: 'expired'; at: number };
  onScreenshot: { path?: string; error?: 'denied' | 'unavailable' | 'timeout' | 'failed' };
  onSharedImage: { path?: string; error?: string };
}

interface Subscription {
  remove(): void;
}

interface NativeShape {
  isSupported(): boolean;
  getPermissions(): GuardPermissions;
  openSettings(kind: PermissionKind): boolean;
  listApps(): Promise<InstalledApp[]>;
  startSession(timer: NativeTimer, options: GuardOptions): StartStatus;
  syncTimer(timer: NativeTimer): void;
  ackCommand(): void;
  stopGuard(): void;
  getSessionState(): NativeSession;
  captureScreen(minimize: boolean): void;
  minimizeApp(): void;
  checkShareIntent(): void;
  hasPendingImage(): boolean;
  takePendingImage(): string | null;
  readImageBase64(path: string): Promise<string>;
  deleteImage(path: string): boolean;
  addListener(event: string, listener: (payload: never) => void): Subscription;
}

const native: NativeShape | null =
  Platform.OS === 'android' ? requireOptionalNativeModule<NativeShape>('MajestoFocus') : null;

const NONE: GuardPermissions = { overlay: false, usageAccess: false, accessibility: false, notificationPolicy: false, notifications: true };

/** Runs a native call and returns the fallback if it throws. Native problems must never take the app down. */
function safe<T>(fallback: T, fn: (n: NativeShape) => T): T {
  if (!native) return fallback;
  try {
    return fn(native);
  } catch {
    return fallback;
  }
}

export const focusGuard = {
  /** True only on an Android build that includes the native module. */
  isSupported: !!native,

  getPermissions: (): GuardPermissions => safe(NONE, (n) => n.getPermissions()),
  openSettings: (kind: PermissionKind): boolean => safe(false, (n) => n.openSettings(kind)),
  listApps: async (): Promise<InstalledApp[]> => {
    if (!native) return [];
    return native.listApps();
  },

  startSession: (timer: NativeTimer, options: GuardOptions): StartStatus | null => safe<StartStatus | null>(null, (n) => n.startSession(timer, options)),
  syncTimer: (timer: NativeTimer): void => safe(undefined, (n) => n.syncTimer(timer)),
  ackCommand: (): void => safe(undefined, (n) => n.ackCommand()),
  stopGuard: (): void => safe(undefined, (n) => n.stopGuard()),
  getSessionState: (): NativeSession => safe(EMPTY_NATIVE_SESSION, (n) => n.getSessionState()),

  captureScreen: (minimize: boolean): void => safe(undefined, (n) => n.captureScreen(minimize)),
  minimizeApp: (): void => safe(undefined, (n) => n.minimizeApp()),
  checkShareIntent: (): void => safe(undefined, (n) => n.checkShareIntent()),
  hasPendingImage: (): boolean => safe(false, (n) => n.hasPendingImage()),
  takePendingImage: (): string | null => safe<string | null>(null, (n) => n.takePendingImage()),
  readImageBase64: async (path: string): Promise<string> => {
    if (!native) throw new Error('Screenshots are only available on Android.');
    return native.readImageBase64(path);
  },
  deleteImage: (path: string): void => safe(undefined, (n) => void n.deleteImage(path)),

  on<K extends keyof GuardEvents>(event: K, listener: (payload: GuardEvents[K]) => void): () => void {
    if (!native) return () => {};
    try {
      const sub = native.addListener(event, listener as (payload: never) => void);
      return () => {
        try {
          sub.remove();
        } catch {
          // already removed
        }
      };
    } catch {
      return () => {};
    }
  },
};
