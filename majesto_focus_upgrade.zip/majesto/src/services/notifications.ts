import { Platform } from 'react-native';
import * as Notifications from 'expo-notifications';
import { store } from '@/store';

const TIMER_ID = 'majesto-timer';
const CHANNEL_ID = 'timer';

let setup: Promise<void> | null = null;

/**
 * One-time setup. Safe to call any number of times.
 * - Shows alerts that arrive while the app is open (SDK 57 hides them unless a handler says otherwise).
 * - Creates the Android channel. On Android 13+ the permission prompt only appears once a channel exists,
 *   so this must finish before we ask for permission.
 */
export function initNotifications(): Promise<void> {
  if (!setup) {
    setup = (async () => {
      try {
        Notifications.setNotificationHandler({
          handleNotification: async () => ({
            shouldShowBanner: true,
            shouldShowList: true,
            shouldPlaySound: true,
            shouldSetBadge: false,
          }),
        });
        if (Platform.OS === 'android') {
          await Notifications.setNotificationChannelAsync(CHANNEL_ID, {
            name: 'Focus timer',
            importance: Notifications.AndroidImportance.HIGH,
          });
        }
      } catch {
        // Notifications are a nicety. The timer works without them.
      }
    })();
  }
  return setup;
}

/** Ask once. Returns true when we are allowed to notify. */
export async function ensureNotificationPermission(): Promise<boolean> {
  try {
    await initNotifications();
    const current = await Notifications.getPermissionsAsync();
    if (current.granted) return true;
    if (!current.canAskAgain) return false;
    const asked = await Notifications.requestPermissionsAsync();
    return asked.granted;
  } catch {
    return false;
  }
}

/** Schedule a "time is up" alert for when the running timer ends. */
export async function scheduleTimerEnd(seconds: number, kind: 'focus' | 'break'): Promise<void> {
  if (!store.get().settings.notifications || seconds < 1) return;
  try {
    if (!(await ensureNotificationPermission())) return;
    await Notifications.scheduleNotificationAsync({
      identifier: TIMER_ID,
      content: {
        title: kind === 'focus' ? 'Focus block complete' : 'Break is over',
        body: kind === 'focus' ? 'Nice work. Come back to log it and take a break.' : 'Ready for the next block?',
        sound: true,
      },
      trigger: {
        type: Notifications.SchedulableTriggerInputTypes.TIME_INTERVAL,
        seconds: Math.max(1, Math.round(seconds)),
        channelId: CHANNEL_ID,
      },
    });
  } catch {
    // ignore
  }
}

export async function cancelTimerEnd(): Promise<void> {
  try {
    await Notifications.cancelScheduledNotificationAsync(TIMER_ID);
  } catch {
    // ignore
  }
}
