import type { PersistedState } from '@/core/types';

/**
 * Cloud sync seam. Majesto is offline-first: the phone is always the source of truth
 * and everything works with no account. A sync adapter mirrors the persisted snapshot
 * to a backend, and merges what it pulls back.
 *
 * Wiring up Supabase (suggested):
 *   1. `npx expo install @supabase/supabase-js` and create the client with
 *      EXPO_PUBLIC_SUPABASE_URL / EXPO_PUBLIC_SUPABASE_ANON_KEY (see .env.example).
 *   2. Table `snapshots(user_id uuid primary key references auth.users, data jsonb, updated_at timestamptz)`
 *      with a row level security policy `user_id = auth.uid()`.
 *   3. Implement `SyncAdapter` below: push = upsert the snapshot, pull = select it.
 *   4. Merge on pull instead of overwriting: union decks and cards by id, keep the card with the
 *      later `srs.lastReviewedAt`, and take the max of per-day activity. Start from `toPersisted`
 *      and `migrate` in src/store/state.ts.
 */
export interface SyncAdapter {
  readonly name: string;
  push(snapshot: PersistedState): Promise<void>;
  pull(): Promise<PersistedState | null>;
}

export const localOnlySync: SyncAdapter = {
  name: 'local',
  push: async () => {},
  pull: async () => null,
};

export function isSyncConfigured(): boolean {
  return Boolean(process.env.EXPO_PUBLIC_SUPABASE_URL && process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY);
}
