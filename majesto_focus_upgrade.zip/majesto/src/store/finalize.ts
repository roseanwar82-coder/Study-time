import type { AppState, DayActivity, DayKey } from '@/core/types';
import { ACHIEVEMENTS, computeMetrics } from '@/core/achievements';
import { emptyActivity } from '@/core/streak';
import { dayKey } from '@/core/time';
import { ACHIEVEMENT_XP, levelFromXp, levelTitle } from '@/core/xp';

export function withActivity(s: AppState, key: DayKey, delta: Partial<DayActivity>): AppState {
  const next: DayActivity = { ...(s.activity[key] ?? emptyActivity()) };
  for (const k of Object.keys(delta) as (keyof DayActivity)[]) next[k] += delta[k] ?? 0;
  return { ...s, activity: { ...s.activity, [key]: next } };
}

export function withXp(s: AppState, key: DayKey, amount: number): AppState {
  if (amount <= 0) return s;
  return withActivity({ ...s, xp: s.xp + amount }, key, { xp: amount });
}

const MAX_TOASTS = 5;

/** Runs after every action: unlocks achievements and queues level-up toasts. */
export function finalize(prev: AppState, next: AppState, now: number, id: (p?: string) => string): AppState {
  if (!next.hydrated) return next;
  const today = dayKey(now);
  let s = next;

  for (let pass = 0; pass < 3; pass++) {
    const metrics = computeMetrics(s, now);
    const fresh = ACHIEVEMENTS.filter((a) => !s.achievements[a.id] && a.progress(metrics) >= a.target);
    if (fresh.length === 0) break;
    const achievements = { ...s.achievements };
    for (const a of fresh) achievements[a.id] = now;
    s = {
      ...s,
      achievements,
      toasts: [
        ...s.toasts,
        ...fresh.map((a) => ({ id: id('toast'), kind: 'achievement' as const, title: a.title, body: a.description })),
      ],
    };
    s = withXp(s, today, fresh.length * ACHIEVEMENT_XP);
  }

  const before = levelFromXp(prev.xp);
  const after = levelFromXp(s.xp);
  if (after > before) {
    s = { ...s, toasts: [...s.toasts, { id: id('toast'), kind: 'level', title: `Level ${after}`, body: levelTitle(after) }] };
  }
  if (s.toasts.length > MAX_TOASTS) s = { ...s, toasts: s.toasts.slice(-MAX_TOASTS) };
  return s;
}
