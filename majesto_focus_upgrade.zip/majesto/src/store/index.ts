import AsyncStorage from '@react-native-async-storage/async-storage';
import type { AppState } from '@/core/types';
import { makeId } from '@/core/ids';
import { createActions } from './actions';
import { attachPersistence, type PersistenceHandle } from './persistence';
import { useSelector } from './react';
import { createInitialState } from './state';
import { createStore } from './store';

export const store = createStore<AppState>(createInitialState(Date.now(), makeId));
export const actions = createActions(store, { now: () => Date.now(), id: makeId });

export function useApp<R>(selector: (state: AppState) => R): R {
  return useSelector(store, selector);
}

let persistence: PersistenceHandle | null = null;

/** Load saved data, then start saving changes. Safe to call more than once. */
export async function bootstrap(): Promise<void> {
  if (persistence) return;
  await actions.hydrate(AsyncStorage);
  persistence = attachPersistence(store, AsyncStorage);
  await persistence.flush();
}

export function flushNow(): Promise<void> {
  return persistence ? persistence.flush() : Promise.resolve();
}
