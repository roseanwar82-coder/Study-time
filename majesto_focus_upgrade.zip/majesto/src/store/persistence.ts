import type { AppState } from '@/core/types';
import type { Store } from './store';
import { PERSISTED_KEYS, STORAGE_KEY, toPersisted } from './state';

export interface StorageAdapter {
  getItem(key: string): Promise<string | null>;
  setItem(key: string, value: string): Promise<void>;
  removeItem(key: string): Promise<void>;
}

export function createMemoryStorage(initial: Record<string, string> = {}): StorageAdapter & { data: Record<string, string> } {
  const data = { ...initial };
  return {
    data,
    getItem: async (k) => (k in data ? data[k] : null),
    setItem: async (k, v) => {
      data[k] = v;
    },
    removeItem: async (k) => {
      delete data[k];
    },
  };
}

export async function loadRaw(storage: StorageAdapter, key = STORAGE_KEY): Promise<unknown> {
  try {
    const text = await storage.getItem(key);
    return text ? JSON.parse(text) : null;
  } catch {
    return null;
  }
}

export interface PersistenceHandle {
  flush(): Promise<void>;
  stop(): void;
}

/** Saves persisted slices shortly after they change. Toasts and other UI-only state are skipped. */
export function attachPersistence(
  store: Store<AppState>,
  storage: StorageAdapter,
  opts: { debounceMs?: number; key?: string } = {},
): PersistenceHandle {
  const debounceMs = opts.debounceMs ?? 400;
  const key = opts.key ?? STORAGE_KEY;
  let timer: ReturnType<typeof setTimeout> | null = null;
  let prev = store.get();

  const write = async () => {
    timer = null;
    const s = store.get();
    if (!s.hydrated) return;
    try {
      await storage.setItem(key, JSON.stringify(toPersisted(s)));
    } catch {
      // Storage full or unavailable: keep running, try again on the next change.
    }
  };

  const unsubscribe = store.subscribe(() => {
    const next = store.get();
    const changed = PERSISTED_KEYS.some((k) => next[k] !== prev[k]);
    prev = next;
    if (!changed || !next.hydrated) return;
    if (timer) clearTimeout(timer);
    timer = setTimeout(write, debounceMs);
  });

  return {
    async flush() {
      if (timer) clearTimeout(timer);
      await write();
    },
    stop() {
      unsubscribe();
      if (timer) clearTimeout(timer);
    },
  };
}
