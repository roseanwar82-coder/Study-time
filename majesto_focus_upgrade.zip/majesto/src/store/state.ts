import type { AppState, Card, Deck, PersistedState, Profile, Settings } from '@/core/types';
import { newSrsState } from '@/core/srs';

export const SCHEMA_VERSION = 1;
export const STORAGE_KEY = 'majesto:state';

export const DECK_COLORS = ['#79BFA9', '#E0B45A', '#A08CE6', '#E58F7B', '#6FA8DC', '#C9A0DC'];

export const DEFAULT_SETTINGS: Settings = {
  dailyFocusGoalMin: 60,
  dailyReviewGoal: 20,
  dailyDrillGoal: 1,
  focusMin: 25,
  breakMin: 5,
  newCardsPerDay: 10,
  haptics: true,
  notifications: true,
  typedRecall: false,
  guardEnabled: false,
  blockedApps: [],
  floatingTimer: true,
  dndMode: 'off',
  aiEndpoint: '',
};

const STARTER_CARDS: [string, string][] = [
  ['What is active recall?', 'Pulling information out of memory without looking at it. Testing yourself beats rereading.'],
  ['What is the spacing effect?', 'Reviews spread over time are remembered longer than the same effort packed into one sitting.'],
  ['What do Again, Hard, Good and Easy tell the scheduler?', 'How hard the recall was, so the next review lands just before you would forget.'],
  ['What is the forgetting curve?', 'Memory of new material fades quickly at first, then more slowly, unless it is reviewed.'],
  ['What does the Pomodoro technique prescribe?', 'Work in focused blocks, classically 25 minutes, separated by short breaks.'],
  ['What is working memory?', 'The small mental workspace that holds and manipulates a handful of items at once, roughly four chunks.'],
];

export function createSeed(now: number, id: (p?: string) => string): { decks: Deck[]; cards: Card[] } {
  const deck: Deck = { id: id('deck'), name: 'Getting started', color: DECK_COLORS[0], createdAt: now };
  const cards: Card[] = STARTER_CARDS.map(([front, back], i) => ({
    id: id('card'),
    deckId: deck.id,
    front,
    back,
    createdAt: now + i,
    srs: newSrsState(now),
  }));
  return { decks: [deck], cards };
}

function emptyPersisted(now: number): PersistedState {
  return {
    version: SCHEMA_VERSION,
    profile: { name: '', createdAt: now, onboarded: false },
    settings: { ...DEFAULT_SETTINGS },
    xp: 0,
    activity: {},
    tasks: [],
    sessions: [],
    timer: null,
    decks: [],
    cards: [],
    drills: { results: [], stats: {}, levels: {} },
    achievements: {},
  };
}

export function createInitialPersisted(now: number, id: (p?: string) => string): PersistedState {
  return { ...emptyPersisted(now), ...createSeed(now, id) };
}

export function createInitialState(now: number, id: (p?: string) => string): AppState {
  return { ...createInitialPersisted(now, id), hydrated: false, toasts: [] };
}

/**
 * Each entry upgrades stored data from schema version (index + 1) to the next one.
 * Add a function here whenever the persisted shape changes, and bump SCHEMA_VERSION.
 */
const MIGRATIONS: ((raw: Record<string, unknown>) => Record<string, unknown>)[] = [];

function isObject(v: unknown): v is Record<string, unknown> {
  return typeof v === 'object' && v !== null && !Array.isArray(v);
}

/** Repairs the focus-guard fields, which older saves don't have and hand-edited saves might get wrong. */
function cleanSettings(s: Settings): Settings {
  const blockedApps = Array.isArray(s.blockedApps)
    ? [...new Set(s.blockedApps.filter((x): x is string => typeof x === 'string' && x.length > 0))]
    : [];
  return {
    ...s,
    guardEnabled: s.guardEnabled === true,
    blockedApps,
    floatingTimer: s.floatingTimer !== false,
    dndMode: s.dndMode === 'priority' || s.dndMode === 'alarms' ? s.dndMode : 'off',
    aiEndpoint: typeof s.aiEndpoint === 'string' ? s.aiEndpoint : '',
  };
}

/** Turn whatever was in storage into a valid state. Never throws. */
export function migrate(raw: unknown, now: number, id: (p?: string) => string): PersistedState {
  if (!isObject(raw)) return createInitialPersisted(now, id);

  let data: Record<string, unknown> = raw;
  let version = typeof data.version === 'number' ? data.version : 1;
  while (version < SCHEMA_VERSION && MIGRATIONS[version - 1]) {
    data = MIGRATIONS[version - 1](data);
    version++;
  }

  const base = emptyPersisted(now);
  const r = data as Partial<PersistedState>;
  const decks = Array.isArray(r.decks) ? r.decks.filter((d) => isObject(d) && typeof d.id === 'string') : [];
  const deckIds = new Set(decks.map((d) => d.id));
  const cards = (Array.isArray(r.cards) ? r.cards : [])
    .filter((c) => isObject(c) && typeof c.id === 'string' && deckIds.has(c.deckId))
    .map((c) => ({ ...c, srs: { ...newSrsState(c.createdAt ?? now), ...(c.srs ?? {}) } }));

  return {
    version: SCHEMA_VERSION,
    profile: { ...base.profile, ...(isObject(r.profile) ? (r.profile as Partial<Profile>) : {}) },
    settings: cleanSettings({ ...DEFAULT_SETTINGS, ...(isObject(r.settings) ? (r.settings as Partial<Settings>) : {}) }),
    xp: typeof r.xp === 'number' && r.xp >= 0 ? r.xp : 0,
    activity: isObject(r.activity) ? (r.activity as PersistedState['activity']) : {},
    tasks: Array.isArray(r.tasks) ? r.tasks : [],
    sessions: Array.isArray(r.sessions) ? r.sessions : [],
    timer: isObject(r.timer) ? (r.timer as PersistedState['timer']) : null,
    decks,
    cards,
    drills: {
      results: Array.isArray(r.drills?.results) ? r.drills.results : [],
      stats: isObject(r.drills?.stats) ? r.drills.stats : {},
      levels: isObject(r.drills?.levels) ? r.drills.levels : {},
    },
    achievements: isObject(r.achievements) ? (r.achievements as Record<string, number>) : {},
  };
}

export const PERSISTED_KEYS = [
  'version', 'profile', 'settings', 'xp', 'activity', 'tasks', 'sessions',
  'timer', 'decks', 'cards', 'drills', 'achievements',
] as const satisfies readonly (keyof PersistedState)[];

export function toPersisted(s: AppState): PersistedState {
  const out = {} as Record<string, unknown>;
  for (const k of PERSISTED_KEYS) out[k] = s[k];
  return out as unknown as PersistedState;
}
