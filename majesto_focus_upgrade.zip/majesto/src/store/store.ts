export type Listener = () => void;

export interface Store<S> {
  get(): S;
  set(updater: (state: S) => S): void;
  subscribe(listener: Listener): () => void;
}

/** A tiny observable store. Returning the same object from an updater is a no-op. */
export function createStore<S>(initial: S): Store<S> {
  let state = initial;
  const listeners = new Set<Listener>();
  return {
    get: () => state,
    set(updater) {
      const next = updater(state);
      if (next === state) return;
      state = next;
      listeners.forEach((l) => l());
    },
    subscribe(listener) {
      listeners.add(listener);
      return () => {
        listeners.delete(listener);
      };
    },
  };
}
