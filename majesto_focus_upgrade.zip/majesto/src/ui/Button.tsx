import type { ComponentProps } from 'react';
import { ActivityIndicator, Pressable, StyleSheet, View, type StyleProp, type ViewStyle } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { haptic } from '@/services/haptics';
import { Txt } from './Text';
import { colors, radius } from './theme';

export type IconName = ComponentProps<typeof Ionicons>['name'];

interface Props {
  title: string;
  onPress: () => void;
  variant?: 'primary' | 'secondary' | 'ghost' | 'danger';
  /** Accent color for the button. Defaults to the focus gold. */
  tint?: string;
  icon?: IconName;
  size?: 'md' | 'lg';
  disabled?: boolean;
  loading?: boolean;
  style?: StyleProp<ViewStyle>;
}

export function Button({
  title, onPress, variant = 'primary', tint = colors.gold, icon, size = 'md', disabled, loading, style,
}: Props) {
  const primary = variant === 'primary';
  const fg = primary ? colors.onAccent : variant === 'danger' ? colors.danger : variant === 'ghost' ? tint : colors.text;
  const bg = primary ? tint : variant === 'secondary' ? colors.surfaceHi : 'transparent';
  const borderColor = primary ? tint : variant === 'danger' ? colors.danger : variant === 'ghost' ? 'transparent' : colors.border;

  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={title}
      accessibilityState={{ disabled: !!disabled }}
      disabled={disabled || loading}
      onPress={() => {
        haptic.tap();
        onPress();
      }}
      style={({ pressed }) => [
        styles.base,
        size === 'lg' ? styles.lg : styles.md,
        { backgroundColor: bg, borderColor },
        pressed && styles.pressed,
        disabled && styles.disabled,
        style,
      ]}
    >
      {loading ? (
        <ActivityIndicator color={fg} />
      ) : (
        <View style={styles.row}>
          {icon ? <Ionicons name={icon} size={size === 'lg' ? 20 : 18} color={fg} /> : null}
          <Txt variant={size === 'lg' ? 'body' : 'small'} style={{ color: fg, fontWeight: '700' }}>
            {title}
          </Txt>
        </View>
      )}
    </Pressable>
  );
}

const styles = StyleSheet.create({
  base: { borderRadius: radius.md, borderWidth: 1, alignItems: 'center', justifyContent: 'center' },
  md: { minHeight: 44, paddingHorizontal: 16 },
  lg: { minHeight: 54, paddingHorizontal: 22 },
  row: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  pressed: { opacity: 0.85, transform: [{ scale: 0.98 }] },
  disabled: { opacity: 0.4 },
});
