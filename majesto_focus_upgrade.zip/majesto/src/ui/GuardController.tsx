import { useCallback, useEffect, useRef } from 'react';
import { AppState } from 'react-native';
import { router, usePathname } from 'expo-router';
import { remainingMs } from '@/core/focus';
import { guardOptions, reconcileGuard, timerToNative, type GuardAction } from '@/core/guard';
import { formatMinutes } from '@/core/time';
import { focusGuard } from '@/services/focusGuard';
import { cancelTimerEnd, scheduleTimerEnd } from '@/services/notifications';
import { actions, store, useApp } from '@/store';

/**
 * Keeps the Android focus guard (floating timer, app blocking, Do Not Disturb) in step with the focus timer.
 *
 * The timer in the store is the single source of truth. This component only
 *  - starts the native service when a guarded focus block begins (or after the app was restarted),
 *  - copies pause/resume to it,
 *  - applies presses made on the floating timer to the store,
 *  - shuts the native side down when the block is over.
 *
 * It never stops or pauses anything because the app was opened, so using the AI helper can't switch the
 * restrictions off.
 */
export function GuardController() {
  const timer = useApp((s) => s.timer);
  const pathname = usePathname();
  const pathRef = useRef(pathname);
  pathRef.current = pathname;
  const warnedFor = useRef<string | null>(null);

  const execute = useCallback((action: GuardAction) => {
    const t = store.get().timer;
    switch (action.type) {
      case 'start': {
        if (!t?.guard) return;
        const status = focusGuard.startSession(timerToNative(t), guardOptions(t.guard));
        if (status && warnedFor.current !== t.id) {
          warnedFor.current = t.id;
          const wanted = t.guard;
          if (!status.serviceStarted) {
            actions.pushToast('Focus guard could not start', 'Android did not allow it right now. Open Majesto and start the block again.');
          } else if (wanted.blockedApps.length > 0 && !status.blocking) {
            actions.pushToast('App blocking is off', 'Finish setup in Profile, Focus guard & AI help.');
          } else if (wanted.floatingTimer && !status.floatingTimer) {
            actions.pushToast('Floating timer is off', 'Allow "Display over other apps" in Focus guard settings.');
          }
        }
        return;
      }
      case 'sync':
        if (t) focusGuard.syncTimer(timerToNative(t));
        return;
      case 'stop-native':
        focusGuard.stopGuard();
        return;
      case 'apply': {
        if (t) {
          if (action.command === 'pause') {
            if (t.pausedAt === null) {
              cancelTimerEnd();
              actions.pauseTimer(action.at);
            }
          } else if (action.command === 'resume') {
            if (t.pausedAt !== null) {
              actions.resumeTimer(action.at);
              const now = store.get().timer;
              if (now) scheduleTimerEnd(remainingMs(now, Date.now()) / 1000, now.kind);
            }
          } else {
            cancelTimerEnd();
            const res = actions.finishTimer(false, action.at);
            if (res?.session) actions.pushToast('Session stopped', `${formatMinutes(res.session.actualMs)} logged. +${res.xp} XP`);
            else if (res) actions.pushToast('Session stopped', 'Under a minute, so nothing was logged.');
          }
        }
        focusGuard.ackCommand();
        return;
      }
      default:
        return;
    }
  }, []);

  const reconcile = useCallback(() => {
    if (!focusGuard.isSupported) return;
    const action = reconcileGuard(store.get().timer, focusGuard.getSessionState(), Date.now());
    if (action.type !== 'none') execute(action);
  }, [execute]);

  const openAssistIfPicturePending = useCallback(() => {
    if (!focusGuard.hasPendingImage() || pathRef.current === '/assist') return;
    let tries = 0;
    const go = () => {
      try {
        router.push('/assist');
      } catch {
        if (++tries < 6) setTimeout(go, 400);
      }
    };
    go();
  }, []);

  // Any change to the timer (start, pause, resume, finish) is reconciled straight away.
  useEffect(() => {
    reconcile();
  }, [timer, reconcile]);

  // Coming back to the app: catch up on anything pressed on the floating timer while we were away.
  useEffect(() => {
    if (!focusGuard.isSupported) return;
    focusGuard.checkShareIntent();
    openAssistIfPicturePending();
    const sub = AppState.addEventListener('change', (s) => {
      if (s !== 'active') return;
      reconcile();
      focusGuard.checkShareIntent();
      openAssistIfPicturePending();
    });
    return () => sub.remove();
  }, [reconcile, openAssistIfPicturePending]);

  // Live events from the native side.
  useEffect(() => {
    if (!focusGuard.isSupported) return;
    const offs = [
      focusGuard.on('onCommand', reconcile),
      focusGuard.on('onSessionEnded', reconcile),
      focusGuard.on('onScreenshot', openAssistIfPicturePending),
      focusGuard.on('onSharedImage', openAssistIfPicturePending),
    ];
    return () => offs.forEach((off) => off());
  }, [reconcile, openAssistIfPicturePending]);

  return null;
}
