import { useState } from 'react';
import { StyleSheet, Switch, TextInput, View, type TextInputProps } from 'react-native';
import { IconButton } from './Layout';
import { Txt } from './Text';
import { colors, radius, space } from './theme';

export function TextField({ label, style, ...rest }: TextInputProps & { label?: string }) {
  const [focused, setFocused] = useState(false);
  return (
    <View style={{ gap: 6 }}>
      {label ? <Txt variant="small" color="textDim">{label}</Txt> : null}
      <TextInput
        placeholderTextColor={colors.textFaint}
        selectionColor={colors.gold}
        {...rest}
        onFocus={(e) => {
          setFocused(true);
          rest.onFocus?.(e);
        }}
        onBlur={(e) => {
          setFocused(false);
          rest.onBlur?.(e);
        }}
        style={[styles.input, focused && { borderColor: colors.textDim }, rest.multiline && styles.multiline, style]}
      />
    </View>
  );
}

export function Stepper({ label, value, onChange, min, max, step = 1, format }: {
  label: string; value: number; onChange: (v: number) => void; min: number; max: number; step?: number; format?: (v: number) => string;
}) {
  return (
    <View style={styles.settingRow}>
      <Txt style={{ flex: 1 }}>{label}</Txt>
      <View style={styles.stepper}>
        <IconButton icon="remove-circle-outline" label={`Decrease ${label}`} onPress={() => onChange(Math.max(min, value - step))} size={26} />
        <Txt variant="body" style={styles.stepperValue}>{format ? format(value) : String(value)}</Txt>
        <IconButton icon="add-circle-outline" label={`Increase ${label}`} onPress={() => onChange(Math.min(max, value + step))} size={26} />
      </View>
    </View>
  );
}

export function ToggleRow({ label, hint, value, onChange }: { label: string; hint?: string; value: boolean; onChange: (v: boolean) => void }) {
  return (
    <View style={styles.settingRow}>
      <View style={{ flex: 1, gap: 2 }}>
        <Txt>{label}</Txt>
        {hint ? <Txt variant="caption" color="textDim">{hint}</Txt> : null}
      </View>
      <Switch
        value={value}
        onValueChange={onChange}
        trackColor={{ false: colors.border, true: colors.gold + '99' }}
        thumbColor={value ? colors.gold : colors.textDim}
        accessibilityLabel={label}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  input: {
    backgroundColor: colors.surfaceHi,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.md,
    color: colors.text,
    fontSize: 16,
    paddingHorizontal: space.lg,
    paddingVertical: 12,
    minHeight: 48,
  },
  multiline: { minHeight: 96, textAlignVertical: 'top', paddingTop: 12 },
  settingRow: { flexDirection: 'row', alignItems: 'center', gap: space.md, minHeight: 48 },
  stepper: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  stepperValue: { minWidth: 64, textAlign: 'center', fontWeight: '600' },
});
