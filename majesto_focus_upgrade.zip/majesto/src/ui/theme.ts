import { Platform, type TextStyle } from 'react-native';

export const colors = {
  bg: '#0D0C10',
  surface: '#16141B',
  surfaceHi: '#1F1C26',
  border: '#2B2733',
  text: '#F1E9D8',
  textDim: '#A9A092',
  textFaint: '#6E675C',
  /** Focus */
  gold: '#E0B45A',
  /** Recall */
  sage: '#79BFA9',
  /** Drills */
  amethyst: '#A08CE6',
  danger: '#E5645B',
  success: '#7BC496',
  onAccent: '#1A1408',
} as const;

export type ColorName = keyof typeof colors;

/** Each area of the app keeps its own hue everywhere it appears. */
export const areaColor = {
  focus: colors.gold,
  recall: colors.sage,
  drills: colors.amethyst,
} as const;

export const fonts = {
  serif: Platform.select({ ios: 'Georgia', android: 'serif', default: 'serif' }) as string,
};

export const space = { xs: 4, sm: 8, md: 12, lg: 16, xl: 24, xxl: 32 } as const;

export const radius = { sm: 10, md: 16, lg: 22, pill: 999 } as const;

export const typeStyles = {
  display: { fontFamily: fonts.serif, fontSize: 34, lineHeight: 40, letterSpacing: -0.4 },
  title: { fontFamily: fonts.serif, fontSize: 24, lineHeight: 30 },
  heading: { fontFamily: fonts.serif, fontSize: 18, lineHeight: 24 },
  body: { fontSize: 16, lineHeight: 23 },
  small: { fontSize: 14, lineHeight: 20 },
  caption: { fontSize: 12, lineHeight: 16 },
  numeral: { fontFamily: fonts.serif, fontSize: 64, lineHeight: 72, fontVariant: ['tabular-nums'] },
  cardFace: { fontFamily: fonts.serif, fontSize: 26, lineHeight: 36, textAlign: 'center' },
} satisfies Record<string, TextStyle>;

export type TypeVariant = keyof typeof typeStyles;
