import test from 'node:test';
import assert from 'node:assert/strict';
import {
  buildQueue, deckCounts, dueLabel, formatDays, newSrsState, parseBulkCards, previewIntervals, schedule,
  LEARNING_STEPS_MIN, MIN_EASE,
} from '@/core/srs';
import { DAY, MINUTE, dayKey, startOfDay } from '@/core/time';
import type { Card, SrsState } from '@/core/types';
import { at } from './helpers';

const NOW = at(2026, 9, 20, 10, 0);

const card = (id: string, srs: Partial<SrsState> = {}, createdAt = 0): Card => ({
  id,
  deckId: 'd1',
  front: id,
  back: id,
  createdAt,
  srs: { ...newSrsState(NOW), ...srs },
});

test('new card + again goes to the first learning step', () => {
  const s = schedule(newSrsState(NOW), 'again', NOW);
  assert.equal(s.phase, 'learning');
  assert.equal(s.step, 0);
  assert.equal(s.due, NOW + LEARNING_STEPS_MIN[0] * MINUTE);
  assert.equal(s.reps, 1);
});

test('new card + good moves to step 2, then graduates to a 1 day interval', () => {
  const a = schedule(newSrsState(NOW), 'good', NOW);
  assert.equal(a.phase, 'learning');
  assert.equal(a.step, 1);
  assert.equal(a.due, NOW + 10 * MINUTE);

  const b = schedule(a, 'good', NOW + 10 * MINUTE);
  assert.equal(b.phase, 'review');
  assert.equal(b.intervalDays, 1);
  assert.equal(b.due, startOfDay('2026-09-21'));
});

test('new card + easy graduates straight to 4 days', () => {
  const s = schedule(newSrsState(NOW), 'easy', NOW);
  assert.equal(s.phase, 'review');
  assert.equal(s.intervalDays, 4);
  assert.equal(dayKey(s.due), '2026-09-24');
});

test('hard in learning repeats the step', () => {
  const a = schedule(newSrsState(NOW), 'good', NOW); // step 1
  const b = schedule(a, 'hard', NOW);
  assert.equal(b.step, 1);
  assert.equal(b.phase, 'learning');
});

const review = (intervalDays: number, ease = 2.5): SrsState => ({
  ...newSrsState(NOW),
  phase: 'review',
  intervalDays,
  ease,
  reps: 5,
  due: NOW - 1,
});

test('review good multiplies the interval by ease', () => {
  const s = schedule(review(10), 'good', NOW);
  assert.equal(s.intervalDays, 25);
  assert.equal(s.ease, 2.5);
});

test('review hard grows slowly and lowers ease', () => {
  const s = schedule(review(10), 'hard', NOW);
  assert.equal(s.intervalDays, 12);
  assert.equal(s.ease, 2.35);
});

test('review easy grows fast and raises ease', () => {
  const s = schedule(review(10), 'easy', NOW);
  assert.equal(s.intervalDays, Math.round(10 * 2.5 * 1.3));
  assert.equal(s.ease, 2.65);
});

test('interval always grows by at least a day on good', () => {
  const s = schedule(review(1, 1.3), 'good', NOW);
  assert.equal(s.intervalDays, 2);
});

test('lapse: goes back to learning, lowers ease, counts the lapse, shrinks the interval', () => {
  const s = schedule(review(20), 'again', NOW);
  assert.equal(s.phase, 'learning');
  assert.equal(s.lapses, 1);
  assert.equal(s.ease, 2.3);
  assert.equal(s.intervalDays, 6);
  assert.equal(s.due, NOW + MINUTE);
});

test('a lapsed card returns to review at its reduced interval', () => {
  const lapsed = schedule(review(20), 'again', NOW);
  const step2 = schedule(lapsed, 'good', NOW);
  const back = schedule(step2, 'good', NOW);
  assert.equal(back.phase, 'review');
  assert.equal(back.intervalDays, 6);
});

test('ease never drops below the floor', () => {
  let s = review(10, 1.35);
  for (let i = 0; i < 5; i++) {
    s = schedule({ ...s, phase: 'review' }, 'hard', NOW);
  }
  assert.ok(s.ease >= MIN_EASE);
});

test('scheduling does not mutate the input', () => {
  const s = newSrsState(NOW);
  const copy = JSON.stringify(s);
  schedule(s, 'good', NOW);
  assert.equal(JSON.stringify(s), copy);
});

test('buildQueue orders learning, then due reviews, then new, and respects limits', () => {
  const cards = [
    card('new1', {}, 1),
    card('new2', {}, 2),
    card('new3', {}, 3),
    card('rev-late', { phase: 'review', intervalDays: 3, due: NOW - 2 * DAY }),
    card('rev-early', { phase: 'review', intervalDays: 3, due: NOW - 5 * DAY }),
    card('rev-future', { phase: 'review', intervalDays: 3, due: NOW + 2 * DAY }),
    card('learn-due', { phase: 'learning', due: NOW - MINUTE }),
    card('learn-soon', { phase: 'learning', due: NOW + 10 * MINUTE }),
    card('learn-later', { phase: 'learning', due: NOW + 3 * 60 * MINUTE }),
  ];
  const q = buildQueue(cards, NOW, { newLimit: 2 });
  assert.deepEqual(q, ['learn-due', 'learn-soon', 'rev-early', 'rev-late', 'new1', 'new2']);
});

test('deckCounts reflects the queue', () => {
  const cards = [card('a', {}, 1), card('b', {}, 2), card('c', { phase: 'review', intervalDays: 2, due: NOW - 1 })];
  assert.deepEqual(deckCounts(cards, NOW, 1), { new: 1, learning: 0, review: 1, total: 2 });
  assert.deepEqual(deckCounts(cards, NOW, 0), { new: 0, learning: 0, review: 1, total: 1 });
});

test('previewIntervals for a new card', () => {
  const p = previewIntervals(newSrsState(NOW), NOW);
  assert.deepEqual(p, { again: '1m', hard: '1m', good: '10m', easy: '4d' });
});

test('previewIntervals for a mature card', () => {
  const p = previewIntervals(review(10), NOW);
  assert.equal(p.again, '1m');
  assert.equal(p.hard, '12d');
  assert.equal(p.good, '25d');
  assert.equal(p.easy, '1.1mo'); // 33 days
});

test('formatDays', () => {
  assert.equal(formatDays(5), '5d');
  assert.equal(formatDays(45), '1.5mo');
  assert.equal(formatDays(60), '2mo');
  assert.equal(formatDays(730), '2y');
});

test('dueLabel', () => {
  assert.equal(dueLabel(newSrsState(NOW), NOW), 'New');
  assert.equal(dueLabel(review(3), NOW), 'Due');
  assert.equal(dueLabel({ ...review(3), due: startOfDay('2026-09-21') }, NOW), 'Tomorrow');
  assert.equal(dueLabel({ ...review(3), due: startOfDay('2026-09-25') }, NOW), 'in 5d');
  assert.equal(dueLabel({ ...newSrsState(NOW), phase: 'learning', due: NOW + 10 * MINUTE }, NOW), 'in 10m');
});

test('parseBulkCards handles :: and tabs, skips bad lines', () => {
  const r = parseBulkCards('Capital of France :: Paris\n\nH2O\tWater\nno separator here\n:: missing front\nmissing back ::\n');
  assert.deepEqual(r.cards, [
    { front: 'Capital of France', back: 'Paris' },
    { front: 'H2O', back: 'Water' },
  ]);
  assert.equal(r.skipped, 3);
});

test('parseBulkCards keeps extra :: inside the answer', () => {
  const r = parseBulkCards('Ratio :: 3::1');
  assert.deepEqual(r.cards, [{ front: 'Ratio', back: '3::1' }]);
});
