import test from 'node:test';
import assert from 'node:assert/strict';
import { countsForDeck, newCardsRemaining, recommendedDrill, todaySummary, todayTasks, weekSeries } from '@/core/stats';
import { MINUTE, DAY } from '@/core/time';
import { at, makeApp } from './helpers';

test('today summary tracks progress against goals and caps at 100%', () => {
  const app = makeApp();
  app.actions.updateSettings({ dailyFocusGoalMin: 50, dailyReviewGoal: 10, dailyDrillGoal: 2 });
  app.actions.startTimer({ kind: 'focus', minutes: 25 });
  app.advance(25 * MINUTE);
  app.actions.finishTimer(true);
  app.actions.recordDrill({ kind: 'span', points: 500, summary: 's', accuracy: null, durationMs: 1, level: 1 });
  const t = todaySummary(app.state(), app.now());
  assert.equal(t.focusRatio, 0.5);
  assert.equal(t.reviewRatio, 0);
  assert.equal(t.drillRatio, 0.5);
  assert.ok(Math.abs(t.overall - 1 / 3) < 1e-9);

  app.actions.recordDrill({ kind: 'span', points: 500, summary: 's', accuracy: null, durationMs: 1, level: 1 });
  app.actions.recordDrill({ kind: 'span', points: 500, summary: 's', accuracy: null, durationMs: 1, level: 1 });
  assert.equal(todaySummary(app.state(), app.now()).drillRatio, 1);
});

test('today tasks: open first, carries over unfinished work, hides old finished work', () => {
  const app = makeApp(at(2026, 9, 19, 9));
  const oldOpen = app.actions.addTask('carried over')!;
  const oldDone = app.actions.addTask('finished yesterday')!;
  app.actions.toggleTask(oldDone);
  app.advance(DAY);
  const a = app.actions.addTask('today A')!;
  const b = app.actions.addTask('today B')!;
  app.actions.toggleTask(a);
  const key = '2026-09-20';
  const list = todayTasks(app.state(), key);
  assert.deepEqual(list.map((t) => t.title), ['carried over', 'today B', 'today A']);
  assert.ok(oldOpen && b);
});

test('new cards per day are limited by what was already introduced today', () => {
  const app = makeApp();
  app.actions.updateSettings({ newCardsPerDay: 2 });
  assert.equal(newCardsRemaining(app.state(), app.now()), 2);
  assert.equal(countsForDeck(app.state(), null, app.now()).new, 2);
  const [c1, c2] = app.state().cards;
  app.actions.gradeCard(c1.id, 'easy');
  assert.equal(newCardsRemaining(app.state(), app.now()), 1);
  app.actions.gradeCard(c2.id, 'easy');
  assert.equal(newCardsRemaining(app.state(), app.now()), 0);
  assert.equal(countsForDeck(app.state(), null, app.now()).new, 0);
});

test('counts for a single deck only include that deck', () => {
  const app = makeApp();
  const deckId = app.actions.addDeck('Other')!;
  app.actions.addCards(deckId, [{ front: 'a', back: 'b' }]);
  assert.equal(countsForDeck(app.state(), deckId, app.now()).total, 1);
});

test('week series spans seven days ending today and flags active days', () => {
  const app = makeApp(at(2026, 9, 18, 9));
  app.actions.recordDrill({ kind: 'span', points: 800, summary: 's', accuracy: null, durationMs: 1, level: 1 });
  app.advance(2 * DAY);
  const w = weekSeries(app.state(), app.now());
  assert.equal(w.length, 7);
  assert.equal(w.at(-1)?.isToday, true);
  assert.equal(w.at(-1)?.key, '2026-09-20');
  assert.equal(w.find((d) => d.key === '2026-09-18')?.active, true);
  assert.equal(w.find((d) => d.key === '2026-09-19')?.active, false);
  assert.equal(Math.max(...w.map((d) => d.ratio)), 1);
});

test('recommended drill prefers never-played, then least recently played', () => {
  const app = makeApp();
  assert.equal(recommendedDrill(app.state()), 'schulte');
  for (const kind of ['schulte', 'span', 'nback', 'stroop'] as const) {
    app.actions.recordDrill({ kind, points: 100, summary: 's', accuracy: null, durationMs: 1, level: 1 });
    app.advance(MINUTE);
  }
  assert.equal(recommendedDrill(app.state()), 'sequence');
  app.actions.recordDrill({ kind: 'sequence', points: 100, summary: 's', accuracy: null, durationMs: 1, level: 1 });
  assert.equal(recommendedDrill(app.state()), 'schulte'); // oldest play
});
