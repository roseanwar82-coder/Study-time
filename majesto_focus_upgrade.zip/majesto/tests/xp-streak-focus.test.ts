import test from 'node:test';
import assert from 'node:assert/strict';
import { levelFromXp, levelProgress, levelTitle, xpForDrill, xpForFocus, xpForLevel, xpForReview } from '@/core/xp';
import { computeStreak, emptyActivity, isActiveDay } from '@/core/streak';
import { buildSession, createTimer, elapsedMs, isExpired, pauseTimer, remainingMs, resumeTimer } from '@/core/focus';
import { MINUTE } from '@/core/time';
import type { DayActivity } from '@/core/types';
import { at } from './helpers';

test('level thresholds', () => {
  assert.equal(xpForLevel(1), 0);
  assert.equal(xpForLevel(2), 100);
  assert.equal(xpForLevel(3), 300);
  assert.equal(levelFromXp(0), 1);
  assert.equal(levelFromXp(99), 1);
  assert.equal(levelFromXp(100), 2);
  assert.equal(levelFromXp(299), 2);
  assert.equal(levelFromXp(300), 3);
  assert.equal(levelFromXp(-50), 1);
});

test('levelFromXp is consistent with xpForLevel across a wide range', () => {
  for (let xp = 0; xp < 60_000; xp += 37) {
    const l = levelFromXp(xp);
    assert.ok(xpForLevel(l) <= xp && xp < xpForLevel(l + 1), `xp ${xp} -> level ${l}`);
  }
});

test('levelProgress', () => {
  const p = levelProgress(200);
  assert.equal(p.level, 2);
  assert.equal(p.current, 100);
  assert.equal(p.needed, 200);
  assert.equal(p.ratio, 0.5);
});

test('level titles step up every three levels', () => {
  assert.equal(levelTitle(1), 'Novice');
  assert.equal(levelTitle(3), 'Novice');
  assert.equal(levelTitle(4), 'Apprentice');
  assert.equal(levelTitle(999), 'Grandmaster');
});

test('xp for focus', () => {
  assert.equal(xpForFocus(30_000, true, 0), 0);
  assert.equal(xpForFocus(25 * MINUTE, true, 0), 60);
  assert.equal(xpForFocus(25 * MINUTE, false, 0), 50);
  assert.equal(xpForFocus(25 * MINUTE, true, 3), 54);
  assert.equal(xpForFocus(10 * MINUTE, true, 100), 20 + 10 - 6); // penalty is capped at 30% of base
  assert.equal(xpForFocus(500 * MINUTE, false, 0), 360);
});

test('xp for review and drills', () => {
  assert.equal(xpForReview('again'), 1);
  assert.equal(xpForReview('good'), 2);
  assert.equal(xpForReview('easy'), 3);
  assert.equal(xpForDrill(0, false), 10);
  assert.equal(xpForDrill(1000, false), 40);
  assert.equal(xpForDrill(500, true), 35);
  assert.equal(xpForDrill(5000, false), 40);
});

/* ---------- streaks ---------- */

const active = (over: Partial<DayActivity> = {}): DayActivity => ({ ...emptyActivity(), drills: 1, ...over });

test('what counts as an active day', () => {
  assert.equal(isActiveDay(undefined), false);
  assert.equal(isActiveDay(emptyActivity()), false);
  assert.equal(isActiveDay({ ...emptyActivity(), focusMs: 9 * MINUTE }), false);
  assert.equal(isActiveDay({ ...emptyActivity(), focusMs: 10 * MINUTE }), true);
  assert.equal(isActiveDay({ ...emptyActivity(), reviews: 10 }), true);
  assert.equal(isActiveDay({ ...emptyActivity(), drills: 1 }), true);
});

test('streak counts consecutive days including today', () => {
  const a = { '2026-09-18': active(), '2026-09-19': active(), '2026-09-20': active() };
  assert.deepEqual(computeStreak(a, '2026-09-20'), { current: 3, longest: 3, activeToday: true, atRisk: false });
});

test('streak stays alive through today until midnight', () => {
  const a = { '2026-09-18': active(), '2026-09-19': active() };
  const s = computeStreak(a, '2026-09-20');
  assert.equal(s.current, 2);
  assert.equal(s.activeToday, false);
  assert.equal(s.atRisk, true);
});

test('streak breaks after a missed day', () => {
  const a = { '2026-09-10': active(), '2026-09-11': active(), '2026-09-12': active(), '2026-09-19': active() };
  const s = computeStreak(a, '2026-09-20');
  assert.equal(s.current, 1);
  assert.equal(s.longest, 3);
  const dead = computeStreak({ '2026-09-10': active() }, '2026-09-20');
  assert.equal(dead.current, 0);
  assert.equal(dead.atRisk, false);
});

test('inactive days with partial activity do not extend a streak', () => {
  const a = { '2026-09-19': { ...emptyActivity(), reviews: 3 }, '2026-09-20': active() };
  assert.equal(computeStreak(a, '2026-09-20').current, 1);
});

/* ---------- focus timer ---------- */

const T0 = at(2026, 9, 20, 9, 0);

test('timer counts down and expires', () => {
  const t = createTimer({ kind: 'focus', minutes: 25 }, T0, 't1');
  assert.equal(remainingMs(t, T0), 25 * MINUTE);
  assert.equal(remainingMs(t, T0 + 10 * MINUTE), 15 * MINUTE);
  assert.equal(isExpired(t, T0 + 24 * MINUTE), false);
  assert.equal(isExpired(t, T0 + 25 * MINUTE), true);
  assert.equal(remainingMs(t, T0 + 99 * MINUTE), 0);
});

test('pausing freezes the clock and resuming continues from there', () => {
  let t = createTimer({ kind: 'focus', minutes: 25 }, T0, 't1');
  t = pauseTimer(t, T0 + 5 * MINUTE);
  assert.equal(remainingMs(t, T0 + 60 * MINUTE), 20 * MINUTE);
  t = resumeTimer(t, T0 + 30 * MINUTE);
  assert.equal(elapsedMs(t, T0 + 30 * MINUTE), 5 * MINUTE);
  assert.equal(remainingMs(t, T0 + 40 * MINUTE), 10 * MINUTE);
});

test('pause and resume are idempotent', () => {
  const t = createTimer({ kind: 'focus', minutes: 10 }, T0, 't1');
  assert.equal(resumeTimer(t, T0 + 1000), t);
  const p = pauseTimer(t, T0 + 1000);
  assert.equal(pauseTimer(p, T0 + 5000), p);
});

test('a completed session is capped at the planned time even if the app was closed', () => {
  const t = createTimer({ kind: 'focus', minutes: 25, label: '  Essay ' }, T0, 't1');
  const s = buildSession(t, T0 + 3 * 60 * MINUTE, true, 's1');
  assert.ok(s);
  assert.equal(s.actualMs, 25 * MINUTE);
  assert.equal(s.endedAt, T0 + 25 * MINUTE);
  assert.equal(s.label, 'Essay');
  assert.equal(s.xp, 60);
});

test('ending early gives partial credit; under a minute gives none', () => {
  const t = createTimer({ kind: 'focus', minutes: 25 }, T0, 't1');
  const partial = buildSession(t, T0 + 12 * MINUTE, false, 's1');
  assert.equal(partial?.actualMs, 12 * MINUTE);
  assert.equal(partial?.completed, false);
  assert.equal(partial?.xp, 24);
  assert.equal(buildSession(t, T0 + 30_000, false, 's2'), null);
});
